# মোবাইল থেকে GitHub APK তৈরির সহজ নিয়ম (v2.1.0)

1. নতুন `SRCreationFarm_Video_SEO_AI_YouTube_Facebook_2.1.0.zip` ডাউনলোড করুন।
2. GitHub Repository-র Root-এ ZIP ফাইলটি Upload করুন।
3. `build-apk.yml` আপলোড করুন **`.github/workflows/build-apk.yml`** পাথে।
4. আগের `.github/workflows/build-apk.yml` থাকলে Replace করুন।
5. GitHub → **Actions** → **Build Video SEO AI APK** → **Run workflow**।
6. Build সফল হলে `Artifacts` থেকে `youtube-seo-ai-debug-apk` ডাউনলোড করুন।
7. ZIP-এর ভেতরের `app-debug.apk` ফোনে Install করুন।

**মনে রাখবেন:** Source ZIP-এর ভেতর `.github/workflows/build-apk.yml` থাকলেও GitHub Workflow একা চালু হবে না। Workflow ফাইল Repository-তে আলাদাভাবে সঠিক জায়গায় থাকতে হবে।

**Build ব্যর্থ হলে:** একই Workflow Run-এর `youtube-seo-ai-build-diagnostics` Artifact Download করুন। সেখানে `sdk-install.log`, `build-validation.log`, `build-apk.log` ইত্যাদি প্রয়োজন অনুযায়ী থাকবে। Error স্ক্রিনশট বা লগ দিয়ে সংশোধন করা যাবে।

**Play Store release:** আগের প্রকাশিত অ্যাপ আপডেট করতে হলে আগের Signing Key ব্যবহার করুন; আলাদা Debug Signing দিয়ে সরাসরি আপডেট করা যায় না।
