# Video SEO AI (YouTube + Facebook) — SR Creation Farm

**Version:** 2.1.0 (`versionCode 6`)  
**Developer:** Shahriar Rahman  
**Brand:** SR Creation Farm  
**Application ID:** `com.shahriar.youtubeseo.youtube_seo_ai` (অপরিবর্তিত)  
**YouTube:** https://www.youtube.com/@SRCreation-farm  
**Facebook:** https://fb.com/srcreation.farm

## নতুন ও পুরোনো ফিচার
- তিনটি প্ল্যাটফর্মভিত্তিক Writing Mode: **YouTube SEO**, **Facebook Reels**, **Facebook Video**।
- পূর্বের YouTube Title + Description + Hashtags সুবিধা অক্ষত।
- Facebook Reels: Reel Hook, সংক্ষিপ্ত Caption, প্রাসঙ্গিক Hashtags।
- Facebook Video: বর্ণনামূলক Title, বিস্তারিত Caption, প্রাসঙ্গিক Hashtags।
- Google Gemini AI দিয়ে ঠিক ৩টি স্ক্রিনশট বিশ্লেষণ।
- বাংলা/English/মিশ্র ভাষা, কিওয়ার্ড এবং টার্গেট দর্শক নির্বাচন।
- Editable Results, Per-field Copy, Copy All, সর্বশেষ ২০টি Generation History।
- History-তে প্ল্যাটফর্মের নাম সংরক্ষণ, পুরোনো History-কে YouTube Mode হিসেবে পড়া।
- System / Light / Dark এবং ৯টি Color Theme; নির্বাচিত প্ল্যাটফর্মও সংরক্ষিত থাকে।
- Local Android Keystore AES-GCM encrypted Gemini API key।
- About Developer, YouTube/Facebook Link, Privacy Information ও Facebook Guidelines।

**Facebook Video / Reels সম্পর্কিত গুরুত্বপূর্ণ নোট:** Meta নতুন ভিডিওকে Reels হিসেবে শেয়ার করার পরিবর্তন জানিয়েছে; অ্যাপে দুটি Facebook Mode মূলত লেখার দৈর্ঘ্য ও ধরন আলাদা করে। কোনো Auto Posting বা Meta Approval Checker নেই। বিস্তারিত: `META_POLICY_GUIDE_BN.md`।

## মোবাইল থেকে GitHub APK

**দুটি ফাইল পদ্ধতি (সবচেয়ে সহজ):**
1. `SRCreationFarm_Video_SEO_AI_YouTube_Facebook_2.1.0.zip` GitHub Repository-র Root-এ Upload করুন।
2. আলাদা `build-apk.yml` ফাইলটি **`.github/workflows/build-apk.yml`**-এ রাখুন। ZIP-এর ভেতরের Workflow থেকে GitHub Actions নিজে চালু হয় না।
3. Root-এ পুরোনো একাধিক ZIP থাকলে সরিয়ে দিন, অথবা নিশ্চিত করুন নতুন ZIP ফাইলের নাম হুবহু মিলে।
4. GitHub → **Actions** → **Build Video SEO AI APK** → **Run workflow**।
5. সফল হলে **Artifacts → youtube-seo-ai-debug-apk** থেকে Installable Debug APK নিন।

**Extract পদ্ধতি:** ZIP Extract করে `.github`-সহ সব ফাইল Repository-র Root-এ আপলোড করতে পারেন। একই Workflow কাজ করবে।

## API সেটআপ
1. Google AI Studio থেকে ব্যবহারযোগ্য Gemini API Key নিন।
2. অ্যাপ → ⋮ → Settings → Gemini API Key-তে সংরক্ষণ করুন।
3. YouTube / FB Reels / FB Video নির্বাচন করুন।
4. ঠিক ৩টি স্ক্রিনশট দিন; প্রয়োজন অনুযায়ী কিওয়ার্ড লিখুন।
5. Generate → Caption/Title যাচাই → Copy করে প্রকাশ করুন।

### Privacy

স্ক্রিনশট ও Prompt আপনার ফোন থেকে Google Gemini API-তে যায়। SR Creation Farm-এর নিজস্ব সার্ভার ব্যবহৃত হয় না। Gemini API ব্যবহারের শর্ত ও কোটা প্রযোজ্য। ছবিতে ব্যক্তিগত তথ্য থাকলে প্রকাশের আগে নিজে সরিয়ে ফেলুন। Key Android Keystore দিয়ে এনক্রিপ্টেড এবং Local History ডিভাইসে রাখা হয়।

### Build/Signing

- Java 17, AGP 8.13.2, Gradle 8.13, compile/target SDK 36, min SDK 23।
- Android SDK `setup-android@v4` এবং API 36 Platform + Build Tools 35.0.0।
- Workflow Unit Tests, Lint, Debug & Release APK Build, APK Signature Verification এবং Diagnostic Log Artifact Upload করে।
- Debug APK পরীক্ষার জন্য Installable; Release APK কেবল Keystore Secrets যোগ করলে signed হবে।
- Required secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`।
- Workflow রান করার সময় Runner-এ Official Gradle Wrapper JAR তৈরি হয়; Source ZIP-এ JAR নেই।

### Known Limitations
- ৩টি Screenshot-এর বাইরে ভিডিও বা অডিও বিশ্লেষণ সরাসরি যুক্ত নেই।
- AI-র Caption বা Hashtags Meta Compliance নিশ্চয়তা নয়।
- এই পরিবেশে Android SDK/Gradle না থাকায় স্থানীয় Full APK Build চালানো হয়নি; GitHub workflow-এ Build সফল হওয়া নিশ্চিত করতে হবে।
