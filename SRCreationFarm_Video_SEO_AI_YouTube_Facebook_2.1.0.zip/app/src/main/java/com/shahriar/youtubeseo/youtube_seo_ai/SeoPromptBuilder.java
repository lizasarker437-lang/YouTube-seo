package com.shahriar.youtubeseo.youtube_seo_ai;

/** Pure-Java prompt builder, kept separate from Android networking for testability. */
public final class SeoPromptBuilder {
    private SeoPromptBuilder() {}

    public static String build(PlatformMode mode, String language, String keywords, String audience) {
        if (mode == null) mode = PlatformMode.YOUTUBE;
        String safeLanguage = value(language, "বাংলা");
        String safeKeywords = value(keywords, "স্ক্রিনশট অনুযায়ী প্রাসঙ্গিক বিষয় নির্বাচন করো");
        String safeAudience = value(audience, "ভিডিওর উপযুক্ত দর্শক");
        String common = "তুমি একজন social video content strategist।\n"
                + "সংযুক্ত ৩টি ভিডিও স্ক্রিনশট থেকে দৃশ্যমান বিষয় বিশ্লেষণ করো। ছবিতে নেই এমন "
                + "ঘটনা, পরিচয়, পণ্য, স্থান, ফলাফল বা দাবি কল্পনা করবে না।\n"
                + "শুধু ছবিতে দৃশ্যমান অংশ নিয়ে নিশ্চিত হও; অনিশ্চিত বিষয় উল্লেখ করতে হলে তা স্পষ্ট করো।\n"
                + "আউটপুট ভাষা: " + safeLanguage + "\n"
                + "কিওয়ার্ড/প্রেক্ষাপট: " + safeKeywords + "\n"
                + "দর্শক: " + safeAudience + "\n\n";
        String policy;
        if (mode == PlatformMode.FACEBOOK_REELS) {
            policy = "Facebook Reels-এর জন্য সংক্ষিপ্ত, সত্যনিষ্ঠ ও স্বাভাবিক লেখার কনটেন্ট তৈরি করো।\n"
                    + "[TITLE] ঘরে একটি ছোট, প্রাসঙ্গিক Reel Hook লিখবে (এটি বাধ্যতামূলক আলাদা আপলোড Title নয়)।\n"
                    + "[DESCRIPTION] ঘরে ১–৩টি স্বাভাবিক অনুচ্ছেদের আকর্ষণীয় Reel Caption লিখবে।\n"
                    + "[HASHTAGS] ঘরে ৩–৫টি অত্যন্ত প্রাসঙ্গিক, ভিন্ন ভিন্ন hashtag লিখবে; অপ্রাসঙ্গিক trending tag নয়।\n";
        } else if (mode == PlatformMode.FACEBOOK_VIDEO) {
            policy = "Facebook-এ অপেক্ষাকৃত বিস্তারিত ভিডিও পোস্টের জন্য সত্যনিষ্ঠ, সহজপাঠ্য কনটেন্ট তৈরি করো।\n"
                    + "[TITLE] ঘরে একটি সংক্ষিপ্ত বর্ণনামূলক Video Title দাও (প্রকাশের ফর্মে আলাদা title field নাও থাকতে পারে)।\n"
                    + "[DESCRIPTION] ঘরে একটি প্রাসঙ্গিক Video Caption/Description লিখবে, প্রথমে মূল বিষয় থাকবে।\n"
                    + "[HASHTAGS] ঘরে ৩–৫টি প্রাসঙ্গিক, ভিন্ন ভিন্ন hashtag লিখবে; tag-stuffing নয়।\n";
        } else {
            policy = "YouTube ভিডিওর জন্য একটি সত্যনিষ্ঠ, সার্চ-ফ্রেন্ডলি Title ও বিস্তারিত Description লিখবে।\n"
                    + "Description-এর শুরুতে মূল বিষয় রাখবে এবং শেষে প্রাসঙ্গিক CTA যুক্ত করতে পারো।\n"
                    + "[HASHTAGS] ঘরে ৮–১২টি প্রাসঙ্গিক hashtag লিখবে।\n";
        }
        String metaRules = mode.isFacebook()
                ? "Meta/Facebook ভালো অনুশীলন: অরিজিনাল কনটেন্টের গুরুত্ব বোঝাও; কপিরাইটযুক্ত ভিডিও/মিউজিক "
                    + "ব্যবহারের অনুমতি আছে এমন দাবি তৈরি করবে না। অন্যের ভিডিও নিজের দাবি করে লিখবে না। "
                    + "মিথ্যা তথ্য, বিভ্রান্তিকর শিরোনাম, guaranteed reach/viral/monetization, প্রতারণা, "
                    + "engagement bait (লাইক/শেয়ার/কমেন্ট করতে বাধ্য করে এমন ভাষা), অতিরিক্ত emoji, "
                    + "অপ্রাসঙ্গিক hashtag এবং অপ্রাসঙ্গিক লিংক লিখবে না। "
                    + "প্রাসঙ্গিক স্বাভাবিক CTA গ্রহণযোগ্য, কিন্তু engagement-manipulation নয়। "
                    + "অন্যের ট্রেডমার্ক/পরিচয় ভান করবে না। তথ্য/মূল কনটেন্ট কম থাকলে সংযত থাকবে।\n"
                : "ক্লিকবেইট, অপ্রাসঙ্গিক হ্যাশট্যাগ, নিশ্চিত viral/ranking-এর দাবি বা ভুল তথ্য লিখবে না।\n";
        return common + policy + metaRules
                + "শুধু এই ফরম্যাটে উত্তর দেবে, code fence বা বাড়তি ভূমিকাসহ নয়:\n"
                + "[TITLE]\nউপযুক্ত টাইটেল বা হুক\n\n"
                + "[DESCRIPTION]\nউপযুক্ত ডেসক্রিপশন বা ক্যাপশন\n\n"
                + "[HASHTAGS]\n#tag1 #tag2 ...";
    }

    private static String value(String input, String fallback) {
        return input == null || input.trim().isEmpty() ? fallback : input.trim();
    }
}
