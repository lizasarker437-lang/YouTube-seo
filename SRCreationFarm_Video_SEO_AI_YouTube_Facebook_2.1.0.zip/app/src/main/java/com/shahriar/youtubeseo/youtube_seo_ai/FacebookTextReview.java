package com.shahriar.youtubeseo.youtube_seo_ai;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Mechanical checks only. This is not a legal or Meta policy-compliance certification. */
public final class FacebookTextReview {
    private static final Pattern HASHTAG = Pattern.compile("#[\\p{L}\\p{M}\\p{N}_]+", Pattern.UNICODE_CHARACTER_CLASS);

    private FacebookTextReview() {}

    public static String tidyHashtags(String input, PlatformMode platform) {
        if (input == null) return "";
        int limit = platform != null && platform.isFacebook() ? 5 : 15;
        Set<String> tags = new LinkedHashSet<>();
        Matcher matcher = HASHTAG.matcher(input);
        while (matcher.find() && tags.size() < limit) {
            String tag = matcher.group();
            boolean alreadySeen = false;
            for (String current : tags) {
                if (current.equalsIgnoreCase(tag)) { alreadySeen = true; break; }
            }
            if (!alreadySeen) tags.add(tag);
        }
        return String.join(" ", tags);
    }

    public static String getReviewReminder(PlatformMode platform) {
        if (platform == null || !platform.isFacebook()) return "";
        return "পোস্টের আগে নিশ্চিত করুন: ভিডিও/মিউজিক ব্যবহারের অধিকার আছে, "
                + "Caption দৃশ্যের সঙ্গে মিলছে, দাবি সত্য, এবং কোনো অপ্রাসঙ্গিক hashtag বা engagement bait নেই। "
                + "এই অ্যাপ স্বয়ংক্রিয়ভাবে Meta অনুমোদন যাচাই করতে পারে না।";
    }
}
