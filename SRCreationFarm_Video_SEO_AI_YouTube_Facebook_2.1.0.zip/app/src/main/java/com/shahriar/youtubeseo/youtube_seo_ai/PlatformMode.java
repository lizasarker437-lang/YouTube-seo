package com.shahriar.youtubeseo.youtube_seo_ai;

/** Content-writing modes. Meta's current posting system can display Facebook videos as Reels;
 * the two Facebook modes are distinct writing styles, not separate upload APIs. */
public enum PlatformMode {
    YOUTUBE("youtube", "YouTube", "YouTube Title", "Video Description", "Hashtags"),
    FACEBOOK_REELS("facebook_reels", "FB Reels", "Reel Hook", "Reel Caption", "Hashtags"),
    FACEBOOK_VIDEO("facebook_video", "FB Video", "Video Title", "Video Caption", "Hashtags");

    public final String id;
    public final String label;
    public final String titleLabel;
    public final String descriptionLabel;
    public final String hashtagLabel;

    PlatformMode(String id, String label, String titleLabel, String descriptionLabel, String hashtagLabel) {
        this.id = id;
        this.label = label;
        this.titleLabel = titleLabel;
        this.descriptionLabel = descriptionLabel;
        this.hashtagLabel = hashtagLabel;
    }

    public boolean isFacebook() {
        return this != YOUTUBE;
    }

    public static PlatformMode fromId(String id) {
        if (id != null) {
            for (PlatformMode mode : values()) {
                if (mode.id.equals(id)) return mode;
            }
        }
        return YOUTUBE;
    }
}
