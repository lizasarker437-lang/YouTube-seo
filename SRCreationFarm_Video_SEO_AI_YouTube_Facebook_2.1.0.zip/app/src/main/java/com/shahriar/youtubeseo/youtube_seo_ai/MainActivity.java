package com.shahriar.youtubeseo.youtube_seo_ai;

import android.content.ClipData;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_IMAGES = 4102;
    private static final String YOUTUBE_URL = "https://www.youtube.com/@SRCreation-farm";
    private static final String FACEBOOK_URL = "https://fb.com/srcreation.farm";

    private final ArrayList<Uri> selectedImages = new ArrayList<>();
    private final ArrayList<TextView> platformTabs = new ArrayList<>();
    private PlatformMode selectedPlatform = PlatformMode.YOUTUBE;
    private TextView platformDescription;
    private TextView titleSectionLabel;
    private TextView descriptionSectionLabel;
    private TextView hashtagsSectionLabel;
    private TextView resultPolicyNote;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private SecureKeyStore secureKeyStore;
    private HistoryStore historyStore;
    private ThemeManager.Palette palette;

    private LinearLayout root;
    private LinearLayout content;
    private LinearLayout resultPanel;
    private TextView screenshotCounter;
    private TextView errorView;
    private MaterialButton generateButton;
    private CircularProgressIndicator progressIndicator;
    private Spinner languageSpinner;
    private TextInputEditText keywordInput;
    private TextInputEditText audienceInput;
    private TextInputEditText titleOutput;
    private TextInputEditText descriptionOutput;
    private TextInputEditText hashtagsOutput;

    private final ImageView[] screenshotViews = new ImageView[3];
    private final TextView[] screenshotPlaceholders = new TextView[3];
    private final View[] screenshotRemoveButtons = new View[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyMode(this);
        super.onCreate(savedInstanceState);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        secureKeyStore = new SecureKeyStore(this);
        historyStore = new HistoryStore(this);
        palette = ThemeManager.getPalette(this);
        selectedPlatform = PlatformMode.fromId(
                appPreferences().getString("platform_mode", PlatformMode.YOUTUBE.id));
        applySystemBars();

        buildUi();
        if (savedInstanceState != null) restoreState(savedInstanceState);
    }

    private void applySystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(palette.background);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        int flags = palette.dark ? 0
                : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        window.getDecorView().setSystemUiVisibility(flags);
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(palette.background);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return insets;
        });

        MaterialToolbar toolbar = new MaterialToolbar(this);
        toolbar.setTitle("Video SEO AI");
        toolbar.setTitleTextColor(palette.text);
        toolbar.setBackgroundColor(palette.surface);
        toolbar.setNavigationIcon(R.mipmap.ic_launcher);
        toolbar.setNavigationContentDescription("About SR Creation Farm");
        toolbar.setNavigationOnClickListener(view -> showAboutDeveloper());
        toolbar.setElevation(dp(2));
        MenuItem more = toolbar.getMenu().add(0, 1, 0, "More");
        more.setIcon(android.R.drawable.ic_menu_more);
        more.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        toolbar.setOnMenuItemClickListener(item -> {
            View anchor = toolbar.getChildCount() == 0
                    ? toolbar : toolbar.getChildAt(toolbar.getChildCount() - 1);
            showOverflowMenu(anchor);
            return true;
        });
        root.addView(toolbar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setClipToPadding(false);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(14), dp(16), dp(28));
        scrollView.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scrollView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        addHeroCard();
        addSectionHeading("কনটেন্ট প্ল্যাটফর্ম", "YouTube, Facebook Reels বা Facebook Video বেছে নিন");
        addPlatformSelector();
        addSectionHeading("ভিডিও স্ক্রিনশট", "ভিডিওর ৩টি গুরুত্বপূর্ণ দৃশ্য নির্বাচন করুন");
        addScreenshotPicker();
        addSectionHeading("কনটেন্ট সেটিংস", "আরও নির্ভুল SEO ফলাফলের জন্য তথ্য দিন");
        addLanguageSelector();
        keywordInput = addInputField("ভিডিওর বিষয় / কিওয়ার্ড (ঐচ্ছিক)",
                "যেমন: গ্রামের জীবন, Android tips, cooking", 1, 2);
        audienceInput = addInputField("টার্গেট দর্শক (ঐচ্ছিক)",
                "যেমন: বাংলা ভাষার দর্শক, নতুন YouTuber", 1, 2);

        generateButton = new MaterialButton(this);
        generateButton.setText("SEO কনটেন্ট তৈরি করুন");
        generateButton.setTextSize(15);
        generateButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        generateButton.setIconResource(android.R.drawable.ic_menu_search);
        generateButton.setIconTint(ColorStateList.valueOf(Color.WHITE));
        generateButton.setBackgroundTintList(ColorStateList.valueOf(palette.primary));
        generateButton.setTextColor(Color.WHITE);
        generateButton.setCornerRadius(dp(16));
        generateButton.setAllCaps(false);
        generateButton.setOnClickListener(view -> generateSeo());
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        buttonParams.topMargin = dp(10);
        content.addView(generateButton, buttonParams);

        progressIndicator = new CircularProgressIndicator(this);
        progressIndicator.setIndicatorColor(palette.primary, palette.accent);
        progressIndicator.setTrackColor(palette.outline);
        progressIndicator.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(34), dp(34));
        progressParams.gravity = Gravity.CENTER_HORIZONTAL;
        progressParams.topMargin = dp(16);
        content.addView(progressIndicator, progressParams);

        errorView = text("", 13, palette.muted, false);
        errorView.setVisibility(View.GONE);
        errorView.setPadding(dp(12), dp(10), dp(12), dp(10));
        errorView.setBackground(roundDrawable(palette.dark
                ? Color.rgb(72, 35, 43) : Color.rgb(255, 235, 237), dp(12)));
        LinearLayout.LayoutParams errorParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        errorParams.topMargin = dp(12);
        content.addView(errorView, errorParams);

        resultPanel = new LinearLayout(this);
        resultPanel.setOrientation(LinearLayout.VERTICAL);
        resultPanel.setVisibility(View.GONE);
        LinearLayout.LayoutParams resultParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        resultParams.topMargin = dp(22);
        content.addView(resultPanel, resultParams);
        buildResultPanel();
        updatePlatformUi();

        addDeveloperFooter();
    }

    private void addHeroCard() {
        MaterialCardView card = card();
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        hero.setBackground(new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{palette.dark ? Color.rgb(27, 48, 79) : Color.rgb(226, 236, 251),
                        palette.dark ? Color.rgb(39, 31, 62) : Color.rgb(246, 231, 237)}));
        TextView eyebrow = text("SR CREATION FARM  •  AI CONTENT STUDIO", 10,
                palette.dark ? palette.accent : palette.primary, true);
        hero.addView(eyebrow);

        TextView title = text("One app. Three content modes.", 23, palette.text, true);
        title.setPadding(0, dp(10), 0, dp(5));
        hero.addView(title);

        TextView subtitle = text(
                "YouTube এবং Facebook-এর জন্য আলাদা AI Title, Caption ও Hashtags তৈরি করুন।",
                13, palette.muted, false);
        subtitle.setLineSpacing(dp(3), 1f);
        hero.addView(subtitle);

        TextView credit = text("Developed by Shahriar Rahman", 11, palette.muted, true);
        credit.setPadding(0, dp(14), 0, 0);
        hero.addView(credit);
        card.addView(hero);
        addCardToContent(card, 0, 0, 18);
    }

    private void addPlatformSelector() {
        MaterialCardView selectorCard = card();
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setPadding(dp(10), dp(12), dp(10), dp(12));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        PlatformMode[] modes = PlatformMode.values();
        for (int i = 0; i < modes.length; i++) {
            final PlatformMode target = modes[i];
            TextView tab = text(target.label, 12, palette.text, true);
            tab.setGravity(Gravity.CENTER);
            tab.setContentDescription("Select " + target.label);
            tab.setFocusable(true);
            tab.setClickable(true);
            tab.setPadding(dp(3), dp(9), dp(3), dp(9));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(46), 1f);
            if (i > 0) params.leftMargin = dp(6);
            row.addView(tab, params);
            tab.setOnClickListener(v -> selectPlatform(target));
            platformTabs.add(tab);
        }
        wrapper.addView(row);
        platformDescription = text("", 11, palette.muted, false);
        platformDescription.setLineSpacing(dp(2), 1f);
        platformDescription.setPadding(dp(5), dp(12), dp(5), dp(5));
        wrapper.addView(platformDescription);

        MaterialButton details = smallButton("Facebook Rules & Tips");
        details.setOnClickListener(v -> showFacebookGuidelines());
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(37));
        hintParams.gravity = Gravity.END;
        wrapper.addView(details, hintParams);

        selectorCard.addView(wrapper);
        addCardToContent(selectorCard, 0, 0, 0);
        updatePlatformUi();
    }

    private void selectPlatform(PlatformMode mode) {
        if (mode == selectedPlatform) return;
        if (progressIndicator != null && progressIndicator.getVisibility() == View.VISIBLE) {
            showMessage("AI বিশ্লেষণ শেষ হলে প্ল্যাটফর্ম পরিবর্তন করুন।");
            return;
        }
        selectedPlatform = mode;
        appPreferences().edit().putString("platform_mode", mode.id).apply();
        if (resultPanel != null) resultPanel.setVisibility(View.GONE);
        updatePlatformUi();
    }

    private void updatePlatformUi() {
        PlatformMode[] modes = PlatformMode.values();
        for (int i = 0; i < platformTabs.size() && i < modes.length; i++) {
            boolean selected = selectedPlatform == modes[i];
            TextView tab = platformTabs.get(i);
            tab.setTextColor(selected ? Color.WHITE : palette.text);
            GradientDrawable bg = roundDrawable(selected ? palette.primary : palette.surface, dp(12));
            bg.setStroke(dp(1), selected ? palette.primary : palette.outline);
            tab.setBackground(bg);
        }
        if (platformDescription != null) {
            String description;
            if (selectedPlatform == PlatformMode.FACEBOOK_REELS) {
                description = "Facebook Reels: ছোট Hook, স্বাভাবিক Caption এবং ৩–৫টি প্রাসঙ্গিক Hashtags।";
            } else if (selectedPlatform == PlatformMode.FACEBOOK_VIDEO) {
                description = "Facebook Video: বর্ণনামূলক Title ও বিস্তারিত Caption। Facebook এখন নতুন ভিডিওকে Reels হিসেবেও দেখাতে পারে।";
            } else {
                description = "YouTube: সার্চ-ফ্রেন্ডলি Title, বিস্তারিত Description ও Hashtags।";
            }
            platformDescription.setText(description);
        }
        if (titleSectionLabel != null) titleSectionLabel.setText(selectedPlatform.titleLabel);
        if (descriptionSectionLabel != null) descriptionSectionLabel.setText(selectedPlatform.descriptionLabel);
        if (hashtagsSectionLabel != null) hashtagsSectionLabel.setText(selectedPlatform.hashtagLabel);
        if (resultPolicyNote != null) {
            if (selectedPlatform.isFacebook()) {
                resultPolicyNote.setText(FacebookTextReview.getReviewReminder(selectedPlatform));
                resultPolicyNote.setVisibility(View.VISIBLE);
            } else {
                resultPolicyNote.setVisibility(View.GONE);
            }
        }
        if (generateButton != null) {
            generateButton.setText(selectedPlatform.isFacebook()
                    ? "Facebook Caption তৈরি করুন" : "YouTube SEO তৈরি করুন");
        }
    }

    private void showFacebookGuidelines() {
        new AlertDialog.Builder(this)
                .setTitle("Facebook Content Rules & Tips")
                .setMessage("Meta-এর প্রকাশিত নির্দেশনা অনুযায়ী নিরাপদ কনটেন্ট তৈরির পরামর্শ:\n\n"
                        + "• নিজের তৈরি বা অনুমোদিত ভিডিও/অডিও ব্যবহার করুন।\n"
                        + "• অন্যের ভিডিওতে সামান্য পরিবর্তন করে নিজের Original Content দাবি করবেন না।\n"
                        + "• Caption, Title ও Hashtags অবশ্যই ভিডিওর সঙ্গে প্রাসঙ্গিক রাখুন।\n"
                        + "• অতিরিক্ত Hashtags, মিথ্যা দাবি, Clickbait ও Engagement Bait এড়িয়ে চলুন।\n"
                        + "• ৩–৫টি প্রাসঙ্গিক Hashtags একটি ভালো লেখার পদ্ধতি; এটি কোনো বাধ্যতামূলক Meta সীমা নয়।\n"
                        + "• Facebook-এর নতুন ভিডিও অনেক ক্ষেত্রে Reels হিসেবে প্রকাশিত হয়; এখানে Reels এবং Video আলাদা লেখার ধরণ।\n\n"
                        + "অ্যাপটি কোনো পোস্টের Meta Approval, Reach বা Monetization নিশ্চিত করতে পারে না।")
                .setNeutralButton("Meta Guidelines", (dialog, which) ->
                        openExternal("https://about.fb.com/news/2026/03/rewarding-original-creators-on-facebook/"))
                .setPositiveButton("OK", null)
                .show();
    }

    private void addSectionHeading(String title, String subtitle) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        TextView heading = text(title, 17, palette.text, true);
        TextView sub = text(subtitle, 11, palette.muted, false);
        sub.setPadding(0, dp(3), 0, 0);
        block.addView(heading);
        block.addView(sub);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(20);
        params.bottomMargin = dp(10);
        content.addView(block, params);
    }

    private void addScreenshotPicker() {
        MaterialCardView card = card();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(10));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 3; i++) {
            final int index = i;
            FrameLayout tile = new FrameLayout(this);
            LinearLayout.LayoutParams tileParams = new LinearLayout.LayoutParams(
                    0, dp(104), 1f);
            if (i > 0) tileParams.leftMargin = dp(8);
            tile.setBackground(roundDrawable(palette.card, dp(13)));
            tile.setClipToOutline(true);

            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setVisibility(View.GONE);
            screenshotViews[i] = image;
            tile.addView(image, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView placeholder = text("＋\nScreenshot " + (i + 1), 11, palette.muted, true);
            placeholder.setGravity(Gravity.CENTER);
            screenshotPlaceholders[i] = placeholder;
            tile.addView(placeholder, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView remove = text("×", 19, Color.WHITE, true);
            remove.setGravity(Gravity.CENTER);
            remove.setBackground(roundDrawable(Color.argb(205, 12, 17, 27), dp(18)));
            FrameLayout.LayoutParams removeParams = new FrameLayout.LayoutParams(dp(28), dp(28),
                    Gravity.TOP | Gravity.END);
            removeParams.setMargins(0, dp(4), dp(4), 0);
            remove.setVisibility(View.GONE);
            remove.setOnClickListener(v -> {
                if (index < selectedImages.size()) {
                    selectedImages.remove(index);
                    updateScreenshotTiles();
                }
            });
            screenshotRemoveButtons[i] = remove;
            tile.addView(remove, removeParams);
            tile.setOnClickListener(v -> openImagePicker());
            row.addView(tile, tileParams);
        }
        box.addView(row);

        screenshotCounter = text("০/৩টি স্ক্রিনশট নির্বাচিত", 11, palette.muted, false);
        screenshotCounter.setPadding(0, dp(10), 0, dp(7));
        box.addView(screenshotCounter);

        MaterialButton choose = new MaterialButton(this);
        choose.setText("গ্যালারি থেকে স্ক্রিনশট নির্বাচন");
        choose.setIconResource(android.R.drawable.ic_menu_gallery);
        choose.setIconTint(ColorStateList.valueOf(palette.primary));
        choose.setTextColor(palette.text);
        choose.setBackgroundTintList(ColorStateList.valueOf(palette.dark
                ? Color.rgb(31, 46, 70) : Color.rgb(236, 241, 249)));
        choose.setCornerRadius(dp(12));
        choose.setAllCaps(false);
        choose.setOnClickListener(v -> openImagePicker());
        box.addView(choose, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        TextView note = text("AI বিশ্লেষণের জন্য ঠিক ৩টি স্ক্রিনশট প্রয়োজন।", 10,
                palette.muted, false);
        note.setPadding(0, dp(7), 0, 0);
        box.addView(note);

        card.addView(box);
        addCardToContent(card, 0, 0, 0);
    }

    private void addLanguageSelector() {
        TextView label = text("আউটপুটের ভাষা", 12, palette.muted, true);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        labelParams.topMargin = dp(2);
        labelParams.bottomMargin = dp(6);
        content.addView(label, labelParams);

        languageSpinner = new Spinner(this);
        String[] languages = {"বাংলা", "English", "বাংলা + English"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, languages) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView item = (TextView) super.getView(position, convertView, parent);
                item.setTextColor(palette.text);
                item.setTextSize(14);
                return item;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView item = (TextView) super.getDropDownView(position, convertView, parent);
                item.setTextColor(palette.text);
                item.setBackgroundColor(palette.surface);
                item.setPadding(dp(12), dp(10), dp(12), dp(10));
                return item;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(adapter);
        languageSpinner.setSelection(appPreferences().getInt("language_index", 0));
        languageSpinner.setBackground(roundDrawable(palette.surface, dp(12)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        params.bottomMargin = dp(12);
        content.addView(languageSpinner, params);
        languageSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view,
                                                 int position, long id) {
                appPreferences().edit().putInt("language_index", position).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }

    private TextInputEditText addInputField(String hint, String helper, int minLines, int maxLines) {
        TextInputLayout layout = new TextInputLayout(this);
        layout.setHint(hint);
        layout.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);
        layout.setBoxStrokeColor(palette.outline);
        layout.setDefaultHintTextColor(ColorStateList.valueOf(palette.muted));
        layout.setHintTextColor(ColorStateList.valueOf(palette.muted));

        TextInputEditText input = new TextInputEditText(layout.getContext());
        input.setTextColor(palette.text);
        input.setHintTextColor(palette.muted);
        input.setTextSize(14);
        input.setMinLines(minLines);
        input.setMaxLines(maxLines);
        input.setSingleLine(false);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setPadding(dp(12), dp(12), dp(12), dp(12));
        layout.addView(input, new TextInputLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(12);
        content.addView(layout, params);

        TextView helperView = text(helper, 10, palette.muted, false);
        LinearLayout.LayoutParams helperParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        helperParams.topMargin = dp(-7);
        helperParams.bottomMargin = dp(12);
        content.addView(helperView, helperParams);
        return input;
    }

    private void buildResultPanel() {
        MaterialCardView resultCard = card();
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setPadding(dp(14), dp(14), dp(14), dp(14));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = text("আপনার SEO ফলাফল", 18, palette.text, true);
        titleRow.addView(heading, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        MaterialButton copyAll = smallButton("সব কপি");
        copyAll.setIconResource(android.R.drawable.ic_menu_save);
        copyAll.setOnClickListener(v -> copyAllResults());
        titleRow.addView(copyAll);
        wrapper.addView(titleRow);

        TextView hint = text("প্রয়োজনে প্রতিটি লেখা সরাসরি এডিট করতে পারবেন।", 11,
                palette.muted, false);
        hint.setPadding(0, dp(3), 0, dp(12));
        wrapper.addView(hint);

        titleOutput = addResultField(wrapper, "YouTube Title", 2, 4);
        descriptionOutput = addResultField(wrapper, "Video Description", 5, 12);
        hashtagsOutput = addResultField(wrapper, "Hashtags", 2, 5);
        resultPolicyNote = text("", 11, palette.muted, false);
        resultPolicyNote.setLineSpacing(dp(2), 1f);
        resultPolicyNote.setPadding(dp(4), dp(4), dp(4), dp(8));
        wrapper.addView(resultPolicyNote);
        resultCard.addView(wrapper);
        resultPanel.addView(resultCard);
    }

    private TextInputEditText addResultField(LinearLayout parent, String label,
                                              int minLines, int maxLines) {
        LinearLayout headingRow = new LinearLayout(this);
        headingRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text(label, 13, palette.text, true);
        if ("YouTube Title".equals(label)) titleSectionLabel = title;
        else if ("Video Description".equals(label)) descriptionSectionLabel = title;
        else hashtagsSectionLabel = title;
        headingRow.addView(title, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        MaterialButton copy = smallButton("Copy");
        headingRow.addView(copy);
        parent.addView(headingRow);

        TextInputLayout layout = new TextInputLayout(this);
        layout.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);
        layout.setBoxStrokeColor(palette.outline);
        layout.setHintTextColor(ColorStateList.valueOf(palette.muted));
        TextInputEditText field = new TextInputEditText(this);
        field.setTextColor(palette.text);
        field.setHintTextColor(palette.muted);
        field.setTextSize(13);
        field.setMinLines(minLines);
        field.setMaxLines(maxLines);
        field.setSingleLine(false);
        field.setGravity(Gravity.TOP | Gravity.START);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        layout.addView(field, new TextInputLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams fieldParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fieldParams.topMargin = dp(5);
        fieldParams.bottomMargin = dp(13);
        parent.addView(layout, fieldParams);

        copy.setOnClickListener(v -> copyText(field.getText() == null ? "" :
                field.getText().toString(), title.getText().toString()));
        return field;
    }

    private void addDeveloperFooter() {
        TextView footer = text("SR Creation Farm  •  Developed by Shahriar Rahman\nAbout Developer  ·  Version " + BuildConfig.VERSION_NAME,
                10, palette.muted, false);
        footer.setGravity(Gravity.CENTER);
        footer.setLineSpacing(dp(3), 1f);
        footer.setPadding(0, dp(22), 0, dp(4));
        footer.setOnClickListener(v -> showAboutDeveloper());
        content.addView(footer);
    }

    private MaterialCardView card() {
        MaterialCardView card = new MaterialCardView(this);
        card.setCardBackgroundColor(palette.card);
        card.setStrokeColor(palette.outline);
        card.setStrokeWidth(dp(1));
        card.setRadius(dp(18));
        card.setCardElevation(dp(2));
        card.setUseCompatPadding(true);
        return card;
    }

    private void addCardToContent(MaterialCardView card, int left, int top, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.leftMargin = dp(left);
        params.topMargin = dp(top);
        params.bottomMargin = dp(bottom);
        content.addView(card, params);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private MaterialButton smallButton(String label) {
        MaterialButton button = new MaterialButton(this);
        button.setText(label);
        button.setTextSize(10);
        button.setTextColor(palette.primary);
        button.setBackgroundTintList(ColorStateList.valueOf(palette.dark
                ? Color.rgb(31, 45, 68) : Color.rgb(236, 241, 249)));
        button.setCornerRadius(dp(10));
        button.setAllCaps(false);
        button.setInsetTop(0);
        button.setInsetBottom(0);
        button.setMinHeight(dp(34));
        button.setMinimumHeight(dp(34));
        return button;
    }

    private GradientDrawable roundDrawable(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_IMAGES);
        } catch (Exception error) {
            showMessage("গ্যালারি খোলা যায়নি। অন্য ফাইল পিকার ব্যবহার করে দেখুন।");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_IMAGES || resultCode != RESULT_OK || data == null) return;

        ArrayList<Uri> incoming = new ArrayList<>();
        boolean truncated = false;
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri uri = clip.getItemAt(i).getUri();
                if (uri != null && !incoming.contains(uri)) {
                    if (incoming.size() == 3) {
                        truncated = true;
                        break;
                    }
                    incoming.add(uri);
                }
            }
        } else if (data.getData() != null) {
            incoming.add(data.getData());
        }

        if (truncated) showMessage("সর্বোচ্চ ৩টি ছবি নেওয়া হয়েছে।");
        selectedImages.clear();
        for (Uri uri : incoming) {
            try {
                getContentResolver().takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
                // The URI can still be used for the current activity session.
            }
            selectedImages.add(uri);
        }
        updateScreenshotTiles();
    }

    private void updateScreenshotTiles() {
        for (int i = 0; i < 3; i++) {
            if (i < selectedImages.size()) {
                screenshotViews[i].setImageURI(selectedImages.get(i));
                screenshotViews[i].setVisibility(View.VISIBLE);
                screenshotPlaceholders[i].setVisibility(View.GONE);
                screenshotRemoveButtons[i].setVisibility(View.VISIBLE);
            } else {
                screenshotViews[i].setImageDrawable(null);
                screenshotViews[i].setVisibility(View.GONE);
                screenshotPlaceholders[i].setVisibility(View.VISIBLE);
                screenshotRemoveButtons[i].setVisibility(View.GONE);
            }
        }
        if (screenshotCounter != null) {
            String[] banglaDigits = {"০", "১", "২", "৩"};
            screenshotCounter.setText(banglaDigits[selectedImages.size()] + "/৩টি স্ক্রিনশট নির্বাচিত");
        }
    }

    private void generateSeo() {
        String apiKey = secureKeyStore.read();
        if (apiKey.isEmpty()) {
            showApiKeyDialog();
            return;
        }
        if (selectedImages.size() != 3) {
            showMessage("AI বিশ্লেষণের আগে ঠিক ৩টি স্ক্রিনশট নির্বাচন করুন।");
            return;
        }

        final String language = languageSpinner.getSelectedItem() == null
                ? "বাংলা" : languageSpinner.getSelectedItem().toString();
        final String keywords = keywordInput.getText() == null
                ? "" : keywordInput.getText().toString().trim();
        final String audience = audienceInput.getText() == null
                ? "" : audienceInput.getText().toString().trim();
        final ArrayList<Uri> images = new ArrayList<>(selectedImages);
        final PlatformMode requestPlatform = selectedPlatform;

        setLoading(true);
        errorView.setVisibility(View.GONE);
        resultPanel.setVisibility(View.GONE);

        executor.execute(() -> {
            try {
                String output = GeminiClient.generate(
                        getApplicationContext(), apiKey, images, language, keywords, audience,
                        requestPlatform);
                SeoParser.Result rawResult = SeoParser.parse(output);
                SeoParser.Result result = new SeoParser.Result(rawResult.title,
                        rawResult.description,
                        FacebookTextReview.tidyHashtags(rawResult.hashtags, requestPlatform));
                historyStore.add(result, requestPlatform);
                mainHandler.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    selectedPlatform = requestPlatform;
                    updatePlatformUi();
                    titleOutput.setText(result.title);
                    descriptionOutput.setText(result.description);
                    hashtagsOutput.setText(result.hashtags);
                    resultPanel.setVisibility(View.VISIBLE);
                    setLoading(false);
                    resultPanel.requestFocus();
                });
            } catch (Exception error) {
                String message = error.getMessage() == null
                        ? "অজানা সমস্যা হয়েছে। আবার চেষ্টা করুন।" : error.getMessage();
                mainHandler.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    errorView.setText(message);
                    errorView.setVisibility(View.VISIBLE);
                    setLoading(false);
                });
            }
        });
    }

    private void setLoading(boolean loading) {
        generateButton.setEnabled(!loading);
        generateButton.setAlpha(loading ? 0.65f : 1f);
        generateButton.setText(loading ? "AI বিশ্লেষণ করছে..."
                : selectedPlatform.isFacebook() ? "Facebook Caption তৈরি করুন"
                : "YouTube SEO তৈরি করুন");
        progressIndicator.setVisibility(loading ? View.VISIBLE : View.GONE);
    }

    private void copyText(String value, String label) {
        if (value == null || value.trim().isEmpty()) {
            showMessage(label + " কপি করার মতো কোনো লেখা নেই।");
            return;
        }
        android.content.ClipboardManager clipboard =
                (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText(label, value));
        showMessage(label + " কপি হয়েছে।");
    }

    private void copyAllResults() {
        String title = titleOutput.getText() == null ? "" : titleOutput.getText().toString().trim();
        String description = descriptionOutput.getText() == null ? "" :
                descriptionOutput.getText().toString().trim();
        String hashtags = hashtagsOutput.getText() == null ? "" :
                hashtagsOutput.getText().toString().trim();
        StringBuilder all = new StringBuilder();
        if (!title.isEmpty()) all.append(title);
        if (!description.isEmpty()) {
            if (all.length() > 0) all.append("\n\n");
            all.append(description);
        }
        if (!hashtags.isEmpty()) {
            if (all.length() > 0) all.append("\n\n");
            all.append(hashtags);
        }
        copyText(all.toString(), "সম্পূর্ণ SEO কনটেন্ট");
    }

    private void showOverflowMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add(0, 1, 0, "Settings");
        popup.getMenu().add(0, 2, 1, "History");
        popup.getMenu().add(0, 3, 2, "About Developer");
        popup.getMenu().add(0, 4, 3, "Privacy Information");
        popup.getMenu().add(0, 5, 4, "Facebook Content Guidelines");
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: showSettings(); return true;
                case 2: showHistory(); return true;
                case 3: showAboutDeveloper(); return true;
                case 4: showPrivacyInformation(); return true;
                case 5: showFacebookGuidelines(); return true;
                default: return false;
            }
        });
        popup.show();
    }

    private void showSettings() {
        String[] options = {
                "Gemini API Key",
                "Appearance Mode",
                "Color Theme",
                "About Developer",
                "Privacy Information",
                "Facebook Content Guidelines",
                "Clear Generation History"
        };
        new AlertDialog.Builder(this)
                .setTitle("Settings")
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0: showApiKeyDialog(); break;
                        case 1: showAppearanceDialog(); break;
                        case 2: showPaletteDialog(); break;
                        case 3: showAboutDeveloper(); break;
                        case 4: showPrivacyInformation(); break;
                        case 5: showFacebookGuidelines(); break;
                        case 6: confirmClearHistory(); break;
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void showApiKeyDialog() {
        TextInputLayout inputLayout = new TextInputLayout(this);
        inputLayout.setHint("Gemini API Key");
        inputLayout.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);
        inputLayout.setBoxStrokeColor(palette.outline);
        TextInputEditText input = new TextInputEditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setText(secureKeyStore.read());
        input.setSingleLine(true);
        inputLayout.addView(input);

        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(dp(20), dp(8), dp(20), dp(4));
        wrapper.addView(inputLayout);

        new AlertDialog.Builder(this)
                .setTitle("Gemini API Key")
                .setMessage("Google AI Studio থেকে পাওয়া API Key দিন। এটি Android Keystore দিয়ে এনক্রিপ্ট করে এই ডিভাইসে রাখা হবে।")
                .setView(wrapper)
                .setPositiveButton("Save", (dialog, which) -> {
                    try {
                        secureKeyStore.save(input.getText() == null ? "" :
                                input.getText().toString());
                        showMessage("API Key নিরাপদভাবে সংরক্ষিত হয়েছে।");
                    } catch (Exception error) {
                        showMessage("API Key সংরক্ষণ করা যায়নি। আবার চেষ্টা করুন।");
                    }
                })
                .setNeutralButton("Remove Key", (dialog, which) -> {
                    try {
                        secureKeyStore.save("");
                        showMessage("API Key মুছে ফেলা হয়েছে।");
                    } catch (Exception error) {
                        showMessage("API Key মুছে ফেলা যায়নি।");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showAppearanceDialog() {
        String[] labels = {"System Default", "Light Mode", "Dark Mode"};
        String current = ThemeManager.getMode(this);
        int selected = ThemeManager.MODE_LIGHT.equals(current) ? 1
                : ThemeManager.MODE_DARK.equals(current) ? 2 : 0;
        new AlertDialog.Builder(this)
                .setTitle("Appearance Mode")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    String mode = which == 1 ? ThemeManager.MODE_LIGHT
                            : which == 2 ? ThemeManager.MODE_DARK : ThemeManager.MODE_SYSTEM;
                    ThemeManager.setMode(this, mode);
                    dialog.dismiss();
                    recreate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPaletteDialog() {
        String[] palettes = {
                "Midnight Gold", "Ocean Blue", "Emerald Green", "Royal Purple",
                "Sunset Coral", "Graphite Cyan", "Rose Quartz", "Arctic Mint", "Light Day"
        };
        String current = ThemeManager.getPaletteName(this);
        int selected = Arrays.asList(palettes).indexOf(current);
        new AlertDialog.Builder(this)
                .setTitle("Choose Color Theme")
                .setSingleChoiceItems(palettes, Math.max(0, selected), (dialog, which) -> {
                    ThemeManager.setPaletteName(this, palettes[which]);
                    dialog.dismiss();
                    recreate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showHistory() {
        List<HistoryStore.Entry> entries = historyStore.getAll();
        if (entries.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Generation History")
                    .setMessage("এখনও কোনো SEO কনটেন্ট তৈরি করা হয়নি।")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }

        String[] labels = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) {
            HistoryStore.Entry entry = entries.get(i);
            String title = entry.title.isEmpty() ? "Untitled SEO result" : entry.title;
            String date = DateFormat.getDateTimeInstance(
                    DateFormat.SHORT, DateFormat.SHORT).format(new Date(entry.createdAt));
            labels[i] = "[" + entry.platform.label + "] " + title + "\n" + date;
        }
        new AlertDialog.Builder(this)
                .setTitle("Recent Generation History")
                .setItems(labels, (dialog, which) -> {
                    HistoryStore.Entry entry = entries.get(which);
                    selectPlatform(entry.platform);
                    titleOutput.setText(entry.title);
                    descriptionOutput.setText(entry.description);
                    hashtagsOutput.setText(entry.hashtags);
                    resultPanel.setVisibility(View.VISIBLE);
                    showMessage("History থেকে ফলাফল ফিরিয়ে আনা হয়েছে।");
                })
                .setPositiveButton("Close", null)
                .setNeutralButton("Clear History", (dialog, which) -> confirmClearHistory())
                .show();
    }

    private void confirmClearHistory() {
        new AlertDialog.Builder(this)
                .setTitle("Clear History?")
                .setMessage("সংরক্ষিত SEO ফলাফলের History মুছে যাবে।")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", (dialog, which) -> {
                    historyStore.clear();
                    showMessage("Generation History মুছে ফেলা হয়েছে।");
                })
                .show();
    }

    private void showAboutDeveloper() {
        LinearLayout about = new LinearLayout(this);
        about.setOrientation(LinearLayout.VERTICAL);
        about.setGravity(Gravity.CENTER_HORIZONTAL);
        about.setPadding(dp(22), dp(12), dp(22), dp(8));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.sr_creation_farm_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        about.addView(logo, new LinearLayout.LayoutParams(dp(112), dp(112)));

        TextView brand = text("SR Creation Farm", 20, palette.text, true);
        brand.setPadding(0, dp(8), 0, dp(2));
        about.addView(brand);
        about.addView(text("Developer: Shahriar Rahman", 13, palette.muted, false));
        about.addView(text("YouTube: @SRCreation-farm", 12, palette.muted, false));
        about.addView(text("Application: Video SEO AI (YouTube + Facebook)", 12, palette.muted, false));

        MaterialButton youtube = new MaterialButton(this);
        youtube.setText("Open YouTube Channel");
        youtube.setIconResource(android.R.drawable.ic_media_play);
        styleSocialButton(youtube);
        youtube.setOnClickListener(v -> openExternal(YOUTUBE_URL));
        LinearLayout.LayoutParams socialParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        socialParams.topMargin = dp(15);
        about.addView(youtube, socialParams);

        MaterialButton facebook = new MaterialButton(this);
        facebook.setText("Open Facebook Page");
        facebook.setIconResource(android.R.drawable.ic_menu_share);
        styleSocialButton(facebook);
        facebook.setOnClickListener(v -> openExternal(FACEBOOK_URL));
        LinearLayout.LayoutParams fbParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        fbParams.topMargin = dp(8);
        about.addView(facebook, fbParams);

        TextView version = text("Version " + BuildConfig.VERSION_NAME
                + "  •  © 2026 SR Creation Farm", 10, palette.muted, false);
        version.setGravity(Gravity.CENTER);
        version.setPadding(0, dp(14), 0, dp(2));
        about.addView(version);

        new AlertDialog.Builder(this)
                .setTitle("About Developer")
                .setView(about)
                .setPositiveButton("Close", null)
                .show();
    }

    private void styleSocialButton(MaterialButton button) {
        button.setAllCaps(false);
        button.setCornerRadius(dp(12));
        button.setBackgroundTintList(ColorStateList.valueOf(palette.primary));
        button.setTextColor(Color.WHITE);
        button.setIconTint(ColorStateList.valueOf(Color.WHITE));
    }

    private void showPrivacyInformation() {
        new AlertDialog.Builder(this)
                .setTitle("Privacy Information")
                .setMessage("• আপনার Gemini API Key Android Keystore ব্যবহার করে এনক্রিপ্ট করা অবস্থায় ডিভাইসে রাখা হয়।\n\n"
                        + "• নির্বাচিত ৩টি স্ক্রিনশট এবং আপনার দেওয়া কিওয়ার্ড/দর্শক সংক্রান্ত তথ্য সরাসরি Google Gemini API-তে পাঠানো হয়, যাতে SEO ফলাফল তৈরি করা যায়।\n\n"
                        + "• SR Creation Farm-এর নিজস্ব সার্ভারে কোনো ছবি বা API Key পাঠানো হয় না।\n\n"
                        + "• Generation History-তে তৈরি করা Title, Description ও Hashtags স্থানীয়ভাবে সংরক্ষিত হয়। Settings থেকে History মুছতে পারবেন।\n\n"
                        + "• Google-এর API ব্যবহারের শর্ত ও ডেটা নীতি প্রযোজ্য হবে।")
                .setPositiveButton("OK", null)
                .show();
    }

    private void openExternal(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception error) {
            showMessage("লিংকটি খোলা যায়নি।");
        }
    }

    private void showMessage(String message) {
        if (root != null) {
            Snackbar.make(root, message, Snackbar.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    private android.content.SharedPreferences appPreferences() {
        return getSharedPreferences("sr_app_preferences", MODE_PRIVATE);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        String[] uris = new String[selectedImages.size()];
        for (int i = 0; i < selectedImages.size(); i++) uris[i] = selectedImages.get(i).toString();
        outState.putStringArray("selected_image_uris", uris);
        outState.putString("selected_platform", selectedPlatform.id);
        outState.putString("keywords", keywordInput == null || keywordInput.getText() == null
                ? "" : keywordInput.getText().toString());
        outState.putString("audience", audienceInput == null || audienceInput.getText() == null
                ? "" : audienceInput.getText().toString());
        outState.putString("title", titleOutput == null || titleOutput.getText() == null
                ? "" : titleOutput.getText().toString());
        outState.putString("description", descriptionOutput == null || descriptionOutput.getText() == null
                ? "" : descriptionOutput.getText().toString());
        outState.putString("hashtags", hashtagsOutput == null || hashtagsOutput.getText() == null
                ? "" : hashtagsOutput.getText().toString());
        outState.putBoolean("results_visible", resultPanel != null
                && resultPanel.getVisibility() == View.VISIBLE);
    }

    private void restoreState(Bundle state) {
        selectedPlatform = PlatformMode.fromId(state.getString("selected_platform", selectedPlatform.id));
        updatePlatformUi();
        String[] uris = state.getStringArray("selected_image_uris");
        if (uris != null) {
            for (String value : uris) {
                try {
                    selectedImages.add(Uri.parse(value));
                } catch (Exception ignored) {}
            }
            updateScreenshotTiles();
        }
        if (keywordInput != null) keywordInput.setText(state.getString("keywords", ""));
        if (audienceInput != null) audienceInput.setText(state.getString("audience", ""));
        if (titleOutput != null) titleOutput.setText(state.getString("title", ""));
        if (descriptionOutput != null) descriptionOutput.setText(state.getString("description", ""));
        if (hashtagsOutput != null) hashtagsOutput.setText(state.getString("hashtags", ""));
        if (state.getBoolean("results_visible", false)) resultPanel.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
    }
}
