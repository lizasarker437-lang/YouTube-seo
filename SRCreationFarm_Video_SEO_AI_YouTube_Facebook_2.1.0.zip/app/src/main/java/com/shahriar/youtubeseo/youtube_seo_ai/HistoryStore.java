package com.shahriar.youtubeseo.youtube_seo_ai;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class HistoryStore {
    private static final String PREFS = "sr_seo_history";
    private static final String KEY_ENTRIES = "entries";
    private static final int MAX_ENTRIES = 20;

    private final SharedPreferences preferences;

    public HistoryStore(Context context) {
        preferences = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized void add(SeoParser.Result result, PlatformMode platform) {
        if (result == null || result.isEmpty()) return;
        List<Entry> entries = getAll();
        entries.add(0, new Entry(result.title, result.description, result.hashtags,
                System.currentTimeMillis(), platform == null ? PlatformMode.YOUTUBE : platform));
        JSONArray array = new JSONArray();
        for (int i = 0; i < Math.min(entries.size(), MAX_ENTRIES); i++) {
            Entry entry = entries.get(i);
            JSONObject object = new JSONObject();
            try {
                object.put("title", entry.title);
                object.put("description", entry.description);
                object.put("hashtags", entry.hashtags);
                object.put("createdAt", entry.createdAt);
                object.put("platform", entry.platform.id);
                array.put(object);
            } catch (Exception ignored) {
                // A malformed individual history item should not prevent saving other items.
            }
        }
        preferences.edit().putString(KEY_ENTRIES, array.toString()).apply();
    }

    public synchronized List<Entry> getAll() {
        ArrayList<Entry> result = new ArrayList<>();
        String raw = preferences.getString(KEY_ENTRIES, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.optJSONObject(i);
                if (object == null) continue;
                result.add(new Entry(
                        object.optString("title", ""),
                        object.optString("description", ""),
                        object.optString("hashtags", ""),
                        object.optLong("createdAt", 0L),
                        PlatformMode.fromId(object.optString("platform", "youtube"))));
            }
        } catch (Exception ignored) {
            preferences.edit().remove(KEY_ENTRIES).apply();
        }
        return result;
    }

    public synchronized void clear() {
        preferences.edit().remove(KEY_ENTRIES).apply();
    }

    public static final class Entry {
        public final String title;
        public final String description;
        public final String hashtags;
        public final long createdAt;
        public final PlatformMode platform;

        public Entry(String title, String description, String hashtags, long createdAt,
                     PlatformMode platform) {
            this.title = title;
            this.description = description;
            this.hashtags = hashtags;
            this.createdAt = createdAt;
            this.platform = platform == null ? PlatformMode.YOUTUBE : platform;
        }

        public SeoParser.Result toResult() {
            return new SeoParser.Result(title, description, hashtags);
        }
    }
}
