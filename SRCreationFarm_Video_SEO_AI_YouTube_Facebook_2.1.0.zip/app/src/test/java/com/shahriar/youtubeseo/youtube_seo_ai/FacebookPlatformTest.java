package com.shahriar.youtubeseo.youtube_seo_ai;

import org.junit.Test;
import static org.junit.Assert.*;

public class FacebookPlatformTest {
    @Test public void platformIdsRoundtrip() {
        for (PlatformMode mode : PlatformMode.values()) {
            assertEquals(mode, PlatformMode.fromId(mode.id));
        }
    }

    @Test public void previousHistoryWithoutPlatformIsYoutube() {
        assertEquals(PlatformMode.YOUTUBE, PlatformMode.fromId(null));
        assertEquals(PlatformMode.YOUTUBE, PlatformMode.fromId("unknown"));
    }

    @Test public void facebookReelsPromptIsDistinctAndPolicyAware() {
        String prompt = SeoPromptBuilder.build(PlatformMode.FACEBOOK_REELS,
                "বাংলা", "গ্রামের জীবন", "বাংলাদেশের দর্শক");
        assertTrue(prompt.contains("Reel Hook"));
        assertTrue(prompt.contains("engagement bait"));
        assertTrue(prompt.contains("গ্রামের জীবন"));
        assertTrue(prompt.contains("[DESCRIPTION]"));
    }

    @Test public void facebookVideosPromptHasDetailedCaption() {
        String prompt = SeoPromptBuilder.build(PlatformMode.FACEBOOK_VIDEO, "English", "", "");
        assertTrue(prompt.contains("Video Title"));
        assertTrue(prompt.contains("Video Caption"));
        assertTrue(prompt.contains("৩–৫টি"));
    }

    @Test public void youtubeModeIsPreserved() {
        String prompt = SeoPromptBuilder.build(PlatformMode.YOUTUBE, "বাংলা", "", "");
        assertTrue(prompt.contains("YouTube"));
        assertTrue(prompt.contains("৮–১২টি"));
        assertFalse(PlatformMode.YOUTUBE.isFacebook());
    }

    @Test public void facebookHashtagNormalizationCapsDeduplicatesAndSupportsBangla() {
        String result = FacebookTextReview.tidyHashtags(
                "#বাংলা #Bangla #বাংলা #Nature #Travel #Video #Extra #More",
                PlatformMode.FACEBOOK_REELS);
        assertEquals("#বাংলা #Bangla #Nature #Travel #Video", result);
    }

    @Test public void youtubeHashtagsAreNotFacebookLimited() {
        assertEquals("#One #Two #Three #Four #Five #Six",
                FacebookTextReview.tidyHashtags("#One #Two #Three #Four #Five #Six", PlatformMode.YOUTUBE));
    }

    @Test public void facebookReminderDoesNotClaimApproval() {
        String message = FacebookTextReview.getReviewReminder(PlatformMode.FACEBOOK_VIDEO);
        assertTrue(message.contains("অনুমোদন যাচাই করতে পারে না"));
    }
}
