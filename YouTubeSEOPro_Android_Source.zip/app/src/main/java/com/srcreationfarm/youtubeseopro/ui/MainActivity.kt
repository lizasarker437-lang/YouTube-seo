package com.srcreationfarm.youtubeseopro.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.srcreationfarm.youtubeseopro.R
import com.srcreationfarm.youtubeseopro.data.SettingsManager
import com.srcreationfarm.youtubeseopro.databinding.ActivityMainBinding
import com.srcreationfarm.youtubeseopro.model.SeoResult
import com.srcreationfarm.youtubeseopro.network.GeminiSeoService
import com.srcreationfarm.youtubeseopro.utils.ThemeManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settings: SettingsManager
    private val seoService = GeminiSeoService()

    private val screenshotUris = arrayOfNulls<Uri>(3)
    private var activeSlotIndex = 0
    private var appliedThemeName = ""

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            screenshotUris[activeSlotIndex] = uri
            updateSlotPreview(activeSlotIndex, uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        settings = SettingsManager(this)
        appliedThemeName = settings.colorTheme
        ThemeManager.applyTheme(this, settings)
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        setupDropdowns()
        setupListeners()
        refreshApiBanner()
    }

    override fun onResume() {
        super.onResume()
        if (appliedThemeName != settings.colorTheme) {
            recreate()
            return
        }
        refreshApiBanner()
    }

    private fun refreshApiBanner() {
        binding.cardApiWarning.visibility = if (settings.apiKey.isBlank()) View.VISIBLE else View.GONE
    }

    private fun setupDropdowns() {
        val languages = listOf("Bengali (বাংলা)", "English", "Bengali & English Mix")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, languages)
        binding.dropdownLanguage.setAdapter(adapter)
    }

    private fun setupListeners() {
        binding.cardApiWarning.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnQuickSetKey.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.cardShot1.setOnClickListener {
            activeSlotIndex = 0
            pickImageLauncher.launch("image/*")
        }
        binding.cardShot2.setOnClickListener {
            activeSlotIndex = 1
            pickImageLauncher.launch("image/*")
        }
        binding.cardShot3.setOnClickListener {
            activeSlotIndex = 2
            pickImageLauncher.launch("image/*")
        }

        binding.btnGenerate.setOnClickListener {
            generateSeo()
        }

        binding.btnReset.setOnClickListener {
            resetWorkspace()
        }

        binding.btnCopyTitle.setOnClickListener {
            copyText("Title", binding.tvResultTitle.text.toString())
        }
        binding.btnCopyDesc.setOnClickListener {
            copyText("Description", binding.tvResultDesc.text.toString())
        }
        binding.btnCopyTags.setOnClickListener {
            copyText("Hashtags", binding.tvResultTags.text.toString())
        }
    }

    private fun updateSlotPreview(index: Int, uri: Uri?) {
        when (index) {
            0 -> {
                binding.imgShot1.setImageURI(uri)
                binding.txtShot1.visibility = if (uri == null) View.VISIBLE else View.GONE
            }
            1 -> {
                binding.imgShot2.setImageURI(uri)
                binding.txtShot2.visibility = if (uri == null) View.VISIBLE else View.GONE
            }
            2 -> {
                binding.imgShot3.setImageURI(uri)
                binding.txtShot3.visibility = if (uri == null) View.VISIBLE else View.GONE
            }
        }
    }

    private fun resetWorkspace() {
        for (i in 0..2) {
            screenshotUris[i] = null
            updateSlotPreview(i, null)
        }
        binding.etKeyword.setText("")
        binding.layoutResults.visibility = View.GONE
        Toast.makeText(this, "রিসেট সম্পন্ন হয়েছে", Toast.LENGTH_SHORT).show()
    }

    private fun generateSeo() {
        val key = settings.apiKey
        if (key.isBlank()) {
            Toast.makeText(this, "অনুগ্রহ করে আগে Settings থেকে Gemini API Key সেট করুন", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }

        val validUris = screenshotUris.filterNotNull()
        if (validUris.size < 3) {
            Toast.makeText(this, "অনুগ্রহ করে ভিডিওর ৩টি স্ক্রিনশটই নির্বাচন করুন", Toast.LENGTH_SHORT).show()
            return
        }

        val lang = binding.dropdownLanguage.text.toString().ifBlank { "Bengali (বাংলা)" }
        val keyword = binding.etKeyword.text?.toString().orEmpty()

        binding.progressBar.visibility = View.VISIBLE
        binding.btnGenerate.isEnabled = false
        binding.layoutResults.visibility = View.GONE

        lifecycleScope.launch {
            val result = seoService.generateSeoFromScreenshots(
                context = this@MainActivity,
                apiKey = key,
                model = settings.selectedModel,
                imageUris = validUris,
                language = lang,
                keywordHint = keyword
            )

            binding.progressBar.visibility = View.GONE
            binding.btnGenerate.isEnabled = true

            result.onSuccess { parsed ->
                binding.tvResultTitle.text = parsed.title
                binding.tvResultDesc.text = parsed.description
                binding.tvResultTags.text = parsed.hashtags
                binding.layoutResults.visibility = View.VISIBLE

                if (settings.autoSaveHistory) {
                    val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                    settings.addHistory(
                        SeoResult(
                            title = parsed.title,
                            description = parsed.description,
                            hashtags = parsed.hashtags,
                            language = lang,
                            timestamp = dateStr
                        )
                    )
                }
            }.onFailure { err ->
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("বিশ্লেষণ ব্যর্থ হয়েছে")
                    .setMessage(err.message ?: "অজানা ত্রুটি ঘটেছে।")
                    .setPositiveButton("ঠিক আছে", null)
                    .show()
            }
        }
    }

    private fun copyText(label: String, text: String) {
        if (text.isBlank()) return
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, "$label কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_history -> {
                startActivity(Intent(this, HistoryActivity::class.java))
                true
            }
            R.id.action_theme -> {
                showQuickThemeDialog()
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_about -> {
                startActivity(Intent(this, AboutActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showQuickThemeDialog() {
        val themes = ThemeManager.colorThemes.toTypedArray()
        val currentIdx = themes.indexOf(settings.colorTheme).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Select Color Theme")
            .setSingleChoiceItems(themes, currentIdx) { dialog, which ->
                settings.colorTheme = themes[which]
                dialog.dismiss()
                recreate()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
