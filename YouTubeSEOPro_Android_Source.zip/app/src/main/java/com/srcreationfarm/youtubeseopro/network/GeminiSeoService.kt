package com.srcreationfarm.youtubeseopro.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.srcreationfarm.youtubeseopro.utils.SeoResponseParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiSeoService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    suspend fun generateSeoFromScreenshots(
        context: Context,
        apiKey: String,
        model: String,
        imageUris: List<Uri>,
        language: String,
        keywordHint: String
    ): Result<SeoResponseParser.ParsedSeo> = withContext(Dispatchers.IO) {
        try {
            val partsArray = JsonArray()

            val extraInfo = if (keywordHint.isNotBlank()) {
                "অতিরিক্ত কিওয়ার্ড বা বিষয়: $keywordHint"
            } else {
                ""
            }

            val prompt = "তুমি একজন প্রফেশনাল YouTube SEO এবং কন্টেন্ট স্ট্র্যাটেজিস্ট।\n" +
                "তোমাকে একটি ভিডিওর ৩টি স্ক্রিনশট দেওয়া হয়েছে। এই ৩টি স্ক্রিনশট গভীরভাবে বিশ্লেষণ করে ভিডিওটির মূল বিষয়বস্তু, ধরন, দৃশ্যপট এবং দর্শকদের আগ্রহের জায়গা খুঁজে বের করো।\n" +
                "$extraInfo\n\n" +
                "ভাষা নির্দেশনা: আউটপুট অবশ্যই $language ভাষায় তৈরি করবে।\n\n" +
                "নিচের ঠিক এই ফরম্যাটে উত্তর দাও (কোনো বাড়তি ভূমিকা বা উপসংহার লিখবে না):\n\n" +
                "[TITLE]\n(এখানে উচ্চ-CTR সম্পন্ন, আকর্ষণীয় এবং সার্চ-ফ্রেন্ডলি একটি সেরা ইউটিউব টাইটেল লিখবে)\n\n" +
                "[DESCRIPTION]\n(এখানে ইউটিউব অ্যালগরিদম ও এসইও-বান্ধব বিস্তারিত ডেসক্রিপশন লিখবে। প্রথম ২ লাইনে মূল কিওয়ার্ড রাখবে, এরপর ভিডিওর সারসংক্ষেপ ও দর্শকদের জন্য কল-টু-অ্যাকশন যুক্ত করবে)\n\n" +
                "[HASHTAGS]\n(এখানে ১৫টি হাই-র‍্যাংকিং এবং প্রাসঙ্গিক ইউটিউব হ্যাশট্যাগ স্পেস দিয়ে লিখবে, যেমন: #tag1 #tag2 #tag3)"

            val textPart = JsonObject().apply {
                addProperty("text", prompt)
            }
            partsArray.add(textPart)

            for (uri in imageUris) {
                val base64 = encodeUriToCompressedBase64(context, uri)
                    ?: return@withContext Result.failure(Exception("স্ক্রিনশট প্রসেস করতে সমস্যা হয়েছে।"))
                val inlineData = JsonObject().apply {
                    addProperty("mime_type", "image/jpeg")
                    addProperty("data", base64)
                }
                val imagePart = JsonObject().apply {
                    add("inline_data", inlineData)
                }
                partsArray.add(imagePart)
            }

            val contentObj = JsonObject().apply {
                add("parts", partsArray)
            }
            val contentsArray = JsonArray().apply {
                add(contentObj)
            }
            val genConfig = JsonObject().apply {
                addProperty("temperature", 0.7)
                addProperty("maxOutputTokens", 2048)
            }
            val rootBody = JsonObject().apply {
                add("contents", contentsArray)
                add("generationConfig", genConfig)
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val requestBody = gson.toJson(rootBody).toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errObj = runCatching { gson.fromJson(responseStr, JsonObject::class.java) }.getOrNull()
                    val apiErrMsg = errObj?.getAsJsonObject("error")?.get("message")?.asString
                        ?: "API ত্রুটি (${response.code})"
                    return@withContext Result.failure(Exception(apiErrMsg))
                }

                val jsonResponse = gson.fromJson(responseStr, JsonObject::class.java)
                val generatedText = jsonResponse
                    ?.getAsJsonArray("candidates")
                    ?.get(0)?.asJsonObject
                    ?.getAsJsonObject("content")
                    ?.getAsJsonArray("parts")
                    ?.get(0)?.asJsonObject
                    ?.get("text")?.asString
                    .orEmpty()

                if (generatedText.isBlank()) {
                    return@withContext Result.failure(Exception("AI থেকে কোনো উত্তর পাওয়া যায়নি।"))
                }

                Result.success(SeoResponseParser.parse(generatedText))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun encodeUriToCompressedBase64(context: Context, uri: Uri): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val original = BitmapFactory.decodeStream(inputStream)
            inputStream.close()
            if (original == null) return null

            val maxDim = 1024
            val ratio = minOf(maxDim.toFloat() / original.width, maxDim.toFloat() / original.height, 1.0f)
            val targetW = (original.width * ratio).toInt().coerceAtLeast(1)
            val targetH = (original.height * ratio).toInt().coerceAtLeast(1)

            val scaled = Bitmap.createScaledBitmap(original, targetW, targetH, true)
            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 85, baos)
            if (scaled != original) scaled.recycle()
            original.recycle()

            Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }
}
