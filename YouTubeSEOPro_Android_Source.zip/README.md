# YouTube SEO Pro — SR Creation Farm

**Developer:** Shahriar Rahman  
**Brand:** SR Creation Farm  
**YouTube:** [@SRCreation-farm](https://www.youtube.com/@SRCreation-farm)  
**Facebook:** [SR Creation Farm](https://fb.com/srcreation.farm)  

## Features
- **3-Screenshot Multimodal AI Analysis** powered by `gemini-3.8-flash`
- **One-Click Copy** for YouTube Title, SEO Description, and Hashtags
- **9 Color Themes + Light/Dark/System Appearance Modes**
- **Local SEO History** with Copy & Delete controls
- **Smart Three-Dot Menu** & Developer Branding
