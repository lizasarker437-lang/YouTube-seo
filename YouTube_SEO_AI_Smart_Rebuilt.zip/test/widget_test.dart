import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:youtube_seo_ai/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('app starts and shows the SEO generator', (tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const SeoApp());
    await tester.pump();
    expect(find.text('YouTube SEO AI'), findsOneWidget);
    expect(find.text('ভিডিও স্ক্রিনশট'), findsOneWidget);
    expect(find.text('SEO কনটেন্ট তৈরি করুন'), findsOneWidget);
  });
}
