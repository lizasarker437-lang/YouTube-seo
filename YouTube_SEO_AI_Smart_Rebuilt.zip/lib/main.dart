import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const SeoApp());

const _bg = Color(0xFF0B1020);
const _panel = Color(0xFF151D31);
const _accent = Color(0xFFFF3B4E);
const _model = 'gemini-3.8-flash';

class SeoApp extends StatelessWidget {
  const SeoApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'YouTube SEO AI',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: _bg,
          colorScheme: ColorScheme.fromSeed(
            seedColor: _accent,
            brightness: Brightness.dark,
            surface: _panel,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: const Color(0xFF10182A),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFF293650)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFF293650)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: _accent, width: 1.4),
            ),
          ),
        ),
        home: const GeneratorPage(),
      );
}

class GeneratorPage extends StatefulWidget {
  const GeneratorPage({super.key});

  @override
  State<GeneratorPage> createState() => _GeneratorPageState();
}

class _GeneratorPageState extends State<GeneratorPage> {
  final _picker = ImagePicker();
  final List<XFile> _images = [];
  final _apiKey = TextEditingController();
  final _keywords = TextEditingController();
  final _audience = TextEditingController();
  final _title = TextEditingController();
  final _description = TextEditingController();
  final _hashtags = TextEditingController();

  String _language = 'বাংলা';
  bool _loading = false;
  bool _showResults = false;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _loadKey();
  }

  @override
  void dispose() {
    _apiKey.dispose();
    _keywords.dispose();
    _audience.dispose();
    _title.dispose();
    _description.dispose();
    _hashtags.dispose();
    super.dispose();
  }

  Future<void> _loadKey() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _apiKey.text = prefs.getString('gemini_api_key') ?? '');
  }

  Future<void> _saveKey(String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('gemini_api_key', value.trim());
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  Future<void> _chooseImages() async {
    try {
      final picked = await _picker.pickMultiImage(
        maxWidth: 1600,
        maxHeight: 1600,
        imageQuality: 88,
      );
      if (picked.isEmpty) return;
      setState(() {
        _images
          ..clear()
          ..addAll(picked.take(3));
      });
      if (picked.length > 3) _toast('সর্বোচ্চ ৩টি ছবি নেওয়া হয়েছে।');
    } catch (e) {
      _toast('ছবি নির্বাচন করা যায়নি। আবার চেষ্টা করুন।');
    }
  }

  Future<void> _addImage() async {
    if (_images.length >= 3) {
      _toast('সর্বোচ্চ ৩টি স্ক্রিনশট যোগ করা যাবে।');
      return;
    }
    try {
      final image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1600,
        maxHeight: 1600,
        imageQuality: 88,
      );
      if (image != null) setState(() => _images.add(image));
    } catch (_) {
      _toast('ছবি নির্বাচন করা যায়নি।');
    }
  }

  Future<void> _settings() async {
    final temporary = TextEditingController(text: _apiKey.text);
    final saved = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Gemini API Key'),
        content: TextField(
          controller: temporary,
          obscureText: true,
          autocorrect: false,
          enableSuggestions: false,
          decoration: const InputDecoration(
            hintText: 'আপনার API key',
            helperText: 'Google AI Studio থেকে API key তৈরি করুন।',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('বাতিল'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, temporary.text.trim()),
            child: const Text('সেভ'),
          ),
        ],
      ),
    );
    if (saved != null) {
      _apiKey.text = saved;
      await _saveKey(saved);
      if (mounted) setState(() {});
      _toast('API Key সেভ হয়েছে।');
    }
    temporary.dispose();
  }

  String _prompt() => '''
তুমি একজন অভিজ্ঞ YouTube SEO strategist এবং ভিডিও কনটেন্ট বিশ্লেষক।
সংযুক্ত ${_images.length}টি স্ক্রিনশট দেখে ভিডিওর বিষয়, দৃশ্য, সম্ভাব্য দর্শক, আবেগ, অনন্য দিক এবং সার্চ ইন্টেন্ট বিশ্লেষণ করো। ছবিতে নেই এমন ঘটনা বা তথ্য বানিয়ে লিখবে না।

আউটপুট ভাষা: $_language
অতিরিক্ত বিষয়/কিওয়ার্ড: ${_keywords.text.trim().isEmpty ? 'প্রয়োজন অনুযায়ী প্রাসঙ্গিক কিওয়ার্ড নির্বাচন করো' : _keywords.text.trim()}
টার্গেট দর্শক: ${_audience.text.trim().isEmpty ? 'সাধারণ প্রাসঙ্গিক দর্শক' : _audience.text.trim()}

নির্দেশনা:
- একটি শক্তিশালী, স্বাভাবিক ও নির্দিষ্ট SEO title দাও; অযথা clickbait নয়।
- Description-এর প্রথম দুই লাইনে মূল বিষয়/কিওয়ার্ড রাখো; এরপর ভিডিওর সঠিক সারাংশ, প্রাসঙ্গিক CTA এবং প্রয়োজনীয় disclosure/placeholder থাকলে তা স্পষ্ট করো।
- ১০-১৫টি সত্যিই প্রাসঙ্গিক hashtag দাও; অপ্রাসঙ্গিক বা ভুয়া ranking দাবি করবে না।
- ফলাফল যেন সরাসরি YouTube-এ ব্যবহার করা যায়।
- কোনো markdown code fence বা বাড়তি ভূমিকা নয়।

শুধু এই ফরম্যাটে উত্তর দাও:
[TITLE]
টাইটেল

[DESCRIPTION]
ডেসক্রিপশন

[HASHTAGS]
#tag1 #tag2 ...
''';

  Future<void> _generate() async {
    final key = _apiKey.text.trim();
    if (key.isEmpty) {
      _toast('প্রথমে Settings থেকে Gemini API Key দিন।');
      await _settings();
      if (_apiKey.text.trim().isEmpty) return;
    }
    if (_images.isEmpty) {
      _toast('কমপক্ষে ১টি ভিডিও স্ক্রিনশট যোগ করুন।');
      return;
    }

    setState(() {
      _loading = true;
      _error = '';
      _showResults = false;
    });

    try {
      final parts = <Map<String, dynamic>>[
        {'text': _prompt()},
      ];
      for (final image in _images) {
        final bytes = await image.readAsBytes();
        final ext = image.name.toLowerCase().split('.').last;
        final mime = ext == 'png'
            ? 'image/png'
            : (ext == 'webp' ? 'image/webp' : 'image/jpeg');
        parts.add({
          'inline_data': {'mime_type': mime, 'data': base64Encode(bytes)}
        });
      }

      final uri = Uri.https(
        'generativelanguage.googleapis.com',
        '/v1beta/models/$_model:generateContent',
        {'key': _apiKey.text.trim()},
      );

      final response = await http
          .post(
            uri,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'contents': [
                {'role': 'user', 'parts': parts}
              ],
              'generationConfig': {
                'temperature': 0.65,
                'maxOutputTokens': 4096,
              }
            }),
          )
          .timeout(const Duration(seconds: 90));

      final data = jsonDecode(response.body);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        final message = data is Map
            ? (data['error']?['message']?.toString() ?? 'HTTP ${response.statusCode}')
            : 'HTTP ${response.statusCode}';
        throw Exception(_friendlyApiError(response.statusCode, message));
      }

      final candidates = data['candidates'] as List?;
      if (candidates == null || candidates.isEmpty) {
        throw Exception('AI কোনো ফলাফল দেয়নি। নতুন স্ক্রিনশট দিয়ে আবার চেষ্টা করুন।');
      }
      final contentParts = candidates.first['content']?['parts'] as List? ?? [];
      final output = contentParts
          .where((part) => part is Map && part['text'] != null)
          .map((part) => part['text'].toString())
          .join('\n')
          .trim();
      if (output.isEmpty) throw Exception('AI থেকে খালি উত্তর এসেছে। আবার চেষ্টা করুন।');
      if (!mounted) return;
      _parse(output);
    } on SocketException {
      _setError('ইন্টারনেট সংযোগ পাওয়া যাচ্ছে না। নেটওয়ার্ক পরীক্ষা করুন।');
    } on HttpException {
      _setError('সার্ভারের সঙ্গে যোগাযোগ করা যায়নি।');
    } on FormatException {
      _setError('সার্ভারের উত্তর বোঝা যায়নি। কিছুক্ষণ পর আবার চেষ্টা করুন।');
    } catch (e) {
      _setError(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _friendlyApiError(int status, String message) {
    if (status == 400 || status == 403) {
      return 'API Key বা অনুরোধে সমস্যা: $message';
    }
    if (status == 404) return 'Gemini মডেল পাওয়া যায়নি। API Key/মডেল অ্যাক্সেস পরীক্ষা করুন।';
    if (status == 429) return 'API quota বা rate limit শেষ হয়েছে। কিছুক্ষণ পর চেষ্টা করুন।';
    if (status >= 500) return 'Google AI সার্ভারে সাময়িক সমস্যা। পরে আবার চেষ্টা করুন।';
    return message;
  }

  void _setError(String message) {
    if (!mounted) return;
    setState(() => _error = message);
  }

  void _parse(String output) {
    String section(String name, String next) {
      final pattern = RegExp(
        '\\[$name\\](.*?)(?=\\[$next\\]|\\[(?:TITLE|DESCRIPTION|HASHTAGS)\\]|$)',
        dotAll: true,
        caseSensitive: false,
      );
      return pattern.firstMatch(output)?.group(1)?.trim() ?? '';
    }

    var title = section('TITLE', 'DESCRIPTION');
    var description = section('DESCRIPTION', 'HASHTAGS');
    var hashtags = RegExp(r'\[HASHTAGS\](.*)$', dotAll: true, caseSensitive: false)
            .firstMatch(output)
            ?.group(1)
            ?.trim() ??
        '';

    if (title.isEmpty && description.isEmpty && hashtags.isEmpty) {
      title = output;
    }
    setState(() {
      _title.text = title;
      _description.text = description;
      _hashtags.text = hashtags;
      _showResults = true;
    });
  }

  Future<void> _copy(String text, String label) async {
    if (text.trim().isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    _toast('$label কপি হয়েছে।');
  }

  Future<void> _copyAll() async {
    final all = [
      if (_title.text.trim().isNotEmpty) _title.text.trim(),
      if (_description.text.trim().isNotEmpty) _description.text.trim(),
      if (_hashtags.text.trim().isNotEmpty) _hashtags.text.trim(),
    ].join('\n\n');
    await _copy(all, 'সম্পূর্ণ SEO কনটেন্ট');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          titleSpacing: 18,
          title: const Row(
            children: [
              Icon(Icons.smart_toy_rounded, color: _accent),
              SizedBox(width: 9),
              Text('YouTube SEO AI', style: TextStyle(fontWeight: FontWeight.w800)),
            ],
          ),
          actions: [
            IconButton(
              onPressed: _settings,
              tooltip: 'API Key সেটিংস',
              icon: const Icon(Icons.tune_rounded),
            ),
            const SizedBox(width: 6),
          ],
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              _hero(),
              const SizedBox(height: 18),
              _sectionTitle('ভিডিও স্ক্রিনশট', 'সর্বোচ্চ ৩টি ছবি • কমপক্ষে ১টি'),
              const SizedBox(height: 10),
              _imagePicker(),
              const SizedBox(height: 20),
              _sectionTitle('কনটেন্ট সেটিংস', 'ফলাফলকে আরও নির্ভুল করুন'),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: _language,
                decoration: const InputDecoration(
                  labelText: 'আউটপুটের ভাষা',
                  prefixIcon: Icon(Icons.translate_rounded),
                ),
                items: const [
                  DropdownMenuItem(value: 'বাংলা', child: Text('বাংলা')),
                  DropdownMenuItem(value: 'English', child: Text('English')),
                  DropdownMenuItem(value: 'বাংলা ও English মিশ্র', child: Text('বাংলা + English')),
                ],
                onChanged: (value) {
                  if (value != null) setState(() => _language = value);
                },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _keywords,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'ভিডিওর বিষয় / কিওয়ার্ড (ঐচ্ছিক)',
                  hintText: 'যেমন: গ্রামের জীবন, Android tips, cooking',
                  prefixIcon: Icon(Icons.key_rounded),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _audience,
                textInputAction: TextInputAction.done,
                decoration: const InputDecoration(
                  labelText: 'টার্গেট দর্শক (ঐচ্ছিক)',
                  hintText: 'যেমন: নতুন YouTuber, বাংলা ভাষার দর্শক',
                  prefixIcon: Icon(Icons.people_alt_outlined),
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                height: 56,
                child: FilledButton.icon(
                  onPressed: _loading ? null : _generate,
                  style: FilledButton.styleFrom(
                    backgroundColor: _accent,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  icon: _loading
                      ? const SizedBox(
                          height: 19,
                          width: 19,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.auto_awesome_rounded),
                  label: Text(
                    _loading ? 'AI বিশ্লেষণ করছে...' : 'SEO কনটেন্ট তৈরি করুন',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              if (_loading) ...[
                const SizedBox(height: 10),
                const LinearProgressIndicator(minHeight: 3),
                const SizedBox(height: 6),
                const Text('স্ক্রিনশট বিশ্লেষণ করে টাইটেল, ডেসক্রিপশন ও হ্যাশট্যাগ তৈরি হচ্ছে।',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white60, fontSize: 12)),
              ],
              if (_error.isNotEmpty) ...[
                const SizedBox(height: 14),
                _errorCard(),
              ],
              if (_showResults) ...[
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(child: _sectionTitle('আপনার SEO ফলাফল', 'প্রয়োজনে লেখা এডিট করুন')),
                    TextButton.icon(
                      onPressed: _copyAll,
                      icon: const Icon(Icons.copy_all_rounded, size: 18),
                      label: const Text('সব কপি'),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                _resultCard('প্রস্তাবিত Title', _title, Icons.title_rounded),
                const SizedBox(height: 12),
                _resultCard('Description', _description, Icons.subject_rounded),
                const SizedBox(height: 12),
                _resultCard('Hashtags', _hashtags, Icons.tag_rounded),
                const SizedBox(height: 8),
                const Text(
                  'টিপস: প্রকাশের আগে শিরোনাম ও বিবরণ ভিডিওর প্রকৃত কনটেন্টের সঙ্গে মিলিয়ে নিন।',
                  style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4),
                ),
              ],
              const SizedBox(height: 22),
              _privacyNote(),
            ],
          ),
        ),
      );

  Widget _hero() => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(
            colors: [Color(0xFF28375B), Color(0xFF17233B), Color(0xFF351E36)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: Colors.white.withOpacity(.08)),
        ),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Create smarter videos.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            SizedBox(height: 6),
            Text('স্ক্রিনশট দিন, AI দিয়ে তৈরি করুন আকর্ষণীয় YouTube Title, Description ও Hashtags।',
                style: TextStyle(color: Colors.white70, height: 1.5)),
            SizedBox(height: 14),
            Row(
              children: [
                _Pill(icon: Icons.image_outlined, label: 'Image analysis'),
                SizedBox(width: 7),
                _Pill(icon: Icons.bolt_rounded, label: 'Gemini AI'),
              ],
            )
          ],
        ),
      );

  Widget _sectionTitle(String title, String subtitle) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.white54)),
        ],
      );

  Widget _imagePicker() => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: _panel,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFF293650)),
        ),
        child: Column(
          children: [
            Row(
              children: List.generate(3, (index) {
                final hasImage = index < _images.length;
                return Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(right: index == 2 ? 0 : 9),
                    child: AspectRatio(
                      aspectRatio: 1,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(13),
                        onTap: hasImage ? () => _preview(_images[index]) : _addImage,
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFF0D1526),
                            borderRadius: BorderRadius.circular(13),
                            border: Border.all(
                              color: hasImage ? _accent.withOpacity(.8) : const Color(0xFF34425D),
                              width: 1.2,
                            ),
                          ),
                          child: hasImage
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      Image.file(File(_images[index].path), fit: BoxFit.cover),
                                      Positioned(
                                        top: 5,
                                        left: 5,
                                        child: _badge('${index + 1}'),
                                      ),
                                      Positioned(
                                        top: 3,
                                        right: 3,
                                        child: InkWell(
                                          onTap: () => setState(() => _images.removeAt(index)),
                                          child: const CircleAvatar(
                                            radius: 13,
                                            backgroundColor: Colors.black87,
                                            child: Icon(Icons.close, size: 15),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : const Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.add_photo_alternate_outlined, color: Colors.white54, size: 28),
                                    SizedBox(height: 5),
                                    Text('ছবি যোগ', style: TextStyle(fontSize: 11, color: Colors.white60)),
                                  ],
                                ),
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.info_outline, size: 15, color: Colors.white54),
                const SizedBox(width: 6),
                Expanded(
                  child: Text('${_images.length}/3টি ছবি নির্বাচিত',
                      style: const TextStyle(color: Colors.white60, fontSize: 12)),
                ),
                TextButton.icon(
                  onPressed: _chooseImages,
                  icon: const Icon(Icons.photo_library_outlined, size: 17),
                  label: const Text('গ্যালারি'),
                ),
              ],
            ),
          ],
        ),
      );

  Widget _badge(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
        decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
      );

  Future<void> _preview(XFile image) async {
    await showDialog<void>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Image.file(File(image.path), fit: BoxFit.contain),
        ),
      ),
    );
  }

  Widget _resultCard(String label, TextEditingController controller, IconData icon) =>
      Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 10, 10),
        decoration: BoxDecoration(
          color: _panel,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: const Color(0xFF293650)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: _accent, size: 19),
                const SizedBox(width: 8),
                Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.bold))),
                IconButton(
                  tooltip: 'কপি করুন',
                  visualDensity: VisualDensity.compact,
                  onPressed: () => _copy(controller.text, label),
                  icon: const Icon(Icons.copy_rounded, size: 18),
                ),
              ],
            ),
            TextField(
              controller: controller,
              minLines: label == 'Description' ? 5 : 2,
              maxLines: label == 'Description' ? 12 : 5,
              decoration: const InputDecoration(
                filled: false,
                contentPadding: EdgeInsets.fromLTRB(2, 4, 2, 6),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
              ),
              style: const TextStyle(height: 1.5, fontSize: 14),
            ),
          ],
        ),
      );

  Widget _errorCard() => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF4A202B),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _accent.withOpacity(.5)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.error_outline, color: Color(0xFFFF9AA5)),
            const SizedBox(width: 10),
            Expanded(child: Text(_error, style: const TextStyle(height: 1.4))),
            IconButton(
              onPressed: () => setState(() => _error = ''),
              icon: const Icon(Icons.close, size: 18),
              visualDensity: VisualDensity.compact,
            ),
          ],
        ),
      );

  Widget _privacyNote() => Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: const Color(0xFF10182A),
          borderRadius: BorderRadius.circular(14),
        ),
        child: const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.lock_outline_rounded, size: 17, color: Colors.white54),
            SizedBox(width: 9),
            Expanded(
              child: Text(
                'আপনার API Key এই ডিভাইসের অ্যাপ স্টোরেজে রাখা হয়। স্ক্রিনশট ও অনুরোধ বিশ্লেষণের জন্য Google Gemini API-তে পাঠানো হয়।',
                style: TextStyle(color: Colors.white54, fontSize: 11, height: 1.5),
              ),
            ),
          ],
        ),
      );
}

class _Pill extends StatelessWidget {
  const _Pill({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.09),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.white.withOpacity(.1)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: const Color(0xFFFFA3AD)),
            const SizedBox(width: 5),
            Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
          ],
        ),
      );
}
