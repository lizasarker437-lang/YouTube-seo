# YouTube SEO AI

A Flutter Android app that analyzes up to three video screenshots and generates a YouTube title, description and hashtags using the Gemini API.

## Build on GitHub
1. Extract this ZIP and upload **the contents** to a new GitHub repository (the `.github` folder must be at repository root).
2. Open **Actions** and run **Build YouTube SEO AI APK**, or push to `main`/`master`.
3. Download `youtube-seo-ai-release` from the completed workflow's Artifacts section.

## Use
- Create a Gemini API key in Google AI Studio and add it in the app's key settings.
- Select 1–3 screenshots (minimum one required).
- Choose output language, optionally add topic/keywords and audience context.
- Generate, edit, copy individual sections, or copy all results.

The API key is stored locally in Android app preferences. Requests are sent directly from the device to Google's Gemini API. Do not share your API key or include it in screenshots or public repositories.

## Notes
- Requires internet access and a valid Gemini API key. Google API usage and quotas may apply.
- GitHub Actions builds an APK; it does not sign it with a Play Store upload key.
