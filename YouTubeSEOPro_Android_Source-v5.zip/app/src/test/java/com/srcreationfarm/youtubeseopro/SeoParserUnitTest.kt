package com.srcreationfarm.youtubeseopro

import com.srcreationfarm.youtubeseopro.utils.SeoResponseParser
import org.junit.Assert.assertEquals
import org.junit.Test

class SeoParserUnitTest {

    @Test
    fun testFiveFieldStructuredResponseParsing() {
        val sample = "[TITLE]\nAmazing Village Farming Vlog\n" +
            "[DESCRIPTION]\nWatch our daily farm routine in Bangladesh.\n" +
            "[HASHTAGS]\n#farming #vlog #srcreationfarm\n" +
            "[TAGS]\nfarming vlog, bangladesh village, sr creation farm\n" +
            "[EXTRA]\n১০০% দেশি খামার!"
        val parsed = SeoResponseParser.parse(sample)
        assertEquals("Amazing Village Farming Vlog", parsed.title)
        assertEquals("Watch our daily farm routine in Bangladesh.", parsed.description)
        assertEquals("#farming #vlog #srcreationfarm", parsed.hashtags)
        assertEquals("farming vlog, bangladesh village, sr creation farm", parsed.studioTags)
        assertEquals("১০০% দেশি খামার!", parsed.extraHook)
    }
}
