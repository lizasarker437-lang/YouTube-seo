package com.srcreationfarm.youtubeseopro.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.srcreationfarm.youtubeseopro.data.SettingsManager
import com.srcreationfarm.youtubeseopro.utils.SeoResponseParser
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

class GeminiSeoService {

    // Fast client with tight timeouts so no request hangs for minutes
    private val fastClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(28, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val gson = Gson()

    suspend fun generateSeoFromScreenshots(
        context: Context,
        settings: SettingsManager,
        imageUris: List<Uri>,
        language: String,
        keywordHint: String,
        onProgress: (Int, String) -> Unit
    ): Result<SeoResponseParser.ParsedSeo> = withContext(Dispatchers.IO) {
        try {
            val startTime = System.currentTimeMillis()
            onProgress(10, "⚡ টার্বো মোডে স্ক্রিনশট অপ্টিমাইজ হচ্ছে...")

            val payloadImages: List<String> = if (settings.turboCollageMode) {
                val collageBase64 = createThreeInOneCollageBase64(context, imageUris)
                    ?: return@withContext Result.failure(Exception("স্ক্রিনশট প্রসেস করতে সমস্যা হয়েছে।"))
                listOf(collageBase64)
            } else {
                imageUris.map { uri ->
                    encodeSingleFastBase64(context, uri)
                        ?: return@withContext Result.failure(Exception("স্ক্রিনশট প্রসেস করতে সমস্যা হয়েছে।"))
                }
            }

            onProgress(28, "⚡ ছবি প্রস্তুত (মাত্র ${payloadImages.sumOf { it.length } / 1024} KB), AI ইঞ্জিন চালু হচ্ছে...")

            val extraInfo = if (keywordHint.isNotBlank()) {
                "মূল বিষয়/কিওয়ার্ড: $keywordHint\n"
            } else {
                ""
            }

            val prompt = "তুমি একজন এক্সপার্ট YouTube SEO স্পেশালিস্ট।\n" +
                "ছবিতে একটি ভিডিওর ৩টি স্ক্রিনশট দেওয়া হয়েছে। এগুলো দেখে ভিডিওটির বিষয়বস্তু বুঝে নাও।\n" +
                extraInfo +
                "ভাষা: $language।\n" +
                "ঠিক নিচের ফরম্যাটে সংক্ষিপ্ত ও নিখুঁত উত্তর দাও:\n\n" +
                "[TITLE]\n(১টি আকর্ষণীয় ও ভাইরাল ইউটিউব টাইটেল)\n\n" +
                "[DESCRIPTION]\n(এসইও-বান্ধব ডেসক্রিপশন: প্রথম ২ লাইনে মূল কিওয়ার্ড, সংক্ষিপ্ত বিবরণ ও সাবস্ক্রাইব কল-টু-অ্যাকশন)\n\n" +
                "[HASHTAGS]\n(১৫টি প্রাসঙ্গিক হ্যাশট্যাগ স্পেস দিয়ে, যেমন: #tag1 #tag2)"

            val primaryGeminiKey = settings.apiKey.trim()
            val backupGeminiKey = settings.backupGeminiKey.trim()
            val rawGroqKey = settings.groqApiKey.trim()

            val effectiveGroqKey = when {
                rawGroqKey.startsWith("gsk_") -> rawGroqKey
                primaryGeminiKey.startsWith("gsk_") -> primaryGeminiKey
                backupGeminiKey.startsWith("gsk_") -> backupGeminiKey
                else -> ""
            }

            val geminiKeys = listOf(primaryGeminiKey, backupGeminiKey)
                .filter { it.isNotBlank() && !it.startsWith("gsk_") }
                .distinct()

            val networkFinished = AtomicBoolean(false)
            val progressJob = launch {
                var pct = 35
                while (isActive && !networkFinished.get() && pct < 94) {
                    val elapsedSec = (System.currentTimeMillis() - startTime) / 1000
                    val msg = when {
                        pct < 55 -> "⚡ প্যারালাল AI রেসিং চলছে (${elapsedSec}s)..."
                        pct < 80 -> "⚡ দ্রুততম সার্ভার থেকে উত্তর নেওয়া হচ্ছে (${elapsedSec}s)..."
                        else -> "⚡ টাইটেল ও ডেসক্রিপশন সাজানো হচ্ছে (${elapsedSec}s)..."
                    }
                    onProgress(pct, msg)
                    delay(300)
                    pct += 3
                }
            }

            // Build ordered list of fastest models (Lite & Flash first; never slow Pro unless requested)
            val preferred = settings.selectedModel
            val fastModels = mutableListOf<String>()

            if (preferred.startsWith("gemini-")) {
                fastModels.add(preferred)
            }
            if (settings.lastFastestModel.isNotBlank() && !fastModels.contains(settings.lastFastestModel)) {
                fastModels.add(settings.lastFastestModel)
            }

            val defaultFastOrder = listOf(
                "gemini-flash-lite-latest",
                "gemini-3.8-flash-lite",
                "gemini-3.8-flash",
                "gemini-flash-latest",
                "gemini-2.5-flash-lite",
                "gemini-2.0-flash-lite",
                "gemini-2.0-flash"
            )
            for (m in defaultFastOrder) {
                if (!fastModels.contains(m)) fastModels.add(m)
            }

            val winnerDeferred = CompletableDeferred<Pair<String, String>>()
            val lastErrorRef = AtomicReference("সার্ভার ব্যস্ত রয়েছে, অনুগ্রহ করে আবার চেষ্টা করুন।")

            coroutineScope {
                val raceJobs = mutableListOf<Job>()

                // 1. If Groq key is available, launch Groq Vision immediately in parallel (responds in ~2 seconds!)
                if (effectiveGroqKey.isNotBlank()) {
                    raceJobs += launch {
                        val res = callGroqVisionFallback(effectiveGroqKey, prompt, payloadImages)
                        if (res.isSuccess && winnerDeferred.complete("Groq-Vision" to res.getOrThrow())) {
                            raceJobs.forEach { if (it != this) it.cancel() }
                        } else {
                            res.exceptionOrNull()?.message?.let { lastErrorRef.set(it) }
                        }
                    }
                }

                // 2. Launch hedged parallel race across top Gemini models so we never wait sequentially for a slow/busy model!
                for (gKey in geminiKeys) {
                    for ((idx, modelName) in fastModels.withIndex()) {
                        raceJobs += launch {
                            // Stagger requests by 600ms so the fastest 2-3 models race simultaneously without waiting minutes!
                            if (idx > 0) {
                                delay(idx * 650L)
                            }
                            if (winnerDeferred.isCompleted) return@launch

                            val res = callGeminiFast(
                                apiKey = gKey,
                                model = modelName,
                                prompt = prompt,
                                base64Images = payloadImages
                            )
                            if (res.isSuccess) {
                                if (winnerDeferred.complete(modelName to res.getOrThrow())) {
                                    settings.lastFastestModel = modelName
                                    raceJobs.forEach { job -> job.cancel() }
                                }
                            } else {
                                res.exceptionOrNull()?.message?.let { err ->
                                    if (!err.contains("not found", ignoreCase = true) &&
                                        !err.contains("no longer available", ignoreCase = true)
                                    ) {
                                        lastErrorRef.set(err)
                                    }
                                }
                            }
                        }
                    }
                }

                // Wait until either the first winner completes OR all parallel racers finish
                launch {
                    raceJobs.forEach { it.join() }
                    if (!winnerDeferred.isCompleted) {
                        winnerDeferred.completeExceptionally(Exception(lastErrorRef.get()))
                    }
                }
            }

            val (winningModel, winningText) = winnerDeferred.await()
            networkFinished.set(true)
            progressJob.cancel()

            val totalSeconds = ((System.currentTimeMillis() - startTime) / 1000.0)
            onProgress(100, "⚡ মাত্র ${"%.1f".format(totalSeconds)} সেকেন্ডে সম্পন্ন! ($winningModel)")
            Result.success(SeoResponseParser.parse(winningText))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun callGeminiFast(
        apiKey: String,
        model: String,
        prompt: String,
        base64Images: List<String>
    ): Result<String> {
        return try {
            val partsArray = JsonArray()
            partsArray.add(JsonObject().apply { addProperty("text", prompt) })

            for (b64 in base64Images) {
                val inlineData = JsonObject().apply {
                    addProperty("mime_type", "image/jpeg")
                    addProperty("data", b64)
                }
                partsArray.add(JsonObject().apply { add("inline_data", inlineData) })
            }

            val rootBody = JsonObject().apply {
                add("contents", JsonArray().apply {
                    add(JsonObject().apply { add("parts", partsArray) })
                })
                add("generationConfig", JsonObject().apply {
                    addProperty("temperature", 0.6)
                    addProperty("maxOutputTokens", 1024)
                })
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val requestBody = gson.toJson(rootBody).toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url(url).post(requestBody).build()

            fastClient.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errObj = runCatching { gson.fromJson(responseStr, JsonObject::class.java) }.getOrNull()
                    val apiErrMsg = errObj?.getAsJsonObject("error")?.get("message")?.asString
                        ?: "HTTP ${response.code}"
                    return Result.failure(Exception(apiErrMsg))
                }

                val jsonResponse = gson.fromJson(responseStr, JsonObject::class.java)
                val parts = jsonResponse
                    ?.getAsJsonArray("candidates")
                    ?.get(0)?.asJsonObject
                    ?.getAsJsonObject("content")
                    ?.getAsJsonArray("parts")

                var extractedText = ""
                if (parts != null) {
                    for (p in parts) {
                        val obj = p.asJsonObject
                        if (obj.has("text")) {
                            extractedText += obj.get("text").asString
                        }
                    }
                }

                if (extractedText.isBlank()) {
                    return Result.failure(Exception("Empty output from $model"))
                }
                Result.success(extractedText)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun callGroqVisionFallback(
        groqKey: String,
        prompt: String,
        base64Images: List<String>
    ): Result<String> {
        val groqModels = listOf(
            "meta-llama/llama-4-scout-17b-16e-instruct",
            "llama-3.2-11b-vision-preview",
            "llama-3.2-90b-vision-preview"
        )
        var lastErr = "Groq Vision error"

        for (gModel in groqModels) {
            try {
                val contentArr = JsonArray()
                contentArr.add(JsonObject().apply {
                    addProperty("type", "text")
                    addProperty("text", prompt)
                })
                for (b64 in base64Images) {
                    contentArr.add(JsonObject().apply {
                        addProperty("type", "image_url")
                        add("image_url", JsonObject().apply {
                            addProperty("url", "data:image/jpeg;base64,$b64")
                        })
                    })
                }

                val bodyObj = JsonObject().apply {
                    addProperty("model", gModel)
                    add("messages", JsonArray().apply {
                        add(JsonObject().apply {
                            addProperty("role", "user")
                            add("content", contentArr)
                        })
                    })
                    addProperty("temperature", 0.6)
                    addProperty("max_tokens", 1024)
                }

                val reqBody = gson.toJson(bodyObj).toRequestBody("application/json; charset=utf-8".toMediaType())
                val req = Request.Builder()
                    .url("https://api.groq.com/openai/v1/chat/completions")
                    .addHeader("Authorization", "Bearer $groqKey")
                    .post(reqBody)
                    .build()

                fastClient.newCall(req).execute().use { resp ->
                    val respStr = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val root = gson.fromJson(respStr, JsonObject::class.java)
                        val text = root
                            ?.getAsJsonArray("choices")
                            ?.get(0)?.asJsonObject
                            ?.getAsJsonObject("message")
                            ?.get("content")?.asString
                            .orEmpty()
                        if (text.isNotBlank()) {
                            return Result.success(text)
                        }
                    } else {
                        lastErr = respStr
                    }
                }
            } catch (e: Exception) {
                lastErr = e.message ?: "Groq connection failed"
            }
        }
        return Result.failure(Exception(lastErr))
    }

    // Combines 3 screenshots side-by-side into a single 900x320 collage (~22 KB total!)
    // Cuts upload time by 75% and AI vision token processing time by 65%!
    private fun createThreeInOneCollageBase64(context: Context, uris: List<Uri>): String? {
        return try {
            val cellW = 300
            val cellH = 320
            val collage = Bitmap.createBitmap(cellW * 3, cellH, Bitmap.Config.RGB_565)
            val canvas = Canvas(collage)
            canvas.drawColor(Color.BLACK)

            for (i in 0 until minOf(3, uris.size)) {
                val bmp = decodeSmallBitmap(context, uris[i], cellW, cellH) ?: return null
                val destRect = Rect(i * cellW, 0, (i + 1) * cellW, cellH)
                canvas.drawBitmap(bmp, null, destRect, null)
                bmp.recycle()
            }

            val baos = ByteArrayOutputStream()
            collage.compress(Bitmap.CompressFormat.JPEG, 68, baos)
            collage.recycle()

            Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    private fun decodeSmallBitmap(context: Context, uri: Uri, reqW: Int, reqH: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while (bounds.outWidth / sample > reqW * 2 || bounds.outHeight / sample > reqH * 2) {
                sample *= 2
            }
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun encodeSingleFastBase64(context: Context, uri: Uri): String? {
        val bmp = decodeSmallBitmap(context, uri, 480, 480) ?: return null
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 68, baos)
        bmp.recycle()
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }
}
