package com.srcreationfarm.youtubeseopro.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.srcreationfarm.youtubeseopro.model.SeoResult

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("yt_seo_pro_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        const val KEY_API_KEY = "gemini_api_key"
        const val KEY_BACKUP_GEMINI_KEY = "backup_gemini_api_key"
        const val KEY_GROQ_API_KEY = "groq_api_key"
        const val KEY_MODEL = "gemini_model"
        const val KEY_APPEARANCE = "appearance_mode"
        const val KEY_COLOR_THEME = "color_theme"
        const val KEY_AUTO_SAVE = "auto_save_history"
        const val KEY_HISTORY = "seo_history_list"

        const val DEFAULT_MODEL = "Smart Auto-Fallback (100% Guaranteed)"
    }

    var apiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API_KEY, value.trim()).apply()

    var backupGeminiKey: String
        get() = prefs.getString(KEY_BACKUP_GEMINI_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_BACKUP_GEMINI_KEY, value.trim()).apply()

    var groqApiKey: String
        get() = prefs.getString(KEY_GROQ_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_GROQ_API_KEY, value.trim()).apply()

    var selectedModel: String
        get() = prefs.getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) = prefs.edit().putString(KEY_MODEL, value).apply()

    var appearanceMode: Int
        get() = prefs.getInt(KEY_APPEARANCE, 0)
        set(value) = prefs.edit().putInt(KEY_APPEARANCE, value).apply()

    var colorTheme: String
        get() = prefs.getString(KEY_COLOR_THEME, "Midnight Gold") ?: "Midnight Gold"
        set(value) = prefs.edit().putString(KEY_COLOR_THEME, value).apply()

    var autoSaveHistory: Boolean
        get() = prefs.getBoolean(KEY_AUTO_SAVE, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_SAVE, value).apply()

    fun hasAnyValidKey(): Boolean {
        return apiKey.isNotBlank() || backupGeminiKey.isNotBlank() || groqApiKey.isNotBlank()
    }

    fun getHistory(): MutableList<SeoResult> {
        val json = prefs.getString(KEY_HISTORY, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<SeoResult>>() {}.type
        return try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun addHistory(item: SeoResult) {
        val list = getHistory()
        list.add(0, item)
        if (list.size > 50) {
            list.removeAt(list.lastIndex)
        }
        prefs.edit().putString(KEY_HISTORY, gson.toJson(list)).apply()
    }

    fun deleteHistoryItem(id: Long) {
        val list = getHistory().filter { it.id != id }
        prefs.edit().putString(KEY_HISTORY, gson.toJson(list)).apply()
    }

    fun clearAll() {
        val k1 = apiKey
        val k2 = backupGeminiKey
        val k3 = groqApiKey
        prefs.edit().clear().apply()
        apiKey = k1
        backupGeminiKey = k2
        groqApiKey = k3
    }
}
