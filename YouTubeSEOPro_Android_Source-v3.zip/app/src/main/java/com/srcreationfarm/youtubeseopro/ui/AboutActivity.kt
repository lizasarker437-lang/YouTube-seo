package com.srcreationfarm.youtubeseopro.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.srcreationfarm.youtubeseopro.R
import com.srcreationfarm.youtubeseopro.data.SettingsManager
import com.srcreationfarm.youtubeseopro.databinding.ActivityAboutBinding
import com.srcreationfarm.youtubeseopro.utils.ThemeManager

class AboutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        val settings = SettingsManager(this)
        ThemeManager.applyTheme(this, settings)
        super.onCreate(savedInstanceState)

        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbarAbout.setNavigationOnClickListener { finish() }

        binding.btnOpenYouTube.setOnClickListener {
            openUrl(getString(R.string.youtube_url))
        }

        binding.btnOpenFacebook.setOnClickListener {
            openUrl(getString(R.string.facebook_url))
        }
    }

    private fun openUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(intent)
    }
}
