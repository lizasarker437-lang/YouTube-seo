package com.srcreationfarm.youtubeseopro.utils

object SeoResponseParser {

    data class ParsedSeo(
        val title: String,
        val description: String,
        val hashtags: String
    )

    fun parse(rawText: String): ParsedSeo {
        val titleRegex = Regex("\\[TITLE\\](.*?)(?=\\[DESCRIPTION\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val descRegex = Regex("\\[DESCRIPTION\\](.*?)(?=\\[HASHTAGS\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val tagsRegex = Regex("\\[HASHTAGS\\](.*)", RegexOption.DOT_MATCHES_ALL)

        val title = titleRegex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()
        val desc = descRegex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()
        val tags = tagsRegex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()

        return if (title.isEmpty() && desc.isEmpty() && tags.isEmpty()) {
            ParsedSeo(
                title = "Generated SEO Result",
                description = rawText.trim(),
                hashtags = ""
            )
        } else {
            ParsedSeo(title, desc, tags)
        }
    }
}
