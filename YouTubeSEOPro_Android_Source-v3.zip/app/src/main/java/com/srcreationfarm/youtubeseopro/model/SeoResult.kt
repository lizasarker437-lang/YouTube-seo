package com.srcreationfarm.youtubeseopro.model

data class SeoResult(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val description: String,
    val hashtags: String,
    val language: String,
    val timestamp: String
)
