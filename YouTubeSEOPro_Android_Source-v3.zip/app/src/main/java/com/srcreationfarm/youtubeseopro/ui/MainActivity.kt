package com.srcreationfarm.youtubeseopro.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.srcreationfarm.youtubeseopro.R
import com.srcreationfarm.youtubeseopro.data.SettingsManager
import com.srcreationfarm.youtubeseopro.databinding.ActivityMainBinding
import com.srcreationfarm.youtubeseopro.model.SeoResult
import com.srcreationfarm.youtubeseopro.network.GeminiSeoService
import com.srcreationfarm.youtubeseopro.utils.ThemeManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settings: SettingsManager
    private val seoService = GeminiSeoService()

    private val screenshotUris = arrayOfNulls<Uri>(3)
    private var activeSlotIndex = 0
    private var appliedThemeName = ""

    private val pickSingleImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            screenshotUris[activeSlotIndex] = uri
            updateSlotPreview(activeSlotIndex, uri)
        }
    }

    private val pickMultipleVisualMediaLauncher = registerForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(3)
    ) { uris ->
        handleMultipleSelectedUris(uris)
    }

    private val pickMultipleFallbackLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        handleMultipleSelectedUris(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        settings = SettingsManager(this)
        appliedThemeName = settings.colorTheme
        ThemeManager.applyTheme(this, settings)
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        setupDropdowns()
        setupListeners()
        refreshApiBanner()
    }

    override fun onResume() {
        super.onResume()
        if (appliedThemeName != settings.colorTheme) {
            recreate()
            return
        }
        refreshApiBanner()
    }

    private fun handleMultipleSelectedUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val selected = uris.take(3)
        for (i in selected.indices) {
            screenshotUris[i] = selected[i]
            updateSlotPreview(i, selected[i])
        }
        if (selected.size < 3) {
            Toast.makeText(
                this,
                "${selected.size}টি ছবি সিলেক্ট হয়েছে। বাকি স্লটে ট্যাপ করে মোট ৩টি পূর্ণ করুন।",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Toast.makeText(this, "৩টি স্ক্রিনশট একসাথে লোড হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchMultiImagePicker() {
        try {
            pickMultipleVisualMediaLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        } catch (e: Exception) {
            pickMultipleFallbackLauncher.launch("image/*")
        }
    }

    private fun refreshApiBanner() {
        binding.cardApiWarning.visibility = if (!settings.hasAnyValidKey()) View.VISIBLE else View.GONE
    }

    private fun setupDropdowns() {
        val languages = listOf("Bengali (বাংলা)", "English", "Bengali & English Mix")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, languages)
        binding.dropdownLanguage.setAdapter(adapter)
    }

    private fun setupListeners() {
        binding.cardApiWarning.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnQuickSetKey.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnSelectThreeAtOnce.setOnClickListener {
            launchMultiImagePicker()
        }

        binding.cardShot1.setOnClickListener {
            if (screenshotUris.all { it == null }) {
                launchMultiImagePicker()
            } else {
                activeSlotIndex = 0
                pickSingleImageLauncher.launch("image/*")
            }
        }
        binding.cardShot2.setOnClickListener {
            if (screenshotUris.all { it == null }) {
                launchMultiImagePicker()
            } else {
                activeSlotIndex = 1
                pickSingleImageLauncher.launch("image/*")
            }
        }
        binding.cardShot3.setOnClickListener {
            if (screenshotUris.all { it == null }) {
                launchMultiImagePicker()
            } else {
                activeSlotIndex = 2
                pickSingleImageLauncher.launch("image/*")
            }
        }

        binding.btnGenerate.setOnClickListener {
            generateSeo()
        }

        binding.btnReset.setOnClickListener {
            resetWorkspace()
        }

        binding.btnCopyTitle.setOnClickListener {
            copyText("Title", binding.tvResultTitle.text.toString())
        }
        binding.btnCopyDesc.setOnClickListener {
            copyText("Description", binding.tvResultDesc.text.toString())
        }
        binding.btnCopyTags.setOnClickListener {
            copyText("Hashtags", binding.tvResultTags.text.toString())
        }
    }

    private fun updateSlotPreview(index: Int, uri: Uri?) {
        when (index) {
            0 -> {
                binding.imgShot1.setImageURI(uri)
                binding.txtShot1.visibility = if (uri == null) View.VISIBLE else View.GONE
            }
            1 -> {
                binding.imgShot2.setImageURI(uri)
                binding.txtShot2.visibility = if (uri == null) View.VISIBLE else View.GONE
            }
            2 -> {
                binding.imgShot3.setImageURI(uri)
                binding.txtShot3.visibility = if (uri == null) View.VISIBLE else View.GONE
            }
        }
    }

    private fun resetWorkspace() {
        for (i in 0..2) {
            screenshotUris[i] = null
            updateSlotPreview(i, null)
        }
        binding.etKeyword.setText("")
        binding.cardProgress.visibility = View.GONE
        binding.layoutResults.visibility = View.GONE
        Toast.makeText(this, "রিসেট সম্পন্ন হয়েছে", Toast.LENGTH_SHORT).show()
    }

    private fun updateProgressUi(percent: Int, message: String) {
        runOnUiThread {
            binding.cardProgress.visibility = View.VISIBLE
            binding.progressBarLinear.setProgressCompat(percent.coerceIn(0, 100), true)
            binding.tvProgressPercent.text = "${percent.coerceIn(0, 100)}%"
            binding.tvProgressStatus.text = message
        }
    }

    private fun generateSeo() {
        if (!settings.hasAnyValidKey()) {
            Toast.makeText(this, "অনুগ্রহ করে আগে Settings থেকে API Key সেট করুন", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }

        val validUris = screenshotUris.filterNotNull()
        if (validUris.size < 3) {
            Toast.makeText(this, "অনুগ্রহ করে ভিডিওর ৩টি স্ক্রিনশটই নির্বাচন করুন", Toast.LENGTH_SHORT).show()
            return
        }

        val lang = binding.dropdownLanguage.text.toString().ifBlank { "Bengali (বাংলা)" }
        val keyword = binding.etKeyword.text?.toString().orEmpty()

        binding.btnGenerate.isEnabled = false
        binding.btnSelectThreeAtOnce.isEnabled = false
        binding.layoutResults.visibility = View.GONE
        updateProgressUi(1, "প্রক্রিয়া শুরু হচ্ছে...")

        lifecycleScope.launch {
            val result = seoService.generateSeoFromScreenshots(
                context = this@MainActivity,
                primaryGeminiKey = settings.apiKey,
                backupGeminiKey = settings.backupGeminiKey,
                groqApiKey = settings.groqApiKey,
                preferredMode = settings.selectedModel,
                imageUris = validUris,
                language = lang,
                keywordHint = keyword,
                onProgress = { pct, msg ->
                    updateProgressUi(pct, msg)
                }
            )

            binding.btnGenerate.isEnabled = true
            binding.btnSelectThreeAtOnce.isEnabled = true

            result.onSuccess { parsed ->
                updateProgressUi(100, "SEO তৈরি ১০০% সম্পন্ন হয়েছে!")
                binding.tvResultTitle.text = parsed.title
                binding.tvResultDesc.text = parsed.description
                binding.tvResultTags.text = parsed.hashtags
                binding.layoutResults.visibility = View.VISIBLE

                if (settings.autoSaveHistory) {
                    val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                    settings.addHistory(
                        SeoResult(
                            title = parsed.title,
                            description = parsed.description,
                            hashtags = parsed.hashtags,
                            language = lang,
                            timestamp = dateStr
                        )
                    )
                }
            }.onFailure { err ->
                binding.cardProgress.visibility = View.GONE
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("বিশ্লেষণ ব্যর্থ হয়েছে")
                    .setMessage(err.message ?: "অজানা ত্রুটি ঘটেছে।")
                    .setPositiveButton("আবার চেষ্টা করুন") { _, _ ->
                        generateSeo()
                    }
                    .setNegativeButton("বাতিল", null)
                    .show()
            }
        }
    }

    private fun copyText(label: String, text: String) {
        if (text.isBlank()) return
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, "$label কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_history -> {
                startActivity(Intent(this, HistoryActivity::class.java))
                true
            }
            R.id.action_theme -> {
                showQuickThemeDialog()
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_about -> {
                startActivity(Intent(this, AboutActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showQuickThemeDialog() {
        val themes = ThemeManager.colorThemes.toTypedArray()
        val currentIdx = themes.indexOf(settings.colorTheme).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Select Color Theme")
            .setSingleChoiceItems(themes, currentIdx) { dialog, which ->
                settings.colorTheme = themes[which]
                dialog.dismiss()
                recreate()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
