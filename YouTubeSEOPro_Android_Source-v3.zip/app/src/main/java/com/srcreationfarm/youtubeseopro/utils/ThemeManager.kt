package com.srcreationfarm.youtubeseopro.utils

import android.app.Activity
import androidx.appcompat.app.AppCompatDelegate
import com.srcreationfarm.youtubeseopro.R
import com.srcreationfarm.youtubeseopro.data.SettingsManager

object ThemeManager {

    val colorThemes = listOf(
        "Midnight Gold",
        "Ocean Blue",
        "Emerald Green",
        "Royal Purple",
        "Sunset Coral",
        "Graphite Cyan",
        "Rose Quartz",
        "Arctic Mint",
        "Light Day"
    )

    val appearanceModes = listOf(
        "System Default",
        "Light Mode",
        "Dark Mode"
    )

    fun applyTheme(activity: Activity, settings: SettingsManager) {
        when (settings.appearanceMode) {
            1 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            2 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }

        val themeRes = when (settings.colorTheme) {
            "Ocean Blue" -> R.style.Theme_YouTubeSEOPro_OceanBlue
            "Emerald Green" -> R.style.Theme_YouTubeSEOPro_EmeraldGreen
            "Royal Purple" -> R.style.Theme_YouTubeSEOPro_RoyalPurple
            "Sunset Coral" -> R.style.Theme_YouTubeSEOPro_SunsetCoral
            "Graphite Cyan" -> R.style.Theme_YouTubeSEOPro_GraphiteCyan
            "Rose Quartz" -> R.style.Theme_YouTubeSEOPro_RoseQuartz
            "Arctic Mint" -> R.style.Theme_YouTubeSEOPro_ArcticMint
            "Light Day" -> R.style.Theme_YouTubeSEOPro_LightDay
            else -> R.style.Theme_YouTubeSEOPro_MidnightGold
        }
        activity.setTheme(themeRes)
    }
}
