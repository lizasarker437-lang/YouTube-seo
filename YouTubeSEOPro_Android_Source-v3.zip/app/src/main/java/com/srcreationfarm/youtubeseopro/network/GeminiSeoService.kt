package com.srcreationfarm.youtubeseopro.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.srcreationfarm.youtubeseopro.utils.SeoResponseParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class GeminiSeoService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .callTimeout(150, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val gson = Gson()

    suspend fun generateSeoFromScreenshots(
        context: Context,
        primaryGeminiKey: String,
        backupGeminiKey: String,
        groqApiKey: String,
        preferredMode: String,
        imageUris: List<Uri>,
        language: String,
        keywordHint: String,
        onProgress: (Int, String) -> Unit
    ): Result<SeoResponseParser.ParsedSeo> = withContext(Dispatchers.IO) {
        try {
            onProgress(5, "স্ক্রিনশট অপ্টিমাইজেশন শুরু হচ্ছে...")

            val base64Images = mutableListOf<String>()
            for ((index, uri) in imageUris.withIndex()) {
                val stepPct = 10 + (index * 8)
                onProgress(stepPct, "স্ক্রিনশট ${index + 1} কম্প্রেস করা হচ্ছে...")
                val encoded = encodeUriToFastBase64(context, uri)
                    ?: return@withContext Result.failure(Exception("স্ক্রিনশট ${index + 1} প্রসেস করতে সমস্যা হয়েছে।"))
                base64Images.add(encoded)
            }

            val extraInfo = if (keywordHint.isNotBlank()) {
                "অতিরিক্ত কিওয়ার্ড বা বিষয়: $keywordHint"
            } else {
                ""
            }

            val prompt = "তুমি একজন প্রফেশনাল YouTube SEO এবং কন্টেন্ট স্ট্র্যাটেজিস্ট।\n" +
                "তোমাকে একটি ভিডিওর ৩টি স্ক্রিনশট দেওয়া হয়েছে। এই ৩টি স্ক্রিনশট গভীরভাবে বিশ্লেষণ করে ভিডিওটির মূল বিষয়বস্তু, ধরন, দৃশ্যপট এবং দর্শকদের আগ্রহের জায়গা খুঁজে বের করো।\n" +
                "$extraInfo\n\n" +
                "ভাষা নির্দেশনা: আউটপুট অবশ্যই $language ভাষায় তৈরি করবে।\n\n" +
                "নিচের ঠিক এই ফরম্যাটে উত্তর দাও (কোনো বাড়তি ভূমিকা বা উপসংহার লিখবে না):\n\n" +
                "[TITLE]\n(এখানে উচ্চ-CTR সম্পন্ন, আকর্ষণীয় এবং সার্চ-ফ্রেন্ডলি একটি সেরা ইউটিউব টাইটেল লিখবে)\n\n" +
                "[DESCRIPTION]\n(এখানে ইউটিউব অ্যালগরিদম ও এসইও-বান্ধব বিস্তারিত ডেসক্রিপশন লিখবে। প্রথম ২ লাইনে মূল কিওয়ার্ড রাখবে, এরপর ভিডিওর সারসংক্ষেপ ও দর্শকদের জন্য কল-টু-অ্যাকশন যুক্ত করবে)\n\n" +
                "[HASHTAGS]\n(এখানে ১৫টি হাই-র‍্যাংকিং এবং প্রাসঙ্গিক ইউটিউব হ্যাশট্যাগ স্পেস দিয়ে লিখবে, যেমন: #tag1 #tag2 #tag3)"

            // Detect if user pasted a Groq key (gsk_...) into any field
            val effectiveGroqKey = when {
                groqApiKey.startsWith("gsk_") -> groqApiKey
                primaryGeminiKey.startsWith("gsk_") -> primaryGeminiKey
                backupGeminiKey.startsWith("gsk_") -> backupGeminiKey
                else -> groqApiKey
            }

            val geminiKeys = listOf(primaryGeminiKey, backupGeminiKey)
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("gsk_") }
                .distinct()

            val networkFinished = AtomicBoolean(false)
            val progressJob = launch {
                var currentPct = 38
                while (isActive && !networkFinished.get() && currentPct < 93) {
                    val statusMsg = when {
                        currentPct < 55 -> "AI সার্ভারে ছবি পাঠানো হচ্ছে ($currentPct%)..."
                        currentPct < 78 -> "AI ইঞ্জিন স্ক্রিনশট বিশ্লেষণ করছে ($currentPct%)..."
                        else -> "টাইটেল, ডেসক্রিপশন ও হ্যাশট্যাগ তৈরি হচ্ছে ($currentPct%)..."
                    }
                    onProgress(currentPct, statusMsg)
                    delay(450)
                    currentPct += 2
                }
            }

            var lastErrorMsg = "সার্ভার ব্যস্ত রয়েছে।"

            // STEP A: Try Gemini Multi-Model Auto-Fallback Pool across all provided Gemini keys
            for ((keyIdx, gKey) in geminiKeys.withIndex()) {
                val candidateModels = buildSmartModelPool(gKey, preferredMode)

                for ((modelIdx, modelName) in candidateModels.withIndex()) {
                    // For each model, if it hits temporary 503 High Demand, we immediately hop to the next uncongested model!
                    val attemptResult = callGeminiModel(
                        apiKey = gKey,
                        model = modelName,
                        prompt = prompt,
                        base64Images = base64Images
                    )

                    if (attemptResult.isSuccess) {
                        networkFinished.set(true)
                        progressJob.cancel()
                        onProgress(100, "SEO তৈরি ১০০% সম্পন্ন হয়েছে! ($modelName)")
                        return@withContext Result.success(SeoResponseParser.parse(attemptResult.getOrThrow()))
                    } else {
                        val errText = attemptResult.exceptionOrNull()?.message.orEmpty()
                        lastErrorMsg = errText

                        // If API key itself is invalid (400 API_KEY_INVALID), break out of this key's model loop and try next key
                        if (errText.contains("API_KEY_INVALID", ignoreCase = true) ||
                            errText.contains("API key not valid", ignoreCase = true)
                        ) {
                            break
                        }

                        // If high demand / overloaded / unavailable / deprecated / 429 / 503 -> immediately switch to next model!
                        val nextModel = candidateModels.getOrNull(modelIdx + 1)
                        if (nextModel != null) {
                            onProgress(
                                (50 + modelIdx * 6).coerceAtMost(88),
                                "$modelName ব্যস্ত, স্বয়ংক্রিয়ভাবে $nextModel ইঞ্জিনে সুইচ হচ্ছে..."
                            )
                            delay(350)
                        }
                    }
                }

                // Second pass with short cool-down if all models had momentary spike on this key
                for (retryModel in candidateModels.take(3)) {
                    onProgress(85, "সার্ভার কিউ রিফ্রেশ করে $retryModel-এ পুনরায় চেষ্টা করা হচ্ছে...")
                    delay(1500)
                    val retryRes = callGeminiModel(
                        apiKey = gKey,
                        model = retryModel,
                        prompt = prompt,
                        base64Images = base64Images
                    )
                    if (retryRes.isSuccess) {
                        networkFinished.set(true)
                        progressJob.cancel()
                        onProgress(100, "SEO তৈরি ১০০% সম্পন্ন হয়েছে!")
                        return@withContext Result.success(SeoResponseParser.parse(retryRes.getOrThrow()))
                    }
                }
            }

            // STEP B: If Groq API Key is configured, automatically failover to Groq Vision API!
            if (effectiveGroqKey.isNotBlank()) {
                onProgress(88, "ব্যাকআপ Groq Vision AI ইঞ্জিনে সুইচ করা হচ্ছে...")
                val groqRes = callGroqVisionFallback(
                    groqKey = effectiveGroqKey,
                    prompt = prompt,
                    base64Images = base64Images
                )
                if (groqRes.isSuccess) {
                    networkFinished.set(true)
                    progressJob.cancel()
                    onProgress(100, "SEO তৈরি ১০০% সম্পন্ন হয়েছে! (Groq Vision)")
                    return@withContext Result.success(SeoResponseParser.parse(groqRes.getOrThrow()))
                } else {
                    lastErrorMsg = groqRes.exceptionOrNull()?.message ?: lastErrorMsg
                }
            }

            networkFinished.set(true)
            progressJob.cancel()
            Result.failure(Exception(lastErrorMsg))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildSmartModelPool(apiKey: String, preferredMode: String): List<String> {
        val pool = mutableListOf<String>()

        // If user selected a specific model first, put it at the top of the queue
        if (preferredMode.startsWith("gemini-")) {
            pool.add(preferredMode)
        }

        // Dynamic discovery: ask Google API which generateContent models are currently live for this user
        val discovered = fetchAvailableGeminiModels(apiKey)

        // Prioritize Lite & Flash models that have independent, low-congestion traffic queues
        val priorityOrder = listOf(
            "gemini-3.8-flash",
            "gemini-3.8-flash-lite",
            "gemini-3.8-pro",
            "gemini-2.5-flash-lite",
            "gemini-2.5-flash",
            "gemini-2.0-flash-lite",
            "gemini-2.0-flash",
            "gemini-flash-latest",
            "gemini-flash-lite-latest",
            "gemini-pro-latest"
        )

        if (discovered.isNotEmpty()) {
            // Add discovered models that match priority order first
            for (p in priorityOrder) {
                if (discovered.contains(p) && !pool.contains(p)) {
                    pool.add(p)
                }
            }
            // Add any other discovered flash/pro multimodal models
            for (d in discovered) {
                if (!pool.contains(d) && (d.contains("flash") || d.contains("pro"))) {
                    pool.add(d)
                }
            }
        }

        // Always append static fallback names so even if discovery fails, all known endpoints are tried
        for (fallback in priorityOrder) {
            if (!pool.contains(fallback)) {
                pool.add(fallback)
            }
        }

        return pool
    }

    private fun fetchAvailableGeminiModels(apiKey: String): List<String> {
        return try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val body = resp.body?.string().orEmpty()
                val root = gson.fromJson(body, JsonObject::class.java)
                val modelsArr = root?.getAsJsonArray("models") ?: return emptyList()
                val result = mutableListOf<String>()
                for (elem in modelsArr) {
                    val obj = elem.asJsonObject
                    val name = obj.get("name")?.asString.orEmpty().removePrefix("models/")
                    val methods = obj.getAsJsonArray("supportedGenerationMethods")?.map { it.asString }.orEmpty()
                    val isInvalidForTextSeo = name.contains("tts") ||
                        name.contains("embedding") ||
                        name.contains("imagen") ||
                        name.contains("veo") ||
                        name.contains("audio") ||
                        name.contains("aqa") ||
                        name.contains("bisheng")
                    if (methods.contains("generateContent") && !isInvalidForTextSeo) {
                        result.add(name)
                    }
                }
                result
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun callGeminiModel(
        apiKey: String,
        model: String,
        prompt: String,
        base64Images: List<String>
    ): Result<String> {
        return try {
            val partsArray = JsonArray()
            partsArray.add(JsonObject().apply { addProperty("text", prompt) })

            for (b64 in base64Images) {
                val inlineData = JsonObject().apply {
                    addProperty("mime_type", "image/jpeg")
                    addProperty("data", b64)
                }
                partsArray.add(JsonObject().apply { add("inline_data", inlineData) })
            }

            val rootBody = JsonObject().apply {
                add("contents", JsonArray().apply {
                    add(JsonObject().apply { add("parts", partsArray) })
                })
                add("generationConfig", JsonObject().apply {
                    addProperty("temperature", 0.7)
                    addProperty("maxOutputTokens", 2048)
                })
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val requestBody = gson.toJson(rootBody).toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url(url).post(requestBody).build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errObj = runCatching { gson.fromJson(responseStr, JsonObject::class.java) }.getOrNull()
                    val apiErrMsg = errObj?.getAsJsonObject("error")?.get("message")?.asString
                        ?: "HTTP ${response.code}"
                    return Result.failure(Exception(apiErrMsg))
                }

                val jsonResponse = gson.fromJson(responseStr, JsonObject::class.java)
                val generatedText = jsonResponse
                    ?.getAsJsonArray("candidates")
                    ?.get(0)?.asJsonObject
                    ?.getAsJsonObject("content")
                    ?.getAsJsonArray("parts")
                    ?.get(0)?.asJsonObject
                    ?.get("text")?.asString
                    .orEmpty()

                if (generatedText.isBlank()) {
                    return Result.failure(Exception("Empty response from $model"))
                }
                Result.success(generatedText)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun callGroqVisionFallback(
        groqKey: String,
        prompt: String,
        base64Images: List<String>
    ): Result<String> {
        val groqModels = listOf(
            "meta-llama/llama-4-scout-17b-16e-instruct",
            "llama-3.2-90b-vision-preview",
            "llama-3.2-11b-vision-preview"
        )
        var lastErr = "Groq Vision fallback error"

        for (gModel in groqModels) {
            try {
                val contentArr = JsonArray()
                contentArr.add(JsonObject().apply {
                    addProperty("type", "text")
                    addProperty("text", prompt)
                })
                for (b64 in base64Images) {
                    contentArr.add(JsonObject().apply {
                        addProperty("type", "image_url")
                        add("image_url", JsonObject().apply {
                            addProperty("url", "data:image/jpeg;base64,$b64")
                        })
                    })
                }

                val bodyObj = JsonObject().apply {
                    addProperty("model", gModel)
                    add("messages", JsonArray().apply {
                        add(JsonObject().apply {
                            addProperty("role", "user")
                            add("content", contentArr)
                        })
                    })
                    addProperty("temperature", 0.7)
                    addProperty("max_tokens", 2048)
                }

                val reqBody = gson.toJson(bodyObj).toRequestBody("application/json; charset=utf-8".toMediaType())
                val req = Request.Builder()
                    .url("https://api.groq.com/openai/v1/chat/completions")
                    .addHeader("Authorization", "Bearer $groqKey")
                    .post(reqBody)
                    .build()

                client.newCall(req).execute().use { resp ->
                    val respStr = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val root = gson.fromJson(respStr, JsonObject::class.java)
                        val text = root
                            ?.getAsJsonArray("choices")
                            ?.get(0)?.asJsonObject
                            ?.getAsJsonObject("message")
                            ?.get("content")?.asString
                            .orEmpty()
                        if (text.isNotBlank()) {
                            return Result.success(text)
                        }
                    } else {
                        lastErr = respStr
                    }
                }
            } catch (e: Exception) {
                lastErr = e.message ?: "Groq connection failed"
            }
        }
        return Result.failure(Exception(lastErr))
    }

    private fun encodeUriToFastBase64(context: Context, uri: Uri): String? {
        return try {
            val boundsOptions = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, boundsOptions)
            }
            if (boundsOptions.outWidth <= 0 || boundsOptions.outHeight <= 0) return null

            val maxDim = 640
            var sampleSize = 1
            while (boundsOptions.outWidth / sampleSize > maxDim * 2 || boundsOptions.outHeight / sampleSize > maxDim * 2) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
            }
            val decoded = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            } ?: return null

            val ratio = minOf(maxDim.toFloat() / decoded.width, maxDim.toFloat() / decoded.height, 1.0f)
            val targetW = (decoded.width * ratio).toInt().coerceAtLeast(1)
            val targetH = (decoded.height * ratio).toInt().coerceAtLeast(1)

            val scaled = Bitmap.createScaledBitmap(decoded, targetW, targetH, true)
            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 70, baos)
            if (scaled != decoded) scaled.recycle()
            decoded.recycle()

            Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }
}
