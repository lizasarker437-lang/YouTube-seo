package com.srcreationfarm.youtubeseopro

import com.srcreationfarm.youtubeseopro.utils.SeoResponseParser
import org.junit.Assert.assertEquals
import org.junit.Test

class SeoParserUnitTest {

    @Test
    fun testStructuredResponseParsing() {
        val sample = "[TITLE]\nAmazing Village Farming Vlog\n[DESCRIPTION]\nWatch our daily farm routine in Bangladesh.\n[HASHTAGS]\n#farming #vlog #srcreationfarm"
        val parsed = SeoResponseParser.parse(sample)
        assertEquals("Amazing Village Farming Vlog", parsed.title)
        assertEquals("Watch our daily farm routine in Bangladesh.", parsed.description)
        assertEquals("#farming #vlog #srcreationfarm", parsed.hashtags)
    }
}
