package com.srcreationfarm.youtubeseopro

import com.srcreationfarm.youtubeseopro.utils.SeoResponseParser
import org.junit.Assert.assertEquals
import org.junit.Test

class SeoParserUnitTest {

    @Test
    fun testFiveFieldStructuredResponseParsing() {
        val sample = buildString {
            appendLine("[TITLE]")
            appendLine("Amazing Village Farming Vlog")
            appendLine("[DESCRIPTION]")
            appendLine("Watch our daily farm routine in Bangladesh.")
            appendLine("[HASHTAGS]")
            appendLine("#farming #vlog #srcreationfarm")
            appendLine("[TAGS]")
            appendLine("farming vlog, bangladesh village, sr creation farm")
            appendLine("[EXTRA]")
            append("১০০% দেশি খামার!")
        }
        val parsed = SeoResponseParser.parse(sample)
        assertEquals("Amazing Village Farming Vlog", parsed.title)
        assertEquals("Watch our daily farm routine in Bangladesh.", parsed.description)
        assertEquals("#farming #vlog #srcreationfarm", parsed.hashtags)
        assertEquals("farming vlog, bangladesh village, sr creation farm", parsed.studioTags)
        assertEquals("১০০% দেশি খামার!", parsed.extraHook)
    }
}
