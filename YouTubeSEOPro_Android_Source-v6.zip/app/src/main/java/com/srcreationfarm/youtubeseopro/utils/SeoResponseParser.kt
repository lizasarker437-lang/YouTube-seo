package com.srcreationfarm.youtubeseopro.utils

object SeoResponseParser {

    data class ParsedSeo(
        val title: String,
        val description: String,
        val hashtags: String,
        val studioTags: String = "",
        val extraHook: String = ""
    )

    fun parse(rawText: String): ParsedSeo {
        val titleRegex = Regex("\\[TITLE\\](.*?)(?=\\[DESCRIPTION\\]|\\[HASHTAGS\\]|\\[TAGS\\]|\\[EXTRA\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val descRegex = Regex("\\[DESCRIPTION\\](.*?)(?=\\[HASHTAGS\\]|\\[TAGS\\]|\\[EXTRA\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val hashtagsRegex = Regex("\\[HASHTAGS\\](.*?)(?=\\[TAGS\\]|\\[EXTRA\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val tagsRegex = Regex("\\[TAGS\\](.*?)(?=\\[EXTRA\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val extraRegex = Regex("\\[EXTRA\\](.*)", RegexOption.DOT_MATCHES_ALL)

        val title = titleRegex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()
        val desc = descRegex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()
        val hashtags = hashtagsRegex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()
        val studioTags = tagsRegex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()
        val extraHook = extraRegex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()

        return if (title.isEmpty() && desc.isEmpty() && hashtags.isEmpty()) {
            ParsedSeo(
                title = "Generated SEO Result",
                description = rawText.trim(),
                hashtags = "",
                studioTags = "",
                extraHook = ""
            )
        } else {
            ParsedSeo(
                title = title,
                description = desc,
                hashtags = hashtags,
                studioTags = studioTags,
                extraHook = extraHook
            )
        }
    }
}
