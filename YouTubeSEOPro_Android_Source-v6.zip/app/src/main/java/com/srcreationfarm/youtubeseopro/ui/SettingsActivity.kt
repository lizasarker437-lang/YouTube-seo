package com.srcreationfarm.youtubeseopro.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.srcreationfarm.youtubeseopro.data.SettingsManager
import com.srcreationfarm.youtubeseopro.databinding.ActivitySettingsBinding
import com.srcreationfarm.youtubeseopro.utils.ThemeManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var settings: SettingsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        settings = SettingsManager(this)
        ThemeManager.applyTheme(this, settings)
        super.onCreate(savedInstanceState)

        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbarSettings.setNavigationOnClickListener { finish() }

        loadCurrentSettings()
        setupListeners()
    }

    private fun loadCurrentSettings() {
        binding.etApiKey.setText(settings.apiKey)
        binding.etBackupGeminiKey.setText(settings.backupGeminiKey)
        binding.etGroqApiKey.setText(settings.groqApiKey)
        binding.switchTurboCollage.isChecked = settings.turboCollageMode
        binding.switchAutoSaveHistory.isChecked = settings.autoSaveHistory

        val models = listOf(
            "⚡ Turbo Parallel Race (সবচেয়ে দ্রুত)",
            "gemini-flash-lite-latest",
            "gemini-3.8-flash-lite",
            "gemini-3.8-flash",
            "gemini-flash-latest"
        )
        binding.dropdownModel.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, models))
        binding.dropdownModel.setText(settings.selectedModel, false)

        binding.dropdownAppearance.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, ThemeManager.appearanceModes)
        )
        val appIdx = settings.appearanceMode.coerceIn(0, ThemeManager.appearanceModes.lastIndex)
        binding.dropdownAppearance.setText(ThemeManager.appearanceModes[appIdx], false)

        binding.dropdownColorTheme.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, ThemeManager.colorThemes)
        )
        binding.dropdownColorTheme.setText(settings.colorTheme, false)
    }

    private fun setupListeners() {
        binding.btnSaveSettings.setOnClickListener {
            settings.apiKey = binding.etApiKey.text?.toString().orEmpty()
            settings.backupGeminiKey = binding.etBackupGeminiKey.text?.toString().orEmpty()
            settings.groqApiKey = binding.etGroqApiKey.text?.toString().orEmpty()
            settings.selectedModel = binding.dropdownModel.text.toString().ifBlank { SettingsManager.DEFAULT_MODEL }
            settings.turboCollageMode = binding.switchTurboCollage.isChecked
            settings.autoSaveHistory = binding.switchAutoSaveHistory.isChecked

            val selectedApp = binding.dropdownAppearance.text.toString()
            val appIdx = ThemeManager.appearanceModes.indexOf(selectedApp).coerceAtLeast(0)
            settings.appearanceMode = appIdx

            val selectedTheme = binding.dropdownColorTheme.text.toString()
            if (selectedTheme.isNotBlank()) {
                settings.colorTheme = selectedTheme
            }

            Toast.makeText(this, "Turbo Settings সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
            finish()
        }

        binding.btnClearAllData.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Confirm Reset")
                .setMessage("সব সংরক্ষিত SEO হিস্ট্রি এবং থিম সেটিংস রিসেট করতে চান? (API Key সংরক্ষিত থাকবে)")
                .setPositiveButton("Reset") { _, _ ->
                    settings.clearAll()
                    Toast.makeText(this, "ডেটা রিসেট সম্পন্ন হয়েছে", Toast.LENGTH_SHORT).show()
                    recreate()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
}
