package com.srcreationfarm.youtubeseopro.model

data class SeoResult(
    val id: Long = System.currentTimeMillis(),
    val sectionType: String = "YouTube Video",
    val title: String,
    val description: String,
    val hashtags: String,
    val studioTags: String = "",
    val extraHook: String = "",
    val language: String,
    val timestamp: String
)
