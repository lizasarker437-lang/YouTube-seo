package com.srcreationfarm.youtubeseopro.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.tabs.TabLayout
import com.srcreationfarm.youtubeseopro.R
import com.srcreationfarm.youtubeseopro.data.SettingsManager
import com.srcreationfarm.youtubeseopro.databinding.ActivityMainBinding
import com.srcreationfarm.youtubeseopro.model.SeoResult
import com.srcreationfarm.youtubeseopro.network.GeminiSeoService
import com.srcreationfarm.youtubeseopro.utils.SeoResponseParser
import com.srcreationfarm.youtubeseopro.utils.ThemeManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settings: SettingsManager
    private val seoService = GeminiSeoService()

    private val screenshotUris = arrayOfNulls<Uri>(3)
    private var activeSlotIndex = 0
    private var appliedThemeName = ""

    private var isShortsSectionActive = false

    private var cachedVideoSeo: SeoResponseParser.ParsedSeo? = null
    private var cachedShortsSeo: SeoResponseParser.ParsedSeo? = null

    private val pickSingleImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            screenshotUris[activeSlotIndex] = uri
            updateSlotPreview(activeSlotIndex, uri)
        }
    }

    private val pickMultipleVisualMediaLauncher = registerForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(3)
    ) { uris ->
        handleMultipleSelectedUris(uris)
    }

    private val pickMultipleFallbackLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        handleMultipleSelectedUris(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        settings = SettingsManager(this)
        appliedThemeName = settings.colorTheme
        ThemeManager.applyTheme(this, settings)
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        setupDropdowns()
        setupSectionTabs()
        setupListeners()
        refreshApiBanner()
        applyActiveSectionUi()
    }

    override fun onResume() {
        super.onResume()
        if (appliedThemeName != settings.colorTheme) {
            recreate()
            return
        }
        refreshApiBanner()
    }

    private fun setupSectionTabs() {
        binding.tabLayoutSections.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                isShortsSectionActive = (tab?.position == 1)
                applyActiveSectionUi()
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun applyActiveSectionUi() {
        if (!isShortsSectionActive) {
            binding.tvActiveSectionBadge.text = "🎬 সেকশন ১: ইউটিউব ভিডিও (২টি টাইটেল ও ২টি ডেসক্রিপশন)"
            binding.tvActiveSectionInfo.text =
                "নিয়ম: ২টি টাইটেল (হ্যাশট্যাগ ছাড়া, সর্বোচ্চ ১০০ অক্ষর) এবং ২টি ডেসক্রিপশন (হ্যাশট্যাগসহ, সর্বোচ্চ ১০০০ অক্ষর)।"
            binding.tvScreenshotTitle.text = "১. ইউটিউব ভিডিওর ৩টি স্ক্রিনশট দিন"
            binding.btnGenerate.text = "⚡ ইউটিউব ভিডিও SEO তৈরি করুন"

            binding.layoutShortsSectionResults.visibility = View.GONE
            binding.layoutVideoSectionResults.visibility =
                if (cachedVideoSeo != null) View.VISIBLE else View.GONE
        } else {
            binding.tvActiveSectionBadge.text = "📱 সেকশন ২: ইউটিউব শর্টস (হ্যাশট্যাগসহ ৫টি টাইটেল)"
            binding.tvActiveSectionInfo.text =
                "নিয়ম: শর্টসের জন্য শুধুমাত্র হ্যাশট্যাগযুক্ত ৫টি ভাইরাল টাইটেল (প্রতিটি সর্বোচ্চ ১০০ অক্ষরের মধ্যে)।"
            binding.tvScreenshotTitle.text = "১. ইউটিউব শর্টসের ৩টি স্ক্রিনশট দিন"
            binding.btnGenerate.text = "⚡ ইউটিউব Shorts SEO তৈরি করুন"

            binding.layoutVideoSectionResults.visibility = View.GONE
            binding.layoutShortsSectionResults.visibility =
                if (cachedShortsSeo != null) View.VISIBLE else View.GONE
        }
    }

    private fun handleMultipleSelectedUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val selected = uris.take(3)
        for (i in selected.indices) {
            screenshotUris[i] = selected[i]
            updateSlotPreview(i, selected[i])
        }
        if (selected.size < 3) {
            Toast.makeText(
                this,
                "${selected.size}টি ছবি সিলেক্ট হয়েছে। বাকি স্লটে ট্যাপ করে মোট ৩টি পূর্ণ করুন।",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Toast.makeText(this, "৩টি স্ক্রিনশট একসাথে লোড হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchMultiImagePicker() {
        try {
            pickMultipleVisualMediaLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        } catch (e: Exception) {
            pickMultipleFallbackLauncher.launch("image/*")
        }
    }

    private fun refreshApiBanner() {
        binding.cardApiWarning.visibility = if (!settings.hasAnyValidKey()) View.VISIBLE else View.GONE
    }

    private fun setupDropdowns() {
        val languages = listOf("Bengali (বাংলা)", "English", "Bengali & English Mix")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, languages)
        binding.dropdownLanguage.setAdapter(adapter)
    }

    private fun setupListeners() {
        binding.cardApiWarning.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnQuickSetKey.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnSelectThreeAtOnce.setOnClickListener {
            launchMultiImagePicker()
        }

        binding.cardShot1.setOnClickListener {
            if (screenshotUris.all { it == null }) {
                launchMultiImagePicker()
            } else {
                activeSlotIndex = 0
                pickSingleImageLauncher.launch("image/*")
            }
        }
        binding.cardShot2.setOnClickListener {
            if (screenshotUris.all { it == null }) {
                launchMultiImagePicker()
            } else {
                activeSlotIndex = 1
                pickSingleImageLauncher.launch("image/*")
            }
        }
        binding.cardShot3.setOnClickListener {
            if (screenshotUris.all { it == null }) {
                launchMultiImagePicker()
            } else {
                activeSlotIndex = 2
                pickSingleImageLauncher.launch("image/*")
            }
        }

        binding.btnGenerate.setOnClickListener {
            generateSeo()
        }

        binding.btnReset.setOnClickListener {
            resetWorkspace()
        }

        binding.btnCopyVideoTitle1.setOnClickListener {
            copyText("Video Title 1", binding.tvVideoTitle1.text.toString())
        }
        binding.btnCopyVideoTitle2.setOnClickListener {
            copyText("Video Title 2", binding.tvVideoTitle2.text.toString())
        }
        binding.btnCopyVideoDesc1.setOnClickListener {
            copyText("Video Description 1", binding.tvVideoDesc1.text.toString())
        }
        binding.btnCopyVideoDesc2.setOnClickListener {
            copyText("Video Description 2", binding.tvVideoDesc2.text.toString())
        }
        binding.btnCopyAllVideoSeo.setOnClickListener {
            val v = cachedVideoSeo ?: return@setOnClickListener
            val allText = formatFullVideoSeoText(v)
            copyText("সম্পূর্ণ YouTube Video SEO", allText)
        }

        binding.btnCopyShortsTitle1.setOnClickListener {
            copyText("Shorts Title 1", binding.tvShortsTitle1.text.toString())
        }
        binding.btnCopyShortsTitle2.setOnClickListener {
            copyText("Shorts Title 2", binding.tvShortsTitle2.text.toString())
        }
        binding.btnCopyShortsTitle3.setOnClickListener {
            copyText("Shorts Title 3", binding.tvShortsTitle3.text.toString())
        }
        binding.btnCopyShortsTitle4.setOnClickListener {
            copyText("Shorts Title 4", binding.tvShortsTitle4.text.toString())
        }
        binding.btnCopyShortsTitle5.setOnClickListener {
            copyText("Shorts Title 5", binding.tvShortsTitle5.text.toString())
        }
        binding.btnCopyAllShortsSeo.setOnClickListener {
            val s = cachedShortsSeo ?: return@setOnClickListener
            val allText = formatFullShortsSeoText(s)
            copyText("৫টি শর্টস টাইটেল", allText)
        }
    }

    private fun formatFullVideoSeoText(v: SeoResponseParser.ParsedSeo): String {
        return buildString {
            appendLine("📌 [টাইটেল ১ (${v.videoTitle1.length}/100 অক্ষর)]")
            appendLine(v.videoTitle1)
            appendLine()
            appendLine("📌 [টাইটেল ২ (${v.videoTitle2.length}/100 অক্ষর)]")
            appendLine(v.videoTitle2)
            appendLine()
            appendLine("📝 [ডেসক্রিপশন ১ (${v.videoDesc1.length}/1000 অক্ষর)]")
            appendLine(v.videoDesc1)
            appendLine()
            appendLine("📝 [ডেসক্রিপশন ২ (${v.videoDesc2.length}/1000 অক্ষর)]")
            append(v.videoDesc2)
        }
    }

    private fun formatFullShortsSeoText(s: SeoResponseParser.ParsedSeo): String {
        return buildString {
            s.shortsTitles.forEachIndexed { index, title ->
                appendLine("🔥 [শর্টস টাইটেল ${index + 1} (${title.length}/100 অক্ষর)]")
                appendLine(title)
                if (index < s.shortsTitles.lastIndex) {
                    appendLine()
                }
            }
        }
    }

    private fun updateSlotPreview(index: Int, uri: Uri?) {
        when (index) {
            0 -> {
                binding.imgShot1.setImageURI(uri)
                binding.txtShot1.visibility = if (uri == null) View.VISIBLE else View.GONE
            }
            1 -> {
                binding.imgShot2.setImageURI(uri)
                binding.txtShot2.visibility = if (uri == null) View.VISIBLE else View.GONE
            }
            2 -> {
                binding.imgShot3.setImageURI(uri)
                binding.txtShot3.visibility = if (uri == null) View.VISIBLE else View.GONE
            }
        }
    }

    private fun resetWorkspace() {
        for (i in 0..2) {
            screenshotUris[i] = null
            updateSlotPreview(i, null)
        }
        cachedVideoSeo = null
        cachedShortsSeo = null
        binding.etKeyword.setText("")
        binding.cardProgress.visibility = View.GONE
        binding.layoutVideoSectionResults.visibility = View.GONE
        binding.layoutShortsSectionResults.visibility = View.GONE
        Toast.makeText(this, "রিসেট সম্পন্ন হয়েছে", Toast.LENGTH_SHORT).show()
    }

    private fun updateProgressUi(percent: Int, message: String) {
        runOnUiThread {
            binding.cardProgress.visibility = View.VISIBLE
            binding.progressBarLinear.setProgressCompat(percent.coerceIn(0, 100), true)
            binding.tvProgressPercent.text = "${percent.coerceIn(0, 100)}%"
            binding.tvProgressStatus.text = message
        }
    }

    private fun generateSeo() {
        if (!settings.hasAnyValidKey()) {
            Toast.makeText(this, "অনুগ্রহ করে আগে Settings থেকে API Key সেট করুন", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }

        val validUris = screenshotUris.filterNotNull()
        if (validUris.size < 3) {
            Toast.makeText(this, "অনুগ্রহ করে ৩টি স্ক্রিনশটই নির্বাচন করুন", Toast.LENGTH_SHORT).show()
            return
        }

        val lang = binding.dropdownLanguage.text.toString().ifBlank { "Bengali (বাংলা)" }
        val keyword = binding.etKeyword.text?.toString().orEmpty()
        val generatingShorts = isShortsSectionActive

        binding.btnGenerate.isEnabled = false
        binding.btnSelectThreeAtOnce.isEnabled = false
        if (generatingShorts) {
            binding.layoutShortsSectionResults.visibility = View.GONE
        } else {
            binding.layoutVideoSectionResults.visibility = View.GONE
        }
        updateProgressUi(5, "⚡ টার্বো ইঞ্জিন চালু হচ্ছে...")

        lifecycleScope.launch {
            val result = seoService.generateSeoFromScreenshots(
                context = this@MainActivity,
                settings = settings,
                isShortsMode = generatingShorts,
                imageUris = validUris,
                language = lang,
                keywordHint = keyword,
                onProgress = { pct, msg ->
                    updateProgressUi(pct, msg)
                }
            )

            binding.btnGenerate.isEnabled = true
            binding.btnSelectThreeAtOnce.isEnabled = true

            result.onSuccess { parsed ->
                if (!generatingShorts) {
                    cachedVideoSeo = parsed
                    binding.tvVideoTitle1.text = parsed.videoTitle1
                    binding.tvVideoTitle1Count.text = "${parsed.videoTitle1.length}/100 অক্ষর"

                    binding.tvVideoTitle2.text = parsed.videoTitle2
                    binding.tvVideoTitle2Count.text = "${parsed.videoTitle2.length}/100 অক্ষর"

                    binding.tvVideoDesc1.text = parsed.videoDesc1
                    binding.tvVideoDesc1Count.text = "${parsed.videoDesc1.length}/1000 অক্ষর"

                    binding.tvVideoDesc2.text = parsed.videoDesc2
                    binding.tvVideoDesc2Count.text = "${parsed.videoDesc2.length}/1000 অক্ষর"

                    if (!isShortsSectionActive) {
                        binding.layoutVideoSectionResults.visibility = View.VISIBLE
                    }

                    if (settings.autoSaveHistory) {
                        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                        settings.addHistory(
                            SeoResult(
                                sectionType = "🎬 YouTube Video",
                                title = parsed.videoTitle1,
                                description = parsed.videoDesc1,
                                fullFormattedOutput = formatFullVideoSeoText(parsed),
                                language = lang,
                                timestamp = dateStr
                            )
                        )
                    }
                } else {
                    cachedShortsSeo = parsed
                    val list = parsed.shortsTitles
                    val t1 = list.getOrElse(0) { "" }
                    val t2 = list.getOrElse(1) { "" }
                    val t3 = list.getOrElse(2) { "" }
                    val t4 = list.getOrElse(3) { "" }
                    val t5 = list.getOrElse(4) { "" }

                    binding.tvShortsTitle1.text = t1
                    binding.tvShortsTitle1Count.text = "${t1.length}/100 অক্ষর"

                    binding.tvShortsTitle2.text = t2
                    binding.tvShortsTitle2Count.text = "${t2.length}/100 অক্ষর"

                    binding.tvShortsTitle3.text = t3
                    binding.tvShortsTitle3Count.text = "${t3.length}/100 অক্ষর"

                    binding.tvShortsTitle4.text = t4
                    binding.tvShortsTitle4Count.text = "${t4.length}/100 অক্ষর"

                    binding.tvShortsTitle5.text = t5
                    binding.tvShortsTitle5Count.text = "${t5.length}/100 অক্ষর"

                    if (isShortsSectionActive) {
                        binding.layoutShortsSectionResults.visibility = View.VISIBLE
                    }

                    if (settings.autoSaveHistory) {
                        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                        settings.addHistory(
                            SeoResult(
                                sectionType = "📱 YouTube Shorts",
                                title = t1,
                                description = list.drop(1).joinToString(" | "),
                                fullFormattedOutput = formatFullShortsSeoText(parsed),
                                language = lang,
                                timestamp = dateStr
                            )
                        )
                    }
                }
            }.onFailure { err ->
                binding.cardProgress.visibility = View.GONE
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("বিশ্লেষণ ব্যর্থ হয়েছে")
                    .setMessage(err.message ?: "অজানা ত্রুটি ঘটেছে।")
                    .setPositiveButton("আবার চেষ্টা করুন") { _, _ ->
                        generateSeo()
                    }
                    .setNegativeButton("বাতিল", null)
                    .show()
            }
        }
    }

    private fun copyText(label: String, text: String) {
        if (text.isBlank()) return
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, "$label কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_history -> {
                startActivity(Intent(this, HistoryActivity::class.java))
                true
            }
            R.id.action_theme -> {
                showQuickThemeDialog()
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_about -> {
                startActivity(Intent(this, AboutActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showQuickThemeDialog() {
        val themes = ThemeManager.colorThemes.toTypedArray()
        val currentIdx = themes.indexOf(settings.colorTheme).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Select Color Theme")
            .setSingleChoiceItems(themes, currentIdx) { dialog, which ->
                settings.colorTheme = themes[which]
                dialog.dismiss()
                recreate()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
