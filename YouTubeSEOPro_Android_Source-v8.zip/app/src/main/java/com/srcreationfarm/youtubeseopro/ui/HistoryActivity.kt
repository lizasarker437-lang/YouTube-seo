package com.srcreationfarm.youtubeseopro.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.srcreationfarm.youtubeseopro.data.SettingsManager
import com.srcreationfarm.youtubeseopro.databinding.ActivityHistoryBinding
import com.srcreationfarm.youtubeseopro.databinding.ItemHistoryBinding
import com.srcreationfarm.youtubeseopro.model.SeoResult
import com.srcreationfarm.youtubeseopro.utils.ThemeManager

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var settings: SettingsManager
    private var historyList = mutableListOf<SeoResult>()

    override fun onCreate(savedInstanceState: Bundle?) {
        settings = SettingsManager(this)
        ThemeManager.applyTheme(this, settings)
        super.onCreate(savedInstanceState)

        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbarHistory.setNavigationOnClickListener { finish() }

        historyList = settings.getHistory()
        binding.rvHistory.layoutManager = LinearLayoutManager(this)
        binding.rvHistory.adapter = HistoryAdapter()
        updateEmptyState()
    }

    private fun updateEmptyState() {
        binding.tvEmptyHistory.visibility = if (historyList.isEmpty()) View.VISIBLE else View.GONE
    }

    inner class HistoryAdapter : RecyclerView.Adapter<HistoryAdapter.Holder>() {

        inner class Holder(val itemBinding: ItemHistoryBinding) : RecyclerView.ViewHolder(itemBinding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val b = ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return Holder(b)
        }

        override fun getItemCount(): Int = historyList.size

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = historyList[position]
            holder.itemBinding.tvItemDate.text = "${item.sectionType} • ${item.timestamp} • ${item.language}"
            holder.itemBinding.tvItemTitle.text = item.title
            holder.itemBinding.tvItemDesc.text = item.description

            holder.itemBinding.btnItemCopyAll.setOnClickListener {
                val fullText = item.fullFormattedOutput.ifBlank {
                    buildString {
                        appendLine("[${item.sectionType}]")
                        appendLine(item.title)
                        appendLine()
                        append(item.description)
                    }
                }
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("SEO Result", fullText))
                Toast.makeText(this@HistoryActivity, "সম্পূর্ণ SEO তথ্য কপি হয়েছে!", Toast.LENGTH_SHORT).show()
            }

            holder.itemBinding.btnItemDelete.setOnClickListener {
                val pos = holder.adapterPosition
                if (pos != RecyclerView.NO_POSITION) {
                    settings.deleteHistoryItem(item.id)
                    historyList.removeAt(pos)
                    notifyItemRemoved(pos)
                    updateEmptyState()
                }
            }
        }
    }
}
