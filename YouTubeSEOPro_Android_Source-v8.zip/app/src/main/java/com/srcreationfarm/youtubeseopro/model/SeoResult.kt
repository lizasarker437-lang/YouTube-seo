package com.srcreationfarm.youtubeseopro.model

data class SeoResult(
    val id: Long = System.currentTimeMillis(),
    val sectionType: String = "YouTube Video",
    val title: String,
    val description: String,
    val fullFormattedOutput: String = "",
    val language: String,
    val timestamp: String
)
