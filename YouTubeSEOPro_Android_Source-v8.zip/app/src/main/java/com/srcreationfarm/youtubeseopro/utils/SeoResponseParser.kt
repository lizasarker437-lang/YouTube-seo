package com.srcreationfarm.youtubeseopro.utils

object SeoResponseParser {

    data class ParsedSeo(
        val isShorts: Boolean = false,
        val videoTitle1: String = "",
        val videoTitle2: String = "",
        val videoDesc1: String = "",
        val videoDesc2: String = "",
        val shortsTitles: List<String> = emptyList()
    )

    fun parseVideoResponse(rawText: String): ParsedSeo {
        val t1Regex = Regex("\\[VIDEO_TITLE_1\\](.*?)(?=\\[VIDEO_TITLE_2\\]|\\[VIDEO_DESC_1\\]|\\[VIDEO_DESC_2\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val t2Regex = Regex("\\[VIDEO_TITLE_2\\](.*?)(?=\\[VIDEO_DESC_1\\]|\\[VIDEO_DESC_2\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val d1Regex = Regex("\\[VIDEO_DESC_1\\](.*?)(?=\\[VIDEO_DESC_2\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val d2Regex = Regex("\\[VIDEO_DESC_2\\](.*)", RegexOption.DOT_MATCHES_ALL)

        val rawT1 = t1Regex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()
        val rawT2 = t2Regex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()
        val rawD1 = d1Regex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()
        val rawD2 = d2Regex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()

        val cleanT1 = sanitizeVideoTitleNoHashtags(rawT1.ifBlank { rawText.lines().firstOrNull().orEmpty() })
        val cleanT2 = sanitizeVideoTitleNoHashtags(rawT2.ifBlank { cleanT1 })
        val cleanD1 = enforceDescriptionWithHashtags(rawD1.ifBlank { rawText.trim() })
        val cleanD2 = enforceDescriptionWithHashtags(rawD2.ifBlank { cleanD1 })

        return ParsedSeo(
            isShorts = false,
            videoTitle1 = cleanT1,
            videoTitle2 = cleanT2,
            videoDesc1 = cleanD1,
            videoDesc2 = cleanD2
        )
    }

    fun parseShortsResponse(rawText: String): ParsedSeo {
        val s1Regex = Regex("\\[SHORTS_TITLE_1\\](.*?)(?=\\[SHORTS_TITLE_2\\]|\\[SHORTS_TITLE_3\\]|\\[SHORTS_TITLE_4\\]|\\[SHORTS_TITLE_5\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val s2Regex = Regex("\\[SHORTS_TITLE_2\\](.*?)(?=\\[SHORTS_TITLE_3\\]|\\[SHORTS_TITLE_4\\]|\\[SHORTS_TITLE_5\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val s3Regex = Regex("\\[SHORTS_TITLE_3\\](.*?)(?=\\[SHORTS_TITLE_4\\]|\\[SHORTS_TITLE_5\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val s4Regex = Regex("\\[SHORTS_TITLE_4\\](.*?)(?=\\[SHORTS_TITLE_5\\]|$)", RegexOption.DOT_MATCHES_ALL)
        val s5Regex = Regex("\\[SHORTS_TITLE_5\\](.*)", RegexOption.DOT_MATCHES_ALL)

        val rawList = listOf(
            s1Regex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty(),
            s2Regex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty(),
            s3Regex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty(),
            s4Regex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty(),
            s5Regex.find(rawText)?.groupValues?.get(1)?.trim().orEmpty()
        )

        val fallbackLines = rawText.lines().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("[") }

        val finalShortsTitles = (0 until 5).map { idx ->
            val candidate = rawList[idx].ifBlank {
                fallbackLines.getOrNull(idx) ?: fallbackLines.firstOrNull().orEmpty()
            }
            sanitizeShortsTitleWithHashtags(candidate)
        }

        return ParsedSeo(
            isShorts = true,
            shortsTitles = finalShortsTitles
        )
    }

    // Rule for YouTube Video Title: NO hashtags allowed, max 100 characters
    fun sanitizeVideoTitleNoHashtags(input: String): String {
        val singleLine = input.lines().joinToString(" ").trim()
        val withoutHashtags = singleLine
            .replace(Regex("#\\S+"), "")
            .replace("#", "")
            .replace(Regex("\\s+"), " ")
            .trim()
        return truncateCleanly(withoutHashtags, 100)
    }

    // Rule for YouTube Video Description: Hashtags allowed/included, max 1000 characters
    fun enforceDescriptionWithHashtags(input: String): String {
        var cleaned = input.trim()
        if (!cleaned.contains("#")) {
            cleaned = buildString {
                append(cleaned)
                appendLine()
                appendLine()
                append("#youtube #video #trending")
            }
        }
        return truncateCleanly(cleaned, 1000)
    }

    // Rule for YouTube Shorts Title: Only Title with Hashtags attached, max 100 characters
    fun sanitizeShortsTitleWithHashtags(input: String): String {
        val singleLine = input.lines().joinToString(" ").replace(Regex("\\s+"), " ").trim()
        if (singleLine.isEmpty()) {
            return "Viral Shorts #shorts #viral"
        }
        if (!singleLine.contains("#")) {
            val suffix = " #shorts #viral"
            val maxBase = 100 - suffix.length
            val base = truncateCleanly(singleLine, maxBase)
            return "$base$suffix"
        }
        if (singleLine.length <= 100) {
            return singleLine
        }
        val words = singleLine.split(" ")
        val tags = words.filter { it.startsWith("#") }.take(3)
        val nonTags = words.filter { !it.startsWith("#") }
        val tagSuffix = if (tags.isNotEmpty()) " " + tags.joinToString(" ") else " #shorts"
        val allowedBaseLen = (100 - tagSuffix.length).coerceAtLeast(15)
        val trimmedBase = truncateCleanly(nonTags.joinToString(" "), allowedBaseLen)
        val combined = (trimmedBase + tagSuffix).trim()
        return if (combined.length <= 100) combined else combined.take(100).trim()
    }

    private fun truncateCleanly(text: String, maxChars: Int): String {
        if (text.length <= maxChars) return text
        val sliced = text.take(maxChars)
        val lastSpace = sliced.lastIndexOf(' ')
        return if (lastSpace > maxChars - 20 && lastSpace > 0) {
            sliced.substring(0, lastSpace).trim()
        } else {
            sliced.trim()
        }
    }
}
