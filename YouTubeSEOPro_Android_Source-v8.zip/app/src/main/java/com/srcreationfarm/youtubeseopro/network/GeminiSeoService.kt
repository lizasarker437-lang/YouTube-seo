package com.srcreationfarm.youtubeseopro.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.srcreationfarm.youtubeseopro.data.SettingsManager
import com.srcreationfarm.youtubeseopro.utils.SeoResponseParser
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

class GeminiSeoService {

    private val fastClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(28, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val gson = Gson()

    suspend fun generateSeoFromScreenshots(
        context: Context,
        settings: SettingsManager,
        isShortsMode: Boolean,
        imageUris: List<Uri>,
        language: String,
        keywordHint: String,
        onProgress: (Int, String) -> Unit
    ): Result<SeoResponseParser.ParsedSeo> = withContext(Dispatchers.IO) {
        val raceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        val activeHttpCalls = CopyOnWriteArrayList<Call>()
        val networkFinished = AtomicBoolean(false)

        try {
            val startTime = System.currentTimeMillis()
            val modeLabel = if (isShortsMode) "YouTube Shorts" else "YouTube Video"
            onProgress(10, "⚡ $modeLabel স্ক্রিনশট অপ্টিমাইজ হচ্ছে...")

            val payloadImages: List<String> = if (settings.turboCollageMode) {
                val collageBase64 = createThreeInOneCollageBase64(context, imageUris)
                    ?: return@withContext Result.failure(Exception("স্ক্রিনশট প্রসেস করতে সমস্যা হয়েছে।"))
                listOf(collageBase64)
            } else {
                imageUris.map { uri ->
                    encodeSingleFastBase64(context, uri)
                        ?: return@withContext Result.failure(Exception("স্ক্রিনশট প্রসেস করতে সমস্যা হয়েছে।"))
                }
            }

            onProgress(28, "⚡ ছবি প্রস্তুত (${payloadImages.sumOf { it.length } / 1024} KB), $modeLabel AI ইঞ্জিন চালু হচ্ছে...")

            val prompt = buildString {
                if (!isShortsMode) {
                    appendLine("তুমি একজন এক্সপার্ট YouTube Long Video SEO স্পেশালিস্ট।")
                    appendLine("ছবিতে একটি ইউটিউব ভিডিওর ৩টি স্ক্রিনশট দেওয়া হয়েছে। এগুলো বিশ্লেষণ করে ভিডিওটির মূল বিষয়বস্তু বুঝে নাও।")
                    if (keywordHint.isNotBlank()) {
                        appendLine("মূল বিষয়/কিওয়ার্ড: $keywordHint")
                    }
                    appendLine("আউটপুট ভাষা: $language।")
                    appendLine()
                    appendLine("কঠোর নিয়মাবলী (অবশ্যই মানতে হবে):")
                    appendLine("১. দুইটি আলাদা টাইটেল দিবে। টাইটেলে কোনো হ্যাশট্যাগ (#) ব্যবহার করা যাবে না এবং প্রতিটি টাইটেল অবশ্যই ১০০ অক্ষরের (100 characters) ভেতরে হতে হবে।")
                    appendLine("২. দুইটি আলাদা ডেসক্রিপশন দিবে। প্রতিটি ডেসক্রিপশনের ভেতরে প্রাসঙ্গিক এসইও হ্যাশট্যাগ (#) যুক্ত থাকবে এবং প্রতিটি ডেসক্রিপশন সর্বোচ্চ ১০০০ অক্ষরের (1000 characters) ভেতরে হতে হবে।")
                    appendLine()
                    appendLine("নিচের ঠিক এই ৪টি ট্যাগ ব্যবহার করে উত্তর দাও (কোনো বাড়তি ভূমিকা বা উপসংহার লিখবে না):")
                    appendLine()
                    appendLine("[VIDEO_TITLE_1]")
                    appendLine("(১ম আকর্ষণীয় টাইটেল - কোনো হ্যাশট্যাগ থাকবে না, সর্বোচ্চ ১০০ অক্ষর)")
                    appendLine()
                    appendLine("[VIDEO_TITLE_2]")
                    appendLine("(২য় বিকল্প আকর্ষণীয় টাইটেল - কোনো হ্যাশট্যাগ থাকবে না, সর্বোচ্চ ১০০ অক্ষর)")
                    appendLine()
                    appendLine("[VIDEO_DESC_1]")
                    appendLine("(১ম এসইও ডেসক্রিপশন + শেষে প্রাসঙ্গিক হ্যাশট্যাগসমূহ, সব মিলিয়ে সর্বোচ্চ ১০০০ অক্ষর)")
                    appendLine()
                    appendLine("[VIDEO_DESC_2]")
                    appendLine("(২য় বিকল্প এসইও ডেসক্রিপশন + শেষে প্রাসঙ্গিক হ্যাশট্যাগসমূহ, সব মিলিয়ে সর্বোচ্চ ১০০০ অক্ষর)")
                } else {
                    appendLine("তুমি একজন এক্সপার্ট YouTube Shorts ভাইরাল SEO স্পেশালিস্ট।")
                    appendLine("ছবিতে একটি YouTube Shorts ভিডিওর ৩টি স্ক্রিনশট দেওয়া হয়েছে। এগুলো বিশ্লেষণ করে শর্টসটির মূল আকর্ষণ বুঝে নাও।")
                    if (keywordHint.isNotBlank()) {
                        appendLine("মূল বিষয়/কিওয়ার্ড: $keywordHint")
                    }
                    appendLine("আউটপুট ভাষা: $language।")
                    appendLine()
                    appendLine("কঠোর নিয়মাবলী (অবশ্যই মানতে হবে):")
                    appendLine("১. YouTube Shorts-এর জন্য শুধুমাত্র ৫টি ভাইরাল টাইটেল দিবে (কোনো ডেসক্রিপশন দিবে না)।")
                    appendLine("২. প্রতিটি টাইটেলের সাথেই প্রাসঙ্গিক ভাইরাল হ্যাশট্যাগ (#shorts #viral ইত্যাদি) যুক্ত থাকবে।")
                    appendLine("৩. হ্যাশট্যাগসহ প্রতিটি শর্টস টাইটেল অবশ্যই সর্বোচ্চ ১০০ অক্ষরের (maximum 100 characters) ভেতরে হতে হবে।")
                    appendLine()
                    appendLine("নিচের ঠিক এই ৫টি ট্যাগ ব্যবহার করে উত্তর দাও (কোনো বাড়তি কথা লিখবে না):")
                    appendLine()
                    appendLine("[SHORTS_TITLE_1]")
                    appendLine("(১ম শর্টস টাইটেল + হ্যাশট্যাগ, এক লাইনে সর্বোচ্চ ১০০ অক্ষর)")
                    appendLine()
                    appendLine("[SHORTS_TITLE_2]")
                    appendLine("(২য় শর্টস টাইটেল + হ্যাশট্যাগ, এক লাইনে সর্বোচ্চ ১০০ অক্ষর)")
                    appendLine()
                    appendLine("[SHORTS_TITLE_3]")
                    appendLine("(৩য় শর্টস টাইটেল + হ্যাশট্যাগ, এক লাইনে সর্বোচ্চ ১০০ অক্ষর)")
                    appendLine()
                    appendLine("[SHORTS_TITLE_4]")
                    appendLine("(৪র্থ শর্টস টাইটেল + হ্যাশট্যাগ, এক লাইনে সর্বোচ্চ ১০০ অক্ষর)")
                    appendLine()
                    appendLine("[SHORTS_TITLE_5]")
                    appendLine("(৫ম শর্টস টাইটেল + হ্যাশট্যাগ, এক লাইনে সর্বোচ্চ ১০০ অক্ষর)")
                }
            }

            val primaryGeminiKey = settings.apiKey.trim()
            val backupGeminiKey = settings.backupGeminiKey.trim()
            val rawGroqKey = settings.groqApiKey.trim()

            val effectiveGroqKey = when {
                rawGroqKey.startsWith("gsk_") -> rawGroqKey
                primaryGeminiKey.startsWith("gsk_") -> primaryGeminiKey
                backupGeminiKey.startsWith("gsk_") -> backupGeminiKey
                else -> ""
            }

            val geminiKeys = listOf(primaryGeminiKey, backupGeminiKey)
                .filter { it.isNotBlank() && !it.startsWith("gsk_") }
                .distinct()

            raceScope.launch {
                var pct = 35
                while (isActive && !networkFinished.get() && pct < 94) {
                    val elapsedSec = (System.currentTimeMillis() - startTime) / 1000
                    val msg = when {
                        pct < 55 -> "⚡ $modeLabel AI রেসিং চলছে (${elapsedSec}s)..."
                        pct < 80 -> "⚡ দ্রুততম সার্ভার থেকে উত্তর নেওয়া হচ্ছে (${elapsedSec}s)..."
                        else -> "⚡ অক্ষর সীমা ও হ্যাশট্যাগ রুলস যাচাই হচ্ছে (${elapsedSec}s)..."
                    }
                    onProgress(pct, msg)
                    delay(300)
                    pct += 3
                }
            }

            val preferred = settings.selectedModel
            val fastModels = mutableListOf<String>()

            if (preferred.startsWith("gemini-")) {
                fastModels.add(preferred)
            }
            if (settings.lastFastestModel.isNotBlank() && !fastModels.contains(settings.lastFastestModel)) {
                fastModels.add(settings.lastFastestModel)
            }

            val defaultFastOrder = listOf(
                "gemini-flash-lite-latest",
                "gemini-3.8-flash-lite",
                "gemini-3.8-flash",
                "gemini-flash-latest",
                "gemini-2.5-flash-lite",
                "gemini-2.0-flash-lite",
                "gemini-2.0-flash"
            )
            for (m in defaultFastOrder) {
                if (!fastModels.contains(m)) fastModels.add(m)
            }

            val winnerDeferred = CompletableDeferred<Pair<String, String>>()
            val lastErrorRef = AtomicReference("সার্ভার ব্যস্ত রয়েছে, অনুগ্রহ করে আবার চেষ্টা করুন।")
            val raceJobs = CopyOnWriteArrayList<Job>()

            if (effectiveGroqKey.isNotBlank()) {
                raceJobs.add(
                    raceScope.launch {
                        val res = callGroqVisionFallback(effectiveGroqKey, prompt, payloadImages, activeHttpCalls)
                        if (res.isSuccess) {
                            if (winnerDeferred.complete("Groq-Vision" to res.getOrThrow())) {
                                activeHttpCalls.forEach { runCatching { it.cancel() } }
                            }
                        } else {
                            res.exceptionOrNull()?.message?.let { lastErrorRef.set(it) }
                        }
                    }
                )
            }

            for (gKey in geminiKeys) {
                for ((idx, modelName) in fastModels.withIndex()) {
                    raceJobs.add(
                        raceScope.launch {
                            if (idx > 0) {
                                delay(idx * 550L)
                            }
                            if (winnerDeferred.isCompleted) return@launch

                            val res = callGeminiFast(
                                apiKey = gKey,
                                model = modelName,
                                prompt = prompt,
                                base64Images = payloadImages,
                                activeCalls = activeHttpCalls
                            )
                            if (res.isSuccess) {
                                if (winnerDeferred.complete(modelName to res.getOrThrow())) {
                                    settings.lastFastestModel = modelName
                                    activeHttpCalls.forEach { runCatching { it.cancel() } }
                                }
                            } else {
                                res.exceptionOrNull()?.message?.let { err ->
                                    if (!err.contains("not found", ignoreCase = true) &&
                                        !err.contains("no longer available", ignoreCase = true) &&
                                        !err.contains("Canceled", ignoreCase = true)
                                    ) {
                                        lastErrorRef.set(err)
                                    }
                                }
                            }
                        }
                    )
                }
            }

            raceScope.launch {
                for (job in raceJobs) {
                    job.join()
                }
                if (!winnerDeferred.isCompleted) {
                    winnerDeferred.completeExceptionally(Exception(lastErrorRef.get()))
                }
            }

            val (winningModel, winningText) = winnerDeferred.await()
            networkFinished.set(true)

            val totalSeconds = ((System.currentTimeMillis() - startTime) / 1000.0)
            onProgress(100, "⚡ মাত্র ${"%.1f".format(totalSeconds)} সেকেন্ডে $modeLabel SEO সম্পন্ন! ($winningModel)")

            val parsed = if (isShortsMode) {
                SeoResponseParser.parseShortsResponse(winningText)
            } else {
                SeoResponseParser.parseVideoResponse(winningText)
            }
            Result.success(parsed)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            networkFinished.set(true)
            activeHttpCalls.forEach { runCatching { it.cancel() } }
            raceScope.cancel()
        }
    }

    private fun callGeminiFast(
        apiKey: String,
        model: String,
        prompt: String,
        base64Images: List<String>,
        activeCalls: CopyOnWriteArrayList<Call>
    ): Result<String> {
        return try {
            val partsArray = JsonArray()
            partsArray.add(JsonObject().apply { addProperty("text", prompt) })

            for (b64 in base64Images) {
                val inlineData = JsonObject().apply {
                    addProperty("mime_type", "image/jpeg")
                    addProperty("data", b64)
                }
                partsArray.add(JsonObject().apply { add("inline_data", inlineData) })
            }

            val rootBody = JsonObject().apply {
                add("contents", JsonArray().apply {
                    add(JsonObject().apply { add("parts", partsArray) })
                })
                add("generationConfig", JsonObject().apply {
                    addProperty("temperature", 0.65)
                    addProperty("maxOutputTokens", 1400)
                })
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val requestBody = gson.toJson(rootBody).toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url(url).post(requestBody).build()

            val call = fastClient.newCall(request)
            activeCalls.add(call)
            try {
                call.execute().use { response ->
                    val responseStr = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        val errObj = runCatching { gson.fromJson(responseStr, JsonObject::class.java) }.getOrNull()
                        val apiErrMsg = errObj?.getAsJsonObject("error")?.get("message")?.asString
                            ?: "HTTP ${response.code}"
                        return Result.failure(Exception(apiErrMsg))
                    }

                    val jsonResponse = gson.fromJson(responseStr, JsonObject::class.java)
                    val parts = jsonResponse
                        ?.getAsJsonArray("candidates")
                        ?.get(0)?.asJsonObject
                        ?.getAsJsonObject("content")
                        ?.getAsJsonArray("parts")

                    var extractedText = ""
                    if (parts != null) {
                        for (p in parts) {
                            val obj = p.asJsonObject
                            if (obj.has("text")) {
                                extractedText += obj.get("text").asString
                            }
                        }
                    }

                    if (extractedText.isBlank()) {
                        return Result.failure(Exception("Empty output from $model"))
                    }
                    Result.success(extractedText)
                }
            } finally {
                activeCalls.remove(call)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun callGroqVisionFallback(
        groqKey: String,
        prompt: String,
        base64Images: List<String>,
        activeCalls: CopyOnWriteArrayList<Call>
    ): Result<String> {
        val groqModels = listOf(
            "meta-llama/llama-4-scout-17b-16e-instruct",
            "llama-3.2-11b-vision-preview",
            "llama-3.2-90b-vision-preview"
        )
        var lastErr = "Groq Vision error"

        for (gModel in groqModels) {
            try {
                val contentArr = JsonArray()
                contentArr.add(JsonObject().apply {
                    addProperty("type", "text")
                    addProperty("text", prompt)
                })
                for (b64 in base64Images) {
                    contentArr.add(JsonObject().apply {
                        addProperty("type", "image_url")
                        add("image_url", JsonObject().apply {
                            addProperty("url", "data:image/jpeg;base64,$b64")
                        })
                    })
                }

                val bodyObj = JsonObject().apply {
                    addProperty("model", gModel)
                    add("messages", JsonArray().apply {
                        add(JsonObject().apply {
                            addProperty("role", "user")
                            add("content", contentArr)
                        })
                    })
                    addProperty("temperature", 0.65)
                    addProperty("max_tokens", 1400)
                }

                val reqBody = gson.toJson(bodyObj).toRequestBody("application/json; charset=utf-8".toMediaType())
                val req = Request.Builder()
                    .url("https://api.groq.com/openai/v1/chat/completions")
                    .addHeader("Authorization", "Bearer $groqKey")
                    .post(reqBody)
                    .build()

                val call = fastClient.newCall(req)
                activeCalls.add(call)
                try {
                    call.execute().use { resp ->
                        val respStr = resp.body?.string().orEmpty()
                        if (resp.isSuccessful) {
                            val root = gson.fromJson(respStr, JsonObject::class.java)
                            val text = root
                                ?.getAsJsonArray("choices")
                                ?.get(0)?.asJsonObject
                                ?.getAsJsonObject("message")
                                ?.get("content")?.asString
                                .orEmpty()
                            if (text.isNotBlank()) {
                                return Result.success(text)
                            }
                        } else {
                            lastErr = respStr
                        }
                    }
                } finally {
                    activeCalls.remove(call)
                }
            } catch (e: Exception) {
                lastErr = e.message ?: "Groq connection failed"
            }
        }
        return Result.failure(Exception(lastErr))
    }

    private fun createThreeInOneCollageBase64(context: Context, uris: List<Uri>): String? {
        return try {
            val cellW = 300
            val cellH = 320
            val collage = Bitmap.createBitmap(cellW * 3, cellH, Bitmap.Config.RGB_565)
            val canvas = Canvas(collage)
            canvas.drawColor(Color.BLACK)

            for (i in 0 until minOf(3, uris.size)) {
                val bmp = decodeSmallBitmap(context, uris[i], cellW, cellH) ?: return null
                val destRect = Rect(i * cellW, 0, (i + 1) * cellW, cellH)
                canvas.drawBitmap(bmp, null, destRect, null)
                bmp.recycle()
            }

            val baos = ByteArrayOutputStream()
            collage.compress(Bitmap.CompressFormat.JPEG, 68, baos)
            collage.recycle()

            Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    private fun decodeSmallBitmap(context: Context, uri: Uri, reqW: Int, reqH: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while (bounds.outWidth / sample > reqW * 2 || bounds.outHeight / sample > reqH * 2) {
                sample *= 2
            }
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun encodeSingleFastBase64(context: Context, uri: Uri): String? {
        val bmp = decodeSmallBitmap(context, uri, 480, 480) ?: return null
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 68, baos)
        bmp.recycle()
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }
}
