package com.srcreationfarm.youtubeseopro

import com.srcreationfarm.youtubeseopro.utils.SeoResponseParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SeoParserUnitTest {

    @Test
    fun testVideoModeTwoTitlesNoHashtagsAndTwoDescriptions() {
        val raw = buildString {
            appendLine("[VIDEO_TITLE_1]")
            appendLine("Amazing Village Farming Vlog in Bangladesh #farming #vlog")
            appendLine("[VIDEO_TITLE_2]")
            appendLine("How We Built Our Automated Poultry Cage Setup #poultry")
            appendLine("[VIDEO_DESC_1]")
            appendLine("Watch our complete farming guide and daily routine. #farming #srcreationfarm")
            appendLine("[VIDEO_DESC_2]")
            appendLine("Step by step poultry setup tutorial in Bengali. #poultry #bangladesh #vlog")
        }

        val parsed = SeoResponseParser.parseVideoResponse(raw)
        assertFalse(parsed.videoTitle1.contains("#"))
        assertFalse(parsed.videoTitle2.contains("#"))
        assertTrue(parsed.videoTitle1.length <= 100)
        assertTrue(parsed.videoTitle2.length <= 100)

        assertTrue(parsed.videoDesc1.contains("#"))
        assertTrue(parsed.videoDesc2.contains("#"))
        assertTrue(parsed.videoDesc1.length <= 1000)
        assertTrue(parsed.videoDesc2.length <= 1000)
    }

    @Test
    fun testShortsModeFiveTitlesWithHashtagsUnder100Chars() {
        val raw = buildString {
            appendLine("[SHORTS_TITLE_1]")
            appendLine("দেশি হাঁস পালনের দারুণ কৌশল #shorts #farming #viral")
            appendLine("[SHORTS_TITLE_2]")
            appendLine("মাত্র ৫ মিনিটে অটোমেটিক খাঁচা তৈরি #shorts #diy #youtubeshorts")
            appendLine("[SHORTS_TITLE_3]")
            appendLine("বান্দরবানের পাহাড়ের অপরূপ দৃশ্য #shorts #travel #nature")
            appendLine("[SHORTS_TITLE_4]")
            appendLine("সোলার ইনভার্টার সেটআপ টিপস #shorts #solar #tech")
            appendLine("[SHORTS_TITLE_5]")
            appendLine("রেজিন দিয়ে ফটো ফ্রেম তৈরি #shorts #craft #art")
        }

        val parsed = SeoResponseParser.parseShortsResponse(raw)
        assertEquals(5, parsed.shortsTitles.size)
        for (title in parsed.shortsTitles) {
            assertTrue(title.contains("#"))
            assertTrue(title.length <= 100)
        }
    }
}
