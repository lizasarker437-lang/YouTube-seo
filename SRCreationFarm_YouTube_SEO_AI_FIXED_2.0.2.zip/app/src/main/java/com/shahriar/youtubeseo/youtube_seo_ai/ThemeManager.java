package com.shahriar.youtubeseo.youtube_seo_ai;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;

import androidx.appcompat.app.AppCompatDelegate;

public final class ThemeManager {
    public static final String MODE_SYSTEM = "system";
    public static final String MODE_LIGHT = "light";
    public static final String MODE_DARK = "dark";

    private static final String PREFS = "sr_theme_preferences";
    private static final String KEY_MODE = "appearance_mode";
    private static final String KEY_PALETTE = "color_palette";

    private ThemeManager() {}

    public static void applyMode(Context context) {
        String mode = preferences(context).getString(KEY_MODE, MODE_SYSTEM);
        if (MODE_LIGHT.equals(mode)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        } else if (MODE_DARK.equals(mode)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        }
    }

    public static void setMode(Context context, String mode) {
        preferences(context).edit().putString(KEY_MODE, mode).apply();
        applyMode(context);
    }

    public static String getMode(Context context) {
        return preferences(context).getString(KEY_MODE, MODE_SYSTEM);
    }

    public static void setPaletteName(Context context, String name) {
        preferences(context).edit().putString(KEY_PALETTE, name).apply();
    }

    public static String getPaletteName(Context context) {
        return preferences(context).getString(KEY_PALETTE, "Midnight Gold");
    }

    public static Palette getPalette(Context context) {
        boolean dark = (context.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        String name = getPaletteName(context);
        int primary;
        int accent;

        switch (name) {
            case "Ocean Blue":
                primary = Color.rgb(39, 126, 226); accent = Color.rgb(69, 190, 245); break;
            case "Emerald Green":
                primary = Color.rgb(18, 145, 105); accent = Color.rgb(57, 205, 151); break;
            case "Royal Purple":
                primary = Color.rgb(117, 83, 205); accent = Color.rgb(174, 139, 255); break;
            case "Sunset Coral":
                primary = Color.rgb(222, 91, 79); accent = Color.rgb(255, 157, 130); break;
            case "Graphite Cyan":
                primary = Color.rgb(31, 151, 166); accent = Color.rgb(75, 218, 231); break;
            case "Rose Quartz":
                primary = Color.rgb(194, 91, 137); accent = Color.rgb(239, 157, 190); break;
            case "Arctic Mint":
                primary = Color.rgb(51, 143, 125); accent = Color.rgb(117, 218, 194); break;
            case "Light Day":
                primary = Color.rgb(54, 105, 194); accent = Color.rgb(103, 151, 242); break;
            case "Midnight Gold":
            default:
                primary = Color.rgb(191, 143, 54); accent = Color.rgb(242, 197, 104); break;
        }

        int background = dark ? Color.rgb(9, 16, 31) : Color.rgb(245, 247, 251);
        int surface = dark ? Color.rgb(17, 27, 46) : Color.WHITE;
        int card = dark ? Color.rgb(23, 36, 58) : Color.rgb(255, 255, 255);
        int text = dark ? Color.rgb(242, 245, 250) : Color.rgb(26, 36, 54);
        int muted = dark ? Color.rgb(166, 179, 199) : Color.rgb(100, 113, 132);
        int outline = dark ? Color.rgb(48, 64, 91) : Color.rgb(220, 226, 236);
        return new Palette(name, dark, primary, accent, background, surface, card, text, muted, outline);
    }

    private static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static final class Palette {
        public final String name;
        public final boolean dark;
        public final int primary;
        public final int accent;
        public final int background;
        public final int surface;
        public final int card;
        public final int text;
        public final int muted;
        public final int outline;

        Palette(String name, boolean dark, int primary, int accent, int background,
                int surface, int card, int text, int muted, int outline) {
            this.name = name;
            this.dark = dark;
            this.primary = primary;
            this.accent = accent;
            this.background = background;
            this.surface = surface;
            this.card = card;
            this.text = text;
            this.muted = muted;
            this.outline = outline;
        }
    }
}
