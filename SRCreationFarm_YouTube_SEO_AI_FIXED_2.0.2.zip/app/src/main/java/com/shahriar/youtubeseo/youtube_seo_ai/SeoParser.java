package com.shahriar.youtubeseo.youtube_seo_ai;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SeoParser {
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.DOTALL;

    private SeoParser() {}

    public static Result parse(String output) {
        String source = output == null ? "" : output.trim();
        String title = extract(source, "TITLE");
        String description = extract(source, "DESCRIPTION");
        String hashtags = extract(source, "HASHTAGS");

        if (title.isEmpty() && description.isEmpty() && hashtags.isEmpty() && !source.isEmpty()) {
            description = source;
        }
        return new Result(title, description, hashtags);
    }

    private static String extract(String source, String section) {
        Pattern pattern = Pattern.compile(
                "\\[" + section + "\\](.*?)(?=\\[(?:TITLE|DESCRIPTION|HASHTAGS)\\]|\\z)",
                FLAGS);
        Matcher matcher = pattern.matcher(source);
        return matcher.find() ? matcher.group(1).trim() : "";
    }

    public static final class Result {
        public final String title;
        public final String description;
        public final String hashtags;

        public Result(String title, String description, String hashtags) {
            this.title = title == null ? "" : title.trim();
            this.description = description == null ? "" : description.trim();
            this.hashtags = hashtags == null ? "" : hashtags.trim();
        }

        public boolean isEmpty() {
            return title.isEmpty() && description.isEmpty() && hashtags.isEmpty();
        }
    }
}
