package com.shahriar.youtubeseo.youtube_seo_ai;

import org.junit.Test;
import static org.junit.Assert.*;

public class SeoParserTest {
    @Test
    public void parsesAllThreeSections() {
        String raw = "[TITLE]\nA strong YouTube title\n\n"
                + "[DESCRIPTION]\nFirst line\nSecond line\n\n"
                + "[HASHTAGS]\n#video #seo #creator";
        SeoParser.Result result = SeoParser.parse(raw);

        assertEquals("A strong YouTube title", result.title);
        assertEquals("First line\nSecond line", result.description);
        assertEquals("#video #seo #creator", result.hashtags);
    }

    @Test
    public void preservesUnstructuredResponseAsDescription() {
        SeoParser.Result result = SeoParser.parse("A plain text response");
        assertEquals("", result.title);
        assertEquals("A plain text response", result.description);
        assertEquals("", result.hashtags);
    }

    @Test
    public void handlesNullInput() {
        assertTrue(SeoParser.parse(null).isEmpty());
    }
}
