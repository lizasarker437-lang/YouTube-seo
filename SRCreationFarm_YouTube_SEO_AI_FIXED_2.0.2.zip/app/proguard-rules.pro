# The app uses platform JSON APIs and direct HTTPS requests.
# Keep debug metadata out of release artifacts while allowing R8 to optimize.
-keepattributes *Annotation*
