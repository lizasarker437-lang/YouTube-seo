# মোবাইল থেকে GitHub-এ APK তৈরির নির্দেশনা — YouTube SEO AI 2.0.2

## পদ্ধতি A: Extract করে Upload (সুপারিশকৃত)

1. `SRCreationFarm_YouTube_SEO_AI_FIXED_2.0.2.zip` Extract করুন।
2. GitHub-এ আপনার Repository খুলুন।
3. নতুন ZIP-এর ভেতরের **ফাইল ও ফোল্ডারগুলো** Repository-র Root-এ Upload করুন।
4. আগের `.github/workflows/build-apk.yml` **Replace** করুন; পুরোনো `setup-android@v3` থাকা কোনো Workflow চালু রাখবেন না।
5. `Actions` → `Build YouTube SEO AI APK` → `Run workflow` নির্বাচন করুন।
6. Run সবুজ হলে `Artifacts` থেকে `youtube-seo-ai-debug-apk` ডাউনলোড করুন।
7. Build ব্যর্থ হলে `youtube-seo-ai-build-diagnostics` ডাউনলোড করে প্রথম Error দেখুন।

## পদ্ধতি B: মাত্র দুটি ফাইল Upload (মোবাইলের জন্য সহজ)

1. Repository Root-এ `SRCreationFarm_YouTube_SEO_AI_FIXED_2.0.2.zip` Upload করুন।
2. আলাদা দেওয়া `build-apk.yml`-টি Repository-তে এই নির্দিষ্ট Path-এ রাখুন:
   `.github/workflows/build-apk.yml`
3. সম্ভব হলে পুরোনো ZIP মুছে দিন। বর্তমান `SRCreationFarm_YouTube_SEO_AI_FIXED_2.0.2.zip` থাকলে Workflow সেটিকেই অগ্রাধিকার দেবে।
4. GitHub → `Actions` → `Build YouTube SEO AI APK` → `Run workflow` দিন।
5. Workflow নিজেই Source ZIP Extract করে Android Project খুঁজে Build করবে।

**গুরুত্বপূর্ণ:** ZIP-এর ভেতরে `.github/workflows/build-apk.yml` থাকলেও শুধু ZIP Upload করলে GitHub Actions সেটি শনাক্ত করে না। Workflow ফাইলটি Repository-র Path-এ আলাদাভাবে রাখতে হবে।

## APK কোনটি ইনস্টল করবেন?

- `youtube-seo-ai-debug-apk` → মোবাইল ইনস্টল ও পরীক্ষার জন্য।
- `youtube-seo-ai-release-apk` → কেবল Signing Secrets সেট করা থাকলে সরাসরি ইনস্টলযোগ্য Signed Release APK।

## Error হলে

Actions Run-এর `Set up Android SDK (fixed)`, `Install Android API 36 SDK packages`, `Run unit tests and Android lint` এবং `Build debug and release APKs` ধাপের শেষ 30-50 লাইন ও `build-diagnostics` দিন। তাতে কোন ধাপে সমস্যা হয়েছে নির্দিষ্টভাবে বোঝা যাবে।

## জানা সীমাবদ্ধতা

এই পরিবেশে সম্পূর্ণ Android APK Build চালানো যায়নি। নতুন Workflow-এ SDK, Gradle, test ও build ধাপ যুক্ত আছে; GitHub Actions রানটি সফল হলে তবেই APK Build সফল বলা যাবে।
