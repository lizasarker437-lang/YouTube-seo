# Changelog

## 2.0.2 (versionCode 5) — GitHub Build Compatibility
- Downgraded compile SDK from unavailable API 37 to supported API 36; kept target 36.
- Aligned Android Gradle Plugin 8.13.2 with Gradle 8.13 and JDK 17.
- Installed Android SDK platform 36 with Build Tools 35.0.0 (no deprecated tools package).
- Aligned AndroidX AppCompat 1.7.1 and Core 1.16.0 with Material 1.14.0.
- Removed unsupported Gemini 3.8 Flash `temperature` generation parameter.
- Generated the official Gradle Wrapper in an isolated CI bootstrap project.
- Added dependency-resolution logs, SDK package logs and APK metadata validation.
- Retained all existing screenshot/AI/branding/theme/history features and package ID.

## 2.0.1 — Android SDK Setup
- Updated SDK setup action to v4.
- Added ZIP and folder sources support for GitHub.
