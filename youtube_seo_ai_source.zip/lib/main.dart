import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const YouTubeSeoApp());
}

class YouTubeSeoApp extends StatelessWidget {
  const YouTubeSeoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'YouTube SEO AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFF0000),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const SeoGeneratorScreen(),
    );
  }
}

class SeoGeneratorScreen extends StatefulWidget {
  const SeoGeneratorScreen({super.key});

  @override
  State<SeoGeneratorScreen> createState() => _SeoGeneratorScreenState();
}

class _SeoGeneratorScreenState extends State<SeoGeneratorScreen> {
  final ImagePicker _picker = ImagePicker();
  final List<File?> _screenshots = [null, null, null];
  final TextEditingController _apiKeyController = TextEditingController();
  final TextEditingController _keywordController = TextEditingController();

  String _selectedLanguage = 'Bengali (বাংলা)';
  bool _isLoading = false;
  String _generatedTitle = '';
  String _generatedDescription = '';
  String _generatedHashtags = '';
  String _rawOutput = '';

  @override
  void initState() {
    super.initState();
    _loadApiKey();
  }

  Future<void> _loadApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    final savedKey = prefs.getString('gemini_api_key') ?? '';
    setState(() {
      _apiKeyController.text = savedKey;
    });
  }

  Future<void> _saveApiKey(String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('gemini_api_key', key.trim());
  }

  Future<void> _pickImage(int index) async {
    try {
      final XFile? picked = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );
      if (picked != null) {
        setState(() {
          _screenshots[index] = File(picked.path);
        });
      }
    } catch (e) {
      _showSnackBar('ছবি নির্বাচনে সমস্যা হয়েছে: $e');
    }
  }

  void _showSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  void _copyToClipboard(String text, String label) {
    if (text.isEmpty) return;
    Clipboard.setData(ClipboardData(text: text));
    _showSnackBar('$label কপি করা হয়েছে!');
  }

  Future<void> _generateSeo() async {
    final apiKey = _apiKeyController.text.trim();
    if (apiKey.isEmpty) {
      _showSnackBar('অনুগ্রহ করে আগে আপনার Gemini API Key দিন।');
      return;
    }

    if (_screenshots.any((file) => file == null)) {
      _showSnackBar('অনুগ্রহ করে ভিডিওর ৩টি স্ক্রিনশটই আপলোড করুন।');
      return;
    }

    await _saveApiKey(apiKey);

    setState(() {
      _isLoading = true;
      _generatedTitle = '';
      _generatedDescription = '';
      _generatedHashtags = '';
      _rawOutput = '';
    });

    try {
      final List<Map<String, dynamic>> parts = [];

      final extraHint = _keywordController.text.trim().isNotEmpty
          ? 'অতিরিক্ত তথ্য/কিওয়ার্ড: ${_keywordController.text.trim()}'
          : '';

      final prompt = '''
তুমি একজন প্রফেশনাল YouTube SEO এবং কন্টেন্ট স্ট্র্যাটেজিস্ট।
তোমাকে একটি ভিডিওর ৩টি স্ক্রিনশট দেওয়া হয়েছে। এই ৩টি স্ক্রিনশট গভীরভাবে বিশ্লেষণ করে ভিডিওটির মূল বিষয়বস্তু, ধরন, দৃশ্যপট এবং দর্শকদের আগ্রহের জায়গা খুঁজে বের করো।
$extraHint

ভাষা নির্দেশনা: আউটপুট অবশ্যই $_selectedLanguage ভাষায় তৈরি করবে।

নিচের ঠিক এই ফরম্যাটে এবং আলাদা সেকশনে উত্তর দাও (কোনো বাড়তি ভূমিকা বা উপসংহার লিখবে না):

[TITLE]
(এখানে উচ্চ-CTR সম্পন্ন, আকর্ষণীয় এবং সার্চ-ফ্রেন্ডলি একটি সেরা ইউটিউব টাইটেল লিখবে)

[DESCRIPTION]
(এখানে ইউটিউব অ্যালগরিদম ও এসইও-বান্ধব বিস্তারিত ডেসক্রিপশন লিখবে। প্রথম ২ লাইনে মূল কিওয়ার্ড রাখবে, এরপর ভিডিওর সারসংক্ষেপ ও দর্শকদের জন্য কল-টু-অ্যাকশন যুক্ত করবে)

[HASHTAGS]
(এখানে ১৫টি হাই-র‍্যাংকিং এবং প্রাসঙ্গিক ইউটিউব হ্যাশট্যাগ স্পেস দিয়ে লিখবে, যেমন: #tag1 #tag2 #tag3)
''';

      parts.add({'text': prompt});

      for (final file in _screenshots) {
        final bytes = await file!.readAsBytes();
        final base64Image = base64Encode(bytes);
        parts.add({
          'inline_data': {
            'mime_type': 'image/jpeg',
            'data': base64Image,
          }
        });
      }

      final url = Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey',
      );

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [
            {'parts': parts}
          ],
          'generationConfig': {
            'temperature': 0.7,
            'maxOutputTokens': 2048,
          }
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final text = data['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? '';
        _parseResponse(text);
      } else {
        final err = jsonDecode(response.body);
        final errMsg = err['error']?['message'] ?? 'API এরর (${response.statusCode})';
        _showSnackBar('সমস্যা হয়েছে: $errMsg');
      }
    } catch (e) {
      _showSnackBar('নেটওয়ার্ক বা প্রসেসিং ত্রুটি: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _parseResponse(String text) {
    String title = '';
    String desc = '';
    String tags = '';

    final titleRegex = RegExp(r'\[TITLE\](.*?)(?=\[DESCRIPTION\]|$)', dotAll: true);
    final descRegex = RegExp(r'\[DESCRIPTION\](.*?)(?=\[HASHTAGS\]|$)', dotAll: true);
    final tagsRegex = RegExp(r'\[HASHTAGS\](.*)', dotAll: true);

    final titleMatch = titleRegex.firstMatch(text);
    final descMatch = descRegex.firstMatch(text);
    final tagsMatch = tagsRegex.firstMatch(text);

    if (titleMatch != null) title = titleMatch.group(1)?.trim() ?? '';
    if (descMatch != null) desc = descMatch.group(1)?.trim() ?? '';
    if (tagsMatch != null) tags = tagsMatch.group(1)?.trim() ?? '';

    setState(() {
      _generatedTitle = title;
      _generatedDescription = desc;
      _generatedHashtags = tags;
      _rawOutput = text;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('YouTube SEO AI Generator', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.key),
            tooltip: 'API Key সেটিংস',
            onPressed: _showApiKeyDialog,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_apiKeyController.text.isEmpty)
              Card(
                color: Colors.red.withOpacity(0.15),
                child: ListTile(
                  leading: const Icon(Icons.warning_amber_rounded, color: Colors.amber),
                  title: const Text('Gemini API Key সেট করা নেই'),
                  subtitle: const Text('এখানে ট্যাপ করে আপনার ফ্রি API Key বসান'),
                  onTap: _showApiKeyDialog,
                ),
              ),
            const SizedBox(height: 12),
            const Text(
              '১. ভিডিওর ৩টি স্ক্রিনশট নির্বাচন করুন',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Row(
              children: List.generate(3, (index) {
                final file = _screenshots[index];
                return Expanded(
                  child: GestureDetector(
                    onTap: () => _pickImage(index),
                    child: Container(
                      height: 120,
                      margin: EdgeInsets.only(right: index < 2 ? 8 : 0),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade900,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: file != null ? Colors.redAccent : Colors.grey.shade700,
                          width: 1.5,
                        ),
                      ),
                      child: file != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  Image.file(file, fit: BoxFit.cover),
                                  Positioned(
                                    top: 4,
                                    right: 4,
                                    child: CircleAvatar(
                                      radius: 12,
                                      backgroundColor: Colors.black54,
                                      child: Text('${index + 1}', style: const TextStyle(fontSize: 12)),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.add_photo_alternate_outlined, size: 32, color: Colors.grey),
                                const SizedBox(height: 4),
                                Text('স্ক্রিনশট ${index + 1}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                              ],
                            ),
                    ),
                  ),
                );
              }),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: DropdownButtonFormField<String>(
                    value: _selectedLanguage,
                    decoration: InputDecoration(
                      labelText: 'ভাষা',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'Bengali (বাংলা)', child: Text('বাংলা')),
                      DropdownMenuItem(value: 'English', child: Text('English')),
                      DropdownMenuItem(value: 'Bengali & English Mix', child: Text('বাংলা + English')),
                    ],
                    onChanged: (val) {
                      if (val != null) setState(() => _selectedLanguage = val);
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 3,
                  child: TextField(
                    controller: _keywordController,
                    decoration: InputDecoration(
                      labelText: 'বিষয়/কিওয়ার্ড (ঐচ্ছিক)',
                      hintText: 'যেমন: ভ্লগ, রান্না, টেক',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: _isLoading ? null : _generateSeo,
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFFF0000),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              icon: _isLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.auto_awesome),
              label: Text(
                _isLoading ? 'বিশ্লেষণ করা হচ্ছে...' : 'SEO টাইটেল ও ডেসক্রিপশন তৈরি করুন',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 24),
            if (_generatedTitle.isNotEmpty) ...[
              _buildResultCard(
                title: '📌 প্রস্তাবিত টাইটেল (Title)',
                content: _generatedTitle,
                onCopy: () => _copyToClipboard(_generatedTitle, 'টাইটেল'),
              ),
              const SizedBox(height: 14),
            ],
            if (_generatedDescription.isNotEmpty) ...[
              _buildResultCard(
                title: '📝 ভিডিও ডেসক্রিপশন (Description)',
                content: _generatedDescription,
                onCopy: () => _copyToClipboard(_generatedDescription, 'ডেসক্রিপশন'),
              ),
              const SizedBox(height: 14),
            ],
            if (_generatedHashtags.isNotEmpty) ...[
              _buildResultCard(
                title: '🏷️ হ্যাশট্যাগসমূহ (Hashtags)',
                content: _generatedHashtags,
                onCopy: () => _copyToClipboard(_generatedHashtags, 'হ্যাশট্যাগ'),
              ),
              const SizedBox(height: 14),
            ],
            if (_generatedTitle.isEmpty && _rawOutput.isNotEmpty) ...[
              _buildResultCard(
                title: 'ফলাফল',
                content: _rawOutput,
                onCopy: () => _copyToClipboard(_rawOutput, 'ফলাফল'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildResultCard({
    required String title,
    required String content,
    required VoidCallback onCopy,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.redAccent)),
                IconButton(
                  icon: const Icon(Icons.copy, size: 20),
                  tooltip: 'কপি করুন',
                  onPressed: onCopy,
                ),
              ],
            ),
            const Divider(),
            SelectableText(content, style: const TextStyle(fontSize: 14, height: 1.5)),
          ],
        ),
      ),
    );
  }

  void _showApiKeyDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Gemini API Key সেট করুন'),
        content: TextField(
          controller: _apiKeyController,
          decoration: const InputDecoration(
            hintText: 'AIzaSy...',
            border: OutlineInputBorder(),
            helperText: 'Google AI Studio থেকে প্রাপ্ত API Key দিন',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('বাতিল'),
          ),
          FilledButton(
            onPressed: () {
              _saveApiKey(_apiKeyController.text);
              setState(() {});
              Navigator.pop(context);
              _showSnackBar('API Key সংরক্ষিত হয়েছে');
            },
            child: const Text('সেভ করুন'),
          ),
        ],
      ),
    );
  }
}
