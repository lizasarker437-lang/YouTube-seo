package com.shahriar.youtubeseo.youtube_seo_ai;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

public final class GeminiClient {
    private static final String ENDPOINT =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent";

    private GeminiClient() {}

    public static String generate(Context context, String apiKey, List<Uri> images,
                                  String language, String keywords, String audience) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalArgumentException("Gemini API Key দেওয়া হয়নি। Settings থেকে API Key সংরক্ষণ করুন।");
        }
        if (images == null || images.size() != 3) {
            throw new IllegalArgumentException("ভিডিওর ঠিক ৩টি স্ক্রিনশট নির্বাচন করুন।");
        }

        JSONArray parts = new JSONArray();
        parts.put(new JSONObject().put("text", buildPrompt(language, keywords, audience)));

        for (Uri uri : images) {
            byte[] jpeg = imageAsJpeg(context, uri);
            JSONObject inlineData = new JSONObject()
                    .put("mime_type", "image/jpeg")
                    .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP));
            parts.put(new JSONObject().put("inline_data", inlineData));
        }

        JSONObject request = new JSONObject();
        request.put("contents", new JSONArray().put(
                new JSONObject().put("role", "user").put("parts", parts)));
        request.put("generationConfig", new JSONObject()
                .put("temperature", 0.65)
                .put("maxOutputTokens", 4096));

        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(ENDPOINT).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(90000);
            connection.setDoOutput(true);
            connection.setUseCaches(false);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("X-goog-api-key", apiKey.trim());

            byte[] body = request.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body);
                output.flush();
            }

            int status = connection.getResponseCode();
            InputStream responseStream = status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream();
            String responseBody = readFully(responseStream);

            if (status < 200 || status >= 300) {
                throw new Exception(friendlyError(status, responseBody));
            }

            JSONObject response = new JSONObject(responseBody);
            JSONArray candidates = response.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) {
                throw new Exception("Gemini কোনো ফলাফল দেয়নি। স্ক্রিনশটগুলো পরিষ্কার কি না পরীক্ষা করে আবার চেষ্টা করুন।");
            }

            JSONObject first = candidates.optJSONObject(0);
            JSONObject content = first == null ? null : first.optJSONObject("content");
            JSONArray responseParts = content == null ? null : content.optJSONArray("parts");
            StringBuilder text = new StringBuilder();
            if (responseParts != null) {
                for (int i = 0; i < responseParts.length(); i++) {
                    JSONObject part = responseParts.optJSONObject(i);
                    if (part != null && part.has("text")) {
                        if (text.length() > 0) text.append('\n');
                        text.append(part.optString("text", ""));
                    }
                }
            }

            String result = text.toString().trim();
            if (result.isEmpty()) {
                throw new Exception("Gemini-এর উত্তর খালি এসেছে। নতুন স্ক্রিনশট দিয়ে আবার চেষ্টা করুন।");
            }
            return result;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String buildPrompt(String language, String keywords, String audience) {
        String safeKeywords = keywords == null || keywords.trim().isEmpty()
                ? "স্ক্রিনশট থেকে প্রাসঙ্গিক কিওয়ার্ড নির্বাচন করো"
                : keywords.trim();
        String safeAudience = audience == null || audience.trim().isEmpty()
                ? "ভিডিওর বিষয় অনুযায়ী উপযুক্ত দর্শক"
                : audience.trim();

        return "তুমি একজন অভিজ্ঞ YouTube SEO strategist এবং video content analyst।\n"
                + "সংযুক্ত ঠিক ৩টি ভিডিও স্ক্রিনশট দেখে ভিডিওর বিষয়, দৃশ্য, সম্ভাব্য দর্শক, আবেগ, "
                + "অনন্য দিক এবং সার্চ ইন্টেন্ট বিশ্লেষণ করো। ছবিতে নেই এমন ঘটনা বা তথ্য বানিয়ে লিখবে না।\n"
                + "আউটপুট ভাষা: " + language + "\n"
                + "অতিরিক্ত বিষয়/কিওয়ার্ড: " + safeKeywords + "\n"
                + "টার্গেট দর্শক: " + safeAudience + "\n\n"
                + "নির্দেশনা:\n"
                + "১. একটি আকর্ষণীয়, নির্দিষ্ট ও সার্চ-ফ্রেন্ডলি Title দাও; অযথা clickbait নয়।\n"
                + "২. Description-এর প্রথম দুই লাইনে মূল বিষয়/কিওয়ার্ড রাখো; এরপর সত্যনিষ্ঠ সারাংশ, "
                + "প্রাসঙ্গিক CTA এবং প্রয়োজনীয় placeholder থাকলে তা স্পষ্ট করো।\n"
                + "৩. ১০-১৫টি সত্যিই প্রাসঙ্গিক hashtag দাও; অপ্রাসঙ্গিক tag বা নিশ্চিত ranking-এর দাবি করবে না।\n"
                + "৪. ফলাফল যেন সরাসরি YouTube-এ ব্যবহার করা যায়।\n"
                + "৫. কোনো markdown code fence বা বাড়তি ভূমিকা লিখবে না।\n\n"
                + "শুধু এই ফরম্যাটে উত্তর দাও:\n"
                + "[TITLE]\nটাইটেল\n\n[DESCRIPTION]\nডেসক্রিপশন\n\n[HASHTAGS]\n#tag1 #tag2 ...";
    }

    private static byte[] imageAsJpeg(Context context, Uri uri) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) throw new Exception("একটি নির্বাচিত ছবি পড়া যাচ্ছে না। আবার নির্বাচন করুন।");
            BitmapFactory.decodeStream(input, null, bounds);
        }

        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new Exception("নির্বাচিত ফাইলটি বৈধ ছবি নয়।");
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = calculateSampleSize(bounds, 1440, 1440);
        options.inPreferredConfig = Bitmap.Config.RGB_565;

        Bitmap bitmap;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) throw new Exception("একটি নির্বাচিত ছবি পড়া যাচ্ছে না। আবার নির্বাচন করুন।");
            bitmap = BitmapFactory.decodeStream(input, null, options);
        }
        if (bitmap == null) throw new Exception("ছবিটি প্রসেস করা যায়নি।");

        try {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 84, output)) {
                throw new Exception("ছবি কমপ্রেস করা যায়নি।");
            }
            return output.toByteArray();
        } finally {
            bitmap.recycle();
        }
    }

    private static int calculateSampleSize(BitmapFactory.Options options, int maxWidth, int maxHeight) {
        int sample = 1;
        int width = options.outWidth;
        int height = options.outHeight;
        while ((width / sample) > maxWidth || (height / sample) > maxHeight) {
            sample *= 2;
        }
        return Math.max(1, sample);
    }

    private static String readFully(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line);
        }
        return result.toString();
    }

    private static String friendlyError(int status, String body) {
        String message = body;
        try {
            JSONObject error = new JSONObject(body).optJSONObject("error");
            if (error != null) message = error.optString("message", body);
        } catch (Exception ignored) {}

        if (status == 400 || status == 403) {
            return "API Key বা অনুরোধে সমস্যা হয়েছে: " + message;
        }
        if (status == 404) {
            return "Gemini মডেল বা API endpoint পাওয়া যায়নি। API access পরীক্ষা করুন।";
        }
        if (status == 429) {
            return "Gemini API quota বা rate limit শেষ হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।";
        }
        if (status >= 500) {
            return "Google AI সার্ভারে সাময়িক সমস্যা হয়েছে। পরে আবার চেষ্টা করুন।";
        }
        return "Gemini API error (" + status + "): " + message;
    }
}
