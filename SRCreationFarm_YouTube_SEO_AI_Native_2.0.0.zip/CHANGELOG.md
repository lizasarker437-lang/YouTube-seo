# Changelog

## 2.0.0 (versionCode 3)

- Rebuilt the app as a native Android Java project.
- Preserved the three-screenshot Gemini SEO workflow.
- Added SR Creation Farm branding and a dedicated app icon.
- Added About Developer section with YouTube and Facebook buttons.
- Added System / Light / Dark appearance modes.
- Added nine persistent color themes.
- Added encrypted Gemini API key storage with Android Keystore AES-GCM.
- Added editable Title, Description and Hashtags fields.
- Added per-section copy and copy-all.
- Added local history for the latest 20 generations.
- Added privacy information and clear-history controls.
- Added Android unit tests, lint, APK verification and build-log artifact upload.
