package com.shahriar.youtubeseo.youtube_seo_ai;

/** Isolates platform-specific content guidelines from HTTP / Android code. */
public final class SeoPromptBuilder {
    private SeoPromptBuilder() {}

    public static String build(SeoPlatform platform, String language, String keywords, String audience) {
        SeoPlatform mode = platform == null ? SeoPlatform.YOUTUBE : platform;
        String safeLanguage = language == null || language.trim().isEmpty() ? "বাংলা" : language.trim();
        String safeKeywords = keywords == null || keywords.trim().isEmpty()
                ? "স্ক্রিনশট থেকে প্রাসঙ্গিক কিওয়ার্ড নির্বাচন করো" : keywords.trim();
        String safeAudience = audience == null || audience.trim().isEmpty()
                ? "ভিডিওর বিষয় অনুযায়ী উপযুক্ত দর্শক" : audience.trim();

        String context = "সংযুক্ত ঠিক ৩টি ভিডিও স্ক্রিনশট দেখে দৃশ্য, বিষয় এবং দর্শকের আগ্রহ বিশ্লেষণ করো। "
                + "স্ক্রিনশটে দেখা যায় না এমন ঘটনা, কথা, ব্যক্তি, স্থান, ফলাফল বা দাবি বানিয়ে লিখবে না। "
                + "পূর্ণ ভিডিও দেখোনি—সন্দেহ হলে নিশ্চিত করে বলবে না।\n"
                + "আউটপুট ভাষা: " + safeLanguage + "\n"
                + "অতিরিক্ত বিষয়/কিওয়ার্ড: " + safeKeywords + "\n"
                + "টার্গেট দর্শক: " + safeAudience + "\n\n";
        String format = "\nশুধু এই সেকশনগুলোতে উত্তর দাও, কোনো markdown code fence বা ভূমিকা নয়:\n"
                + "[TITLE]\nটাইটেল\n\n[DESCRIPTION]\nডেসক্রিপশন বা ক্যাপশন\n\n[HASHTAGS]\n#tag1 #tag2 ...";

        if (mode == SeoPlatform.FACEBOOK_REELS) {
            return "তুমি Facebook Reels-এর জন্য দায়িত্বশীল Bengali/English content-copy writer।\n"
                    + context
                    + "Meta/Facebook-এর মূল নির্দেশনা মেনে লিখবে: আসল কনটেন্টকে যথাযথভাবে উপস্থাপন, "
                    + "অপ্রাসঙ্গিক ক্যাপশন বা হ্যাশট্যাগ নয়, engagement bait বা sensational clickbait নয়, "
                    + "অত্যধিক লম্বা বা পুনরাবৃত্তিমূলক ক্যাপশন নয়, মিথ্যা ফলাফল/ভাইরাল গ্যারান্টি নয়। "
                    + "কপিরাইট অনুমতি বা মৌলিকতা ছবি দেখে নিশ্চিত করা যায় না; কোনো অনুমোদনের দাবি করবে না।\n"
                    + "[TITLE]: একটি ছোট, সত্যনিষ্ঠ Reel Hook / প্রস্তাবিত শিরোনাম (আলাদা Title field না থাকলে ক্যাপশনের শুরুতে ব্যবহারযোগ্য)।\n"
                    + "[DESCRIPTION]: মূল বিষয়টি সামনে রেখে সংক্ষিপ্ত ১–৩ বাক্যের স্বাভাবিক Facebook Reel caption; "
                    + "প্রয়োজনে একটি প্রাসঙ্গিক, ভদ্র CTA।\n"
                    + "[HASHTAGS]: ২–৫টি নির্দিষ্ট, প্রাসঙ্গিক, আলাদা hashtag; generic trending spam নয়। "
                    + "এটি সম্পাদকীয় পরামর্শ, Facebook-এর বাধ্যতামূলক সংখ্যাগত নিয়ম নয়।\n"
                    + "নিজে নিজে রিচ, মনিটাইজেশন বা নীতিমালা-পাস হওয়ার গ্যারান্টি দেবে না।"
                    + format;
        }
        if (mode == SeoPlatform.FACEBOOK_VIDEO) {
            return "তুমি Facebook Video-এর জন্য দায়িত্বশীল social video title/caption copywriter।\n"
                    + context
                    + "Meta/Facebook-এর মূল নির্দেশনা মেনে লিখবে: কনটেন্ট-সংশ্লিষ্ট, স্পষ্ট ও সত্যনিষ্ঠ লেখা; "
                    + "বিভ্রান্তিকর clickbait, engagement bait, ভুয়া তথ্য, কৃত্রিম viral/monetization promise, "
                    + "অপ্রাসঙ্গিক hashtag ও পুনরাবৃত্তিমূলক spam নয়। "
                    + "অন্যের ভিডিওর মালিকানা বা অনুমতি সম্পর্কে কোনো দাবি করবে না।\n"
                    + "[TITLE]: কনটেন্টের সঙ্গে মেলে এমন একটি সুনির্দিষ্ট Facebook Video শিরোনাম।\n"
                    + "[DESCRIPTION]: প্রথম লাইনে বিষয়; তারপর ভিডিওর প্রকৃত উপাদান সম্পর্কে ২–৪টি ছোট অনুচ্ছেদে "
                    + "সহজপাঠ্য Facebook post description; প্রয়োজনে একটি প্রাসঙ্গিক CTA। "
                    + "শুধু ছবি দেখে জানা যায় না এমন বর্ণনা জুড়বে না।\n"
                    + "[HASHTAGS]: ২–৫টি প্রাসঙ্গিক hashtag, অপ্রাসঙ্গিক ট্রেন্ডিং ট্যাগ নয়; "
                    + "সংখ্যাটি সম্পাদকীয় পরামর্শ, Meta-এর অফিসিয়াল সীমা নয়।\n"
                    + "Meta এখন Facebook-এ নতুন ভিডিও Reels আকারেও প্রকাশ করছে; এটি লেখা তৈরির আলাদা স্টাইল, "
                    + "আলাদা ভিডিও আপলোডের নিশ্চয়তা নয়।"
                    + format;
        }
        // Keep the YouTube output structure and intent unchanged.
        return "তুমি একজন অভিজ্ঞ YouTube SEO strategist এবং video content analyst।\n"
                + context
                + "১. একটি আকর্ষণীয়, নির্দিষ্ট ও সার্চ-ফ্রেন্ডলি Title দাও; অযথা clickbait নয়।\n"
                + "২. Description-এর প্রথম দুই লাইনে মূল বিষয়/কিওয়ার্ড রাখো; এরপর সত্যনিষ্ঠ সারাংশ, "
                + "প্রাসঙ্গিক CTA এবং প্রয়োজনীয় placeholder থাকলে তা স্পষ্ট করো।\n"
                + "৩. ১০-১৫টি প্রাসঙ্গিক YouTube hashtag দাও; অপ্রাসঙ্গিক tag বা নিশ্চিত ranking-এর দাবি করবে না।\n"
                + "৪. ফলাফল যেন সরাসরি YouTube-এ ব্যবহার করা যায়।"
                + format;
    }
}
