package com.shahriar.youtubeseo.youtube_seo_ai;

/** Content-writing mode, independent from the Facebook upload interface. */
public enum SeoPlatform {
    YOUTUBE("youtube", "YouTube"),
    FACEBOOK_REELS("facebook_reels", "Facebook Reels"),
    FACEBOOK_VIDEO("facebook_video", "Facebook Video");

    public final String storageId;
    public final String displayName;

    SeoPlatform(String storageId, String displayName) {
        this.storageId = storageId;
        this.displayName = displayName;
    }

    public boolean isFacebook() {
        return this != YOUTUBE;
    }

    public static SeoPlatform fromStorageId(String value) {
        if (value != null) {
            for (SeoPlatform platform : values()) {
                if (platform.storageId.equals(value)) return platform;
            }
        }
        // Backwards compatibility: existing 2.0.2 history had no platform field.
        return YOUTUBE;
    }
}
