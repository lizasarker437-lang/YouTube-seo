package com.shahriar.youtubeseo.youtube_seo_ai;

import org.junit.Test;
import static org.junit.Assert.*;

public class SeoPromptBuilderTest {
    @Test public void reelsIncludesMetaRelevanceAndShortCaptionRules() {
        String prompt = SeoPromptBuilder.build(SeoPlatform.FACEBOOK_REELS,
                "বাংলা", "কুকিং", "বাংলাদেশ");
        assertTrue(prompt.contains("Facebook Reels"));
        assertTrue(prompt.contains("১–৩ বাক্যের"));
        assertTrue(prompt.contains("২–৫টি"));
        assertTrue(prompt.contains("engagement bait"));
        assertTrue(prompt.contains("[TITLE]"));
        assertTrue(prompt.contains("[DESCRIPTION]"));
        assertTrue(prompt.contains("[HASHTAGS]"));
    }

    @Test public void videoUsesLongFormDescription() {
        String prompt = SeoPromptBuilder.build(SeoPlatform.FACEBOOK_VIDEO,
                "English", "gardening", "beginners");
        assertTrue(prompt.contains("Facebook Video"));
        assertTrue(prompt.contains("২–৪টি"));
        assertTrue(prompt.contains("gardening"));
        assertFalse(prompt.contains("১০-১৫টি প্রাসঙ্গিক YouTube"));
    }

    @Test public void youtubeRetainsOriginalModeRules() {
        String prompt = SeoPromptBuilder.build(SeoPlatform.YOUTUBE,
                "বাংলা", "", "");
        assertTrue(prompt.contains("YouTube SEO"));
        assertTrue(prompt.contains("১০-১৫টি প্রাসঙ্গিক YouTube"));
        assertFalse(prompt.contains("Facebook Reel caption"));
    }

    @Test public void storageFallbackPreservesOldHistory() {
        assertEquals(SeoPlatform.YOUTUBE, SeoPlatform.fromStorageId(null));
        assertEquals(SeoPlatform.YOUTUBE, SeoPlatform.fromStorageId("unknown"));
        assertEquals(SeoPlatform.YOUTUBE, SeoPlatform.fromStorageId("youtube"));
        assertEquals(SeoPlatform.FACEBOOK_REELS,
                SeoPlatform.fromStorageId("facebook_reels"));
        assertEquals(SeoPlatform.FACEBOOK_VIDEO,
                SeoPlatform.fromStorageId("facebook_video"));
    }
}
