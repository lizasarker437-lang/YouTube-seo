# মোবাইল থেকে GitHub APK — YouTube SEO AI v2.1.0

## নতুন Facebook ফিচার

অ্যাপ খুলে **কনটেন্ট প্ল্যাটফর্ম** থেকে Facebook নির্বাচন করুন। তারপর Facebook Reels বা Facebook Video বাছুন। আগের মতো ৩টি ভিডিও স্ক্রিনশট দিন, Gemini API Key সংরক্ষণ করুন এবং Generate চাপুন। Reels-এ ছোট Hook/Caption, Video-তে অপেক্ষাকৃত বিস্তারিত Title/Description পাবেন। তৈরি হওয়া লেখা প্রকাশের আগে নিজে যাচাই করুন।

## সবচেয়ে সহজ Upload পদ্ধতি: মাত্র দুই ফাইল

1. নতুন ZIP `SRCreationFarm_YouTube_SEO_AI_FB_2.1.0.zip` ডাউনলোড করুন; **Extract করবেন না**।
2. GitHub Repository-র মূল ফোল্ডারে ZIP-টি Upload করুন।
3. দ্বিতীয় ফাইল `build-apk.yml`-টি Repository-তে **অবশ্যই** `.github/workflows/build-apk.yml` পাথে রাখুন। ZIP-এর ভিতরে Workflow থাকলেই GitHub Actions তা দেখবে না।
4. আগে রাখা পুরোনো Workflow (ভিন্ন নামে) থাকলে মুছে ফেলুন; পুরোনো Source ZIP থাকলেও নতুন Workflow নির্দিষ্ট 2.1.0 ZIP-কে আগে ব্যবহার করবে।
5. GitHub → Actions → **Build YouTube SEO AI APK** → **Run workflow** নির্বাচন করুন।
6. Build সফল হলে **Artifacts → youtube-seo-ai-debug-apk** থেকে ইনস্টলযোগ্য APK নিন।
7. Build ব্যর্থ হলে **youtube-seo-ai-build-diagnostics** থেকে লগ নিয়ে সমস্যার ধাপ দেখুন।

## বিকল্প পদ্ধতি

নতুন ZIP Extract করে সব ফাইল ও `.github` ফোল্ডার Repository-র Root-এ Upload করুন। এরপর একই Workflow ব্যবহার করুন।

## Signing / Updating

- Debug APK GitHub রানার দিয়ে Debug Key-তে সাইন হয়। নতুন GitHub Run-এ Signature আলাদা হলে পুরোনো APK-এর ওপর ইনস্টল হবে না। সে ক্ষেত্রে নিজের স্থায়ী Release Signing Key ব্যবহার করতে হবে; Uninstall করলে লোকাল ডেটা মুছে যাবে।
- Release APK নিজের Signing Key/Secret ছাড়া Unsigned থাকবে।
- App ID অপরিবর্তিত; Version 2.1.0, versionCode 6।

## সীমাবদ্ধতা

AI ৩টি Screenshot দেখে প্রস্তাবিত লেখা তৈরি করে। পুরো ভিডিও, কপিরাইট অনুমতি বা Facebook Policy স্বয়ংক্রিয়ভাবে নিশ্চিত করতে পারে না। পোস্টের আগে অবশ্যই সঠিকতা যাচাই করুন।
