# Changelog

## 2.1.0 (versionCode 6)

- Added Facebook Reels and Facebook Video content-writing modes.
- Added two distinct Meta-guideline-oriented prompts, for short reels and longer video descriptions.
- Added platform-specific result labels and persistent selected platform.
- History now stores each platform, while legacy entries default to YouTube.
- Unchanged: existing YouTube mode, API key, themes, Branding, Application ID and build toolchain.

## 2.0.2 (versionCode 5) — GitHub Build Compatibility
- Downgraded compile SDK from unavailable API 37 to supported API 36; kept target 36.
- Aligned Android Gradle Plugin 8.13.2 with Gradle 8.13 and JDK 17.
- Installed Android SDK platform 36 with Build Tools 35.0.0 (no deprecated tools package).
- Aligned AndroidX AppCompat 1.7.1 and Core 1.16.0 with Material 1.14.0.
- Removed unsupported Gemini 3.8 Flash `temperature` generation parameter.
- Generated the official Gradle Wrapper in an isolated CI bootstrap project.
- Added dependency-resolution logs, SDK package logs and APK metadata validation.
- Retained all existing screenshot/AI/branding/theme/history features and package ID.

## 2.0.1 — Android SDK Setup
- Updated SDK setup action to v4.
- Added ZIP and folder sources support for GitHub.
