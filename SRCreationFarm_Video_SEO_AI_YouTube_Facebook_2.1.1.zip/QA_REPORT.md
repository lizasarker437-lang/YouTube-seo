# Video SEO AI 2.1.1 — QA Report

## Reported failure and root cause
The GitHub Actions screenshot shows **`lintDebug FAILED`**: `app/src/main/res/values/styles.xml:10` declared `<item name="android:windowLightNavigationBar">false</item>` even though this framework style attribute requires API 27 and this project's `minSdk` is 23. The preceding `compileDebugJavaWithJavac` and `testDebugUnitTest` tasks ran; it was **not** a Java compilation failure.

## Fix
Removed the redundant false-valued API-27-only item from the base theme, without changing minSdk or disabling lint. The system's default is false; the Activity already changes status/navigation appearance at runtime. Added a preflight checker to detect regressions in API-sensitive style attributes. Updated version to 2.1.1, versionCode 7.

## Validation status
The exact test results for this revision are generated in the distribution QA notes below. The checks below should be repeated in GitHub Actions where the complete Android SDK and Gradle dependencies are available.

- Native Android application code and existing three content modes are preserved.
- GitHub Actions is configured to run `testDebugUnitTest lintDebug lintRelease`, `assembleDebug assembleRelease`, APK signature verification and diagnostic log uploads.
- **Full Android APK compilation cannot be confirmed without running the workflow**; source/XML checks are not a substitute for a successful Android build.

## Install/update note
For a previously signed release APK, the same application ID and signing certificate are needed to update in place. GitHub debug builds may use different signing certificates across runs; those cannot necessarily update an already installed build.

## বাস্তবে চালানো Local Verification — ২২ নভেম্বর ২০২৬

| পরীক্ষা | ফলাফল |
|---|---|
| Original 2.1.0 ZIP integrity | PASS |
| Java compiler AST syntax parse (১১টি .java) | PASS (0 syntax error) |
| Pure Java code compilation (`javac`) | PASS (৪টি production classes + ২টি test classes) |
| JUnit-compatible runner (৩টি Parser + ৮টি Facebook logic tests) | PASS 11/11 |
| Android Manifest + resource XML | PASS 6/6 |
| Image resources decoding | PASS 16/16 |
| Android API-level XML preflight (`minSdk 23`) | PASS |
| GitHub Actions YAML parse | PASS |
| Workflow bash syntax checks | PASS 10/10 |
| Version/API identity, ZIP precedence, workflow duplicates | PASS |

**Test limitations:** Local unit tests were executed with a minimal JUnit-compatible annotation/assertion harness because the Android/Gradle toolchain isn't installed here. They exercise the project’s actual pure-Java test methods, but do not replace the official Gradle `testDebugUnitTest` run. The ২৯ nonfatal Lint warnings shown on the screenshot were not individually available in the screenshot. We did not disable Lint or claim those warnings were eliminated.

**Unavailable in this environment:** Android Gradle Plugin dependency resolution, full `lintDebug`/`lintRelease`, full APK compilation, APK installation, hardware UI checks, live Gemini API, Facebook policy acceptance. The first successful GitHub Actions run is needed to validate these.

### GitHub source bootstrap simulation
`Prepare Android source` script executed successfully against a temporary repository containing **both** 2.1.0 and 2.1.1 ZIPs plus stale extracted `app/build.gradle`. The script selected 2.1.1, extracted its `settings.gradle`/`app`, and the extracted project passed the resource API preflight. **PASS.**
