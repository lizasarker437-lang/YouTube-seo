# GitHub-এ Video SEO AI 2.1.1 APK তৈরি (মোবাইল)

১. `SRCreationFarm_Video_SEO_AI_YouTube_Facebook_2.1.1.zip` GitHub Repository-র মূল (root) জায়গায় আপলোড করুন।
২. আলাদা `build-apk.yml` ফাইলটি Repository-র **`.github/workflows/build-apk.yml`** পথে আপলোড বা Replace করুন। ZIP-এর ভেতরে এই ফাইল থাকলেই Workflow চালু হবে না।
৩. Repo-তে আগে থেকে 2.1.0 বা অন্য ZIP থাকলেও Workflow নির্দিষ্ট 2.1.1 ZIP-কে অগ্রাধিকার দেবে। তবু পুরোনো ZIP মুছে রাখা ভালো।
৪. GitHub → Actions → **Build Video SEO AI APK** → **Run workflow** নির্বাচন করুন।
৫. সফল হলে **Artifacts → youtube-seo-ai-debug-apk** থেকে পরীক্ষার APK ডাউনলোড করুন।
৬. Build ব্যর্থ হলে **Artifacts → youtube-seo-ai-build-diagnostics** থেকে Error Logs সংগ্রহ করুন; `Run unit tests and Android lint`-এর শেষ Error-টিও দেখা যায়।

নতুন সংস্করণ: **2.1.1 (versionCode 7)**। আগের Application ID ও YouTube/Facebook ফিচার অক্ষুণ্ণ।
**সতর্কতা:** Workflow সফল না হলে Full APK Build যাচাই হয়েছে বলা যাবে না।
