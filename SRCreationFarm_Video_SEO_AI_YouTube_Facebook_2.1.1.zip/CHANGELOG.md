# Changelog

## 2.1.1 (versionCode 7) — 22 November 2026

- Fixed Android lint `NewApi`: the `android:windowLightNavigationBar` style item requires API 27, but minSdk is 23. Removed the redundant `false` value from unqualified `res/values/styles.xml`.
- Added offline Android resource-API preflight checker.
- GitHub workflow now runs `lintRelease` in addition to `lintDebug` and unit tests.
- GitHub ZIP bootstrap explicitly prioritizes the new 2.1.1 source file.
- Preserved YouTube, Facebook Reels, Facebook Video, Developer branding, API key storage and history.

# Changelog

## 2.1.0 — YouTube + Facebook Content Studio
- Added new platform selector with **YouTube, Facebook Reels, Facebook Video**.
- Added dedicated Meta-friendly prompts for Reels and longer Facebook video captions.
- Added Facebook Content Guidelines dialog with official policy reference.
- Added Facebook hashtag normalization (up to 5 unique relevant tags; not a Meta hard limit).
- Added platform-aware history persistence with migration fallback for older YouTube-only history.
- Preserved AI key encryption, screenshot input, editable results, sharing/copying, theme customization and developer branding.
- Kept applicationId unchanged; raised `versionCode` from 5 to 6 and versionName to 2.1.0.
- Updated repository mobile ZIP workflow to prioritize this 2.1.0 archive.
- Added JUnit tests for prompts, platform selection, normalization and legacy fallback.

## 2.0.2
- SDK API 36 and compatible AGP/Gradle build configuration.
- SDK bootstrap and GitHub ZIP-source workflow improvements.
