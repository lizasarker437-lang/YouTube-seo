#!/usr/bin/env python3
"""Offline preflight for resource/API consistency; Android Lint is still authoritative."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

# Keep these checks deliberately narrow and predictable. Don't hide Android lint failures.
app_gradle = (APP / "build.gradle").read_text(encoding="utf-8")
min_match = re.search(r"\bminSdk\s+(\d+)", app_gradle)
compile_match = re.search(r"\bcompileSdk\s+(\d+)", app_gradle)
if not min_match or not compile_match:
    sys.exit("FAIL: minSdk/compileSdk declaration is missing")
min_sdk = int(min_match.group(1))
compile_sdk = int(compile_match.group(1))
if compile_sdk < min_sdk:
    sys.exit(f"FAIL: compileSdk {compile_sdk} < minSdk {min_sdk}")

# Known API-sensitive Android framework XML attributes.
min_api_for_attr = {
    "windowLightNavigationBar": 27,
    "windowLightStatusBar": 23,
    "navigationBarColor": 21,
    "statusBarColor": 21,
}
xml_files = sorted((APP / "src/main/res").rglob("*.xml"))
xml_files.append(APP / "src/main/AndroidManifest.xml")
for path in xml_files:
    root = ET.parse(path).getroot()
    qualifier = path.parent.name
    match = re.search(r"(?:^|-)v(\d+)(?:-|$)", qualifier)
    resource_api = int(match.group(1)) if match else min_sdk
    for item in root.iter():
        if item.tag == "item":
            name = item.get("name", "")
            if name.startswith("android:"):
                min_attr_api = min_api_for_attr.get(name[8:])
                if min_attr_api is not None and resource_api < min_attr_api:
                    sys.exit(f"FAIL: {path.relative_to(ROOT)} uses {name} "
                             f"(API {min_attr_api}) but resource folder supports API {resource_api}")
        for key in item.attrib:
            if key.startswith(ANDROID_NS):
                min_attr_api = min_api_for_attr.get(key[len(ANDROID_NS):])
                if min_attr_api is not None and resource_api < min_attr_api:
                    sys.exit(f"FAIL: {path.relative_to(ROOT)} uses {key} "
                             f"(API {min_attr_api}) before API {resource_api}")

assert (APP / "src/main/java/com/shahriar/youtubeseo/youtube_seo_ai/MainActivity.java").is_file()
assert (ROOT / ".github/workflows/build-apk.yml").is_file()
assert (ROOT / "gradle/wrapper/gradle-wrapper.properties").is_file()
print(f"PASS: {len(xml_files)} Android XML files well-formed; API-sensitive style attributes compatible with minSdk {min_sdk}")
print(f"PASS: compileSdk {compile_sdk}, source files, manifest and build workflow present")
