package com.srcreationfarm.youtubeseopro.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.srcreationfarm.youtubeseopro.utils.SeoResponseParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class GeminiSeoService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .readTimeout(150, TimeUnit.SECONDS)
        .callTimeout(180, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val gson = Gson()

    suspend fun generateSeoFromScreenshots(
        context: Context,
        apiKey: String,
        model: String,
        imageUris: List<Uri>,
        language: String,
        keywordHint: String,
        onProgress: (Int, String) -> Unit
    ): Result<SeoResponseParser.ParsedSeo> = withContext(Dispatchers.IO) {
        try {
            onProgress(5, "স্ক্রিনশট অপ্টিমাইজেশন শুরু হচ্ছে...")
            val partsArray = JsonArray()

            val extraInfo = if (keywordHint.isNotBlank()) {
                "অতিরিক্ত কিওয়ার্ড বা বিষয়: $keywordHint"
            } else {
                ""
            }

            val prompt = "তুমি একজন প্রফেশনাল YouTube SEO এবং কন্টেন্ট স্ট্র্যাটেজিস্ট।\n" +
                "তোমাকে একটি ভিডিওর ৩টি স্ক্রিনশট দেওয়া হয়েছে। এই ৩টি স্ক্রিনশট গভীরভাবে বিশ্লেষণ করে ভিডিওটির মূল বিষয়বস্তু, ধরন, দৃশ্যপট এবং দর্শকদের আগ্রহের জায়গা খুঁজে বের করো।\n" +
                "$extraInfo\n\n" +
                "ভাষা নির্দেশনা: আউটপুট অবশ্যই $language ভাষায় তৈরি করবে।\n\n" +
                "নিচের ঠিক এই ফরম্যাটে উত্তর দাও (কোনো বাড়তি ভূমিকা বা উপসংহার লিখবে না):\n\n" +
                "[TITLE]\n(এখানে উচ্চ-CTR সম্পন্ন, আকর্ষণীয় এবং সার্চ-ফ্রেন্ডলি একটি সেরা ইউটিউব টাইটেল লিখবে)\n\n" +
                "[DESCRIPTION]\n(এখানে ইউটিউব অ্যালগরিদম ও এসইও-বান্ধব বিস্তারিত ডেসক্রিপশন লিখবে। প্রথম ২ লাইনে মূল কিওয়ার্ড রাখবে, এরপর ভিডিওর সারসংক্ষেপ ও দর্শকদের জন্য কল-টু-অ্যাকশন যুক্ত করবে)\n\n" +
                "[HASHTAGS]\n(এখানে ১৫টি হাই-র‍্যাংকিং এবং প্রাসঙ্গিক ইউটিউব হ্যাশট্যাগ স্পেস দিয়ে লিখবে, যেমন: #tag1 #tag2 #tag3)"

            val textPart = JsonObject().apply {
                addProperty("text", prompt)
            }
            partsArray.add(textPart)

            for ((index, uri) in imageUris.withIndex()) {
                val stepPercent = 12 + (index * 10)
                onProgress(stepPercent, "স্ক্রিনশট ${index + 1} কম্প্রেস করা হচ্ছে...")
                val base64 = encodeUriToFastBase64(context, uri)
                    ?: return@withContext Result.failure(Exception("স্ক্রিনশট ${index + 1} প্রসেস করতে সমস্যা হয়েছে।"))
                val inlineData = JsonObject().apply {
                    addProperty("mime_type", "image/jpeg")
                    addProperty("data", base64)
                }
                val imagePart = JsonObject().apply {
                    add("inline_data", inlineData)
                }
                partsArray.add(imagePart)
            }

            onProgress(40, "ডেটা প্যাকেজ প্রস্তুত হচ্ছে...")

            val contentObj = JsonObject().apply {
                add("parts", partsArray)
            }
            val contentsArray = JsonArray().apply {
                add(contentObj)
            }
            val genConfig = JsonObject().apply {
                addProperty("temperature", 0.7)
                addProperty("maxOutputTokens", 2048)
            }
            val rootBody = JsonObject().apply {
                add("contents", contentsArray)
                add("generationConfig", genConfig)
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val payloadJson = gson.toJson(rootBody)

            val networkFinished = AtomicBoolean(false)
            val progressJob = launch {
                var currentPct = 45
                while (isActive && !networkFinished.get() && currentPct < 92) {
                    val statusMsg = when {
                        currentPct < 60 -> "AI সার্ভারে ছবি পাঠানো হচ্ছে ($currentPct%)..."
                        currentPct < 80 -> "Gemini AI স্ক্রিনশট বিশ্লেষণ করছে ($currentPct%)..."
                        else -> "টাইটেল, ডেসক্রিপশন ও হ্যাশট্যাগ লেখা হচ্ছে ($currentPct%)..."
                    }
                    onProgress(currentPct, statusMsg)
                    delay(450)
                    currentPct += 2
                }
            }

            var lastException: Exception? = null
            var responseString = ""
            var responseSuccess = false
            var responseCode = 0

            // Automatic retry up to 2 attempts if network times out on slow connection
            for (attempt in 1..2) {
                try {
                    if (attempt == 2) {
                        onProgress(65, "ধীরগতির নেটওয়ার্ক: পুনরায় চেষ্টা করা হচ্ছে...")
                    }
                    val requestBody = payloadJson.toRequestBody("application/json; charset=utf-8".toMediaType())
                    val request = Request.Builder()
                        .url(url)
                        .post(requestBody)
                        .build()

                    client.newCall(request).execute().use { response ->
                        responseCode = response.code
                        responseSuccess = response.isSuccessful
                        responseString = response.body?.string().orEmpty()
                    }
                    lastException = null
                    break
                } catch (e: SocketTimeoutException) {
                    lastException = Exception("নেটওয়ার্ক ধীরগতির কারণে সময় বেশি লাগছে (Timeout)। অনুগ্রহ করে ইন্টারনেট কানেকশন চেক করে আবার চেষ্টা করুন।")
                } catch (e: IOException) {
                    lastException = Exception("ইন্টারনেট সংযোগ বিচ্ছিন্ন বা দুর্বল: ${e.localizedMessage ?: "Network Error"}")
                }
            }

            networkFinished.set(true)
            progressJob.cancel()

            if (lastException != null) {
                return@withContext Result.failure(lastException)
            }

            onProgress(95, "ফলাফল যাচাই করা হচ্ছে...")

            if (!responseSuccess) {
                val errObj = runCatching { gson.fromJson(responseString, JsonObject::class.java) }.getOrNull()
                val apiErrMsg = errObj?.getAsJsonObject("error")?.get("message")?.asString
                    ?: "API ত্রুটি (কোড: $responseCode)"
                return@withContext Result.failure(Exception(apiErrMsg))
            }

            val jsonResponse = gson.fromJson(responseString, JsonObject::class.java)
            val generatedText = jsonResponse
                ?.getAsJsonArray("candidates")
                ?.get(0)?.asJsonObject
                ?.getAsJsonObject("content")
                ?.getAsJsonArray("parts")
                ?.get(0)?.asJsonObject
                ?.get("text")?.asString
                .orEmpty()

            if (generatedText.isBlank()) {
                return@withContext Result.failure(Exception("AI থেকে কোনো উত্তর পাওয়া যায়নি।"))
            }

            onProgress(100, "SEO তৈরি ১০০% সম্পন্ন হয়েছে!")
            Result.success(SeoResponseParser.parse(generatedText))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun encodeUriToFastBase64(context: Context, uri: Uri): String? {
        return try {
            // Step 1: Decode bounds only to avoid OOM and speed up decoding
            val boundsOptions = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, boundsOptions)
            }
            if (boundsOptions.outWidth <= 0 || boundsOptions.outHeight <= 0) return null

            // Target max 720px so 3 images total under ~180KB (prevents timeout on slow 0.2KB/s mobile data!)
            val maxDim = 720
            var sampleSize = 1
            while (boundsOptions.outWidth / sampleSize > maxDim * 2 || boundsOptions.outHeight / sampleSize > maxDim * 2) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
            }
            val decoded = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            } ?: return null

            val ratio = minOf(maxDim.toFloat() / decoded.width, maxDim.toFloat() / decoded.height, 1.0f)
            val targetW = (decoded.width * ratio).toInt().coerceAtLeast(1)
            val targetH = (decoded.height * ratio).toInt().coerceAtLeast(1)

            val scaled = Bitmap.createScaledBitmap(decoded, targetW, targetH, true)
            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 72, baos)
            if (scaled != decoded) scaled.recycle()
            decoded.recycle()

            Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }
}
