# Changelog

## 2.0.1 (versionCode 4) — Android SDK setup fix

- Fixed GitHub Actions failure: removed `android-actions/setup-android@v3`, which tried to install retired Android SDK `tools`.
- Switched to `android-actions/setup-android@v4` with no default packages and explicitly installed supported SDK packages.
- Added SDK-file checks and toolchain diagnostics uploaded even after failed jobs.
- Added one-ZIP upload extraction for GitHub mobile workflow; workflow YAML must still exist separately in `.github/workflows/`.
- Preserved application ID, branding, functionality and local data format; increased app version.
- Kept AGP 9.4.0 + Gradle 9.6.0 + JDK 17, a documented compatible combination.

## 2.0.0 (versionCode 3)

- Rebuilt the app as a native Android Java project.
- Preserved the three-screenshot Gemini SEO workflow.
- Added SR Creation Farm branding and a dedicated app icon.
- Added About Developer section with YouTube and Facebook buttons.
- Added System / Light / Dark appearance modes.
- Added nine persistent color themes.
- Added encrypted Gemini API key storage with Android Keystore AES-GCM.
- Added editable Title, Description and Hashtags fields.
- Added per-section copy and copy-all.
- Added local history for the latest 20 generations.
- Added privacy information and clear-history controls.
- Added Android unit tests, lint, APK verification and build-log artifact upload.
